/*
 * Copyright (C) 2006,2007 Eduardo Sabbatella Riccardi
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * Email: esabb <at> users.sourceforge.net
 */

package org.javago.mc.impl;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.javago.mc.TranspositionTable;

public class DynamicTranspositionTableImpl implements TranspositionTable {
	
	private int MAXMOVE = 300;
	private int NODESMALL_INITIAL_SIZE = 8;
	private int MAX_GENERATION_AGE = 4;

	private int _boardSize;
	private int _curGeneration;

	private Map<Long,TTNode>[] _tt;  // Map[] -> int[played|wins][P]

	TTNode _onlyOnePass = new TTNodeOnlyOnePass();
	
	abstract class TTNode {
		int _generation = 0;
		long _sumPlayed = 0;
		abstract boolean storeBlackWin(int P);
		abstract boolean storeLose(int P);
		abstract int getBlackWins(int P);
		abstract int getPlayed(int P);
		long getSumPlayed() {
			return _sumPlayed;
		}
	}
	
	class TTNodeOnlyOnePass extends TTNode {
		int getBlackWins(int P) {
			return 0;
		}
		int getPlayed(int P) {
			return 0;
		}
		boolean storeBlackWin(int P) {
			return false;
		}
		boolean storeLose(int P) {
			return false;
		}
	}
	
	class TTNodeSmall extends TTNode {
		int[] _blackWinTable;
		int[] _playedTable;
		int[] _indirection;
		public TTNodeSmall() {
			_blackWinTable = new int[NODESMALL_INITIAL_SIZE];
			_playedTable = new int[NODESMALL_INITIAL_SIZE];
			_indirection = new int[NODESMALL_INITIAL_SIZE];
			for (int i=0; i<_indirection.length; i++)
				_indirection[i]=-1;
		}
		int getBlackWins(int P) {
			_generation = _curGeneration;
			int i=0;
			while (_indirection[i]!=-1 && i<_indirection.length) {
				if (_indirection[i]==P) 
					return _blackWinTable[i];
				i++;
			}
			return 0;
		}
		int getPlayed(int P) {
			_generation = _curGeneration;
			int i=0;
			while (_indirection[i]!=-1 && i<_indirection.length) {
				if (_indirection[i]==P)
					return _playedTable[i];
				i++;				
			}
			return 0;
		}
		boolean storeBlackWin(int P) {
			_generation = _curGeneration;
			int i=0;
			while (i<_indirection.length && _indirection[i]!=-1) {
				if (_indirection[i]==P) {
					_blackWinTable[i]++;
					_playedTable[i]++;
					_sumPlayed++;
					return true;
				}
				i++;
			}

			if (i==_indirection.length)
				return false;

			_indirection[i]=P;
			_blackWinTable[i]=1;
			_playedTable[i]=1;
			_sumPlayed++;
			return true;
		}
		boolean storeLose(int P) {
			_generation = _curGeneration;
			int i=0;
			while (i<_indirection.length && _indirection[i]!=-1) {
				if (_indirection[i]==P) {
					_playedTable[i]++;
					_sumPlayed++;
					return true;
				}
				i++;
			}
			if (i==_indirection.length)
				return false;

			_indirection[i]=P;
			_blackWinTable[i]=0;
			_playedTable[i]=1;
			_sumPlayed++;
			return true;
		}
	}
	
	class TTNodeBig extends TTNode {
		int[] _blackWinTable;
		int[] _playedTable;
		public TTNodeBig(TTNodeSmall smallNode) {
			//System.err.println(this+"("+smallNode+")");
			_blackWinTable = new int[_boardSize];
			_playedTable = new int[_boardSize];
			for (int i=0; i<smallNode._indirection.length; i++) {
				int ind = smallNode._indirection[i];
				if (ind!=-1) {
					_blackWinTable[ind] += smallNode._blackWinTable[i];
					_playedTable[ind] += smallNode._playedTable[i];
				}
			}
			_sumPlayed = smallNode._sumPlayed;
		}
		int getBlackWins(int P) {
			_generation = _curGeneration;
			return _blackWinTable[P];
		}
		int getPlayed(int P) {
			_generation = _curGeneration;
			return _playedTable[P];
		}
		boolean storeBlackWin(int P) {
			_generation = _curGeneration;
			_blackWinTable[P]++;
			_playedTable[P]++;
			_sumPlayed++;
			return true;
		}
		boolean storeLose(int P) {
			_generation = _curGeneration;
			_playedTable[P]++;
			_sumPlayed++;
			return true;
		}
		int[] getBlackWinTable() {
			_generation = _curGeneration;
			return _blackWinTable;
		}
		int[] getPlayedTable() {
			_generation = _curGeneration;
			return _playedTable;
		}
	}
	
	@SuppressWarnings("unchecked")
	public DynamicTranspositionTableImpl(int boardSize) {
		_boardSize = boardSize;
		_tt = new Map[MAXMOVE];
		for (int i=0; i<MAXMOVE; i++)
			_tt[i] = new HashMap<Long,TTNode>(_boardSize);
		_curGeneration = 0;
	}

	public int getBlackWins(int moveno, long hash, int P) {
		Long hashObj = new Long(hash);
		if (_tt[moveno].containsKey(hashObj)) {
			TTNode ttnode = _tt[moveno].get(hashObj);
			return ttnode.getBlackWins(P);
		}
		return 0;
	}

	public int getPlayed(int moveno, long hash, int P) {
		Long hashObj = new Long(hash);
		if (_tt[moveno].containsKey(hashObj)) {
			TTNode ttnode = _tt[moveno].get(hashObj);
			return ttnode.getPlayed(P);
		}
		return 0;
	}

	public int[] getBlackWinsTable(int moveno, long hash) {
		Long hashObj = new Long(hash);
		if (_tt[moveno].containsKey(hashObj)) {
			TTNode ttnode = _tt[moveno].get(hashObj);
						
			if (ttnode instanceof TTNodeBig)
				return ((TTNodeBig)ttnode).getBlackWinTable();			

			if (ttnode instanceof TTNodeOnlyOnePass)
				ttnode = new TTNodeSmall();
			
			//synchronized (this) { // XXX:
				TTNodeBig ttnodebig = new TTNodeBig( (TTNodeSmall)ttnode );
				_tt[moveno].put(hashObj, ttnodebig);
				return ((TTNodeBig)ttnodebig).getBlackWinTable();
			//}
		} else {
			return null;
		}
	}

	public int[] getPlayedTable(int moveno, long hash) {
		Long hashObj = new Long(hash);
		if (_tt[moveno].containsKey(hashObj)) {
			TTNode ttnode = _tt[moveno].get(hashObj);

			if (ttnode instanceof TTNodeBig)
				return ((TTNodeBig)ttnode).getPlayedTable();

			if (ttnode instanceof TTNodeOnlyOnePass)
				ttnode = new TTNodeSmall();
			
			//synchronized (this) { // XXX:
				TTNodeBig ttnodebig = new TTNodeBig( (TTNodeSmall)ttnode );
				_tt[moveno].put(hashObj, ttnodebig);
			
				return ((TTNodeBig)ttnodebig).getPlayedTable();
			//}
		} else {
			return null;
		}
	}

	public long getSumPlayed(int moveno, long hash) {
		Long hashObj = new Long(hash);
		if (_tt[moveno].containsKey(hashObj)) {
			TTNode ttnode = _tt[moveno].get(hashObj);
			return ttnode._sumPlayed;
		}
		return 0;
	}

	public synchronized void storeBlackWin(int moveno, long hash, int P) {
		Long hashObj = new Long(hash);
		if (_tt[moveno].containsKey(hashObj)) {
			TTNode ttnode = _tt[moveno].get(hashObj);
			
			if (ttnode instanceof TTNodeOnlyOnePass) {
				ttnode = new TTNodeSmall();
				_tt[moveno].put(hashObj, ttnode);
				ttnode.storeBlackWin(P);
				return;
			}
			
			if (!ttnode.storeBlackWin(P)) {
				TTNode bigttnode = new TTNodeBig((TTNodeSmall)ttnode);
				bigttnode.storeBlackWin(P);
				_tt[moveno].put(hashObj, bigttnode);
			}
		} else {
			// 1st time, only store a flag, next time will be stored.
			_tt[moveno].put(hashObj, _onlyOnePass); 
		}
	}

	public synchronized void storeLose(int moveno, long hash, int P) {
		Long hashObj = new Long(hash);
		if (_tt[moveno].containsKey(hashObj)) {
			TTNode ttnode = _tt[moveno].get(hashObj);

			if (ttnode instanceof TTNodeOnlyOnePass) {
				ttnode = new TTNodeSmall();
				_tt[moveno].put(hashObj, ttnode);
				ttnode.storeLose(P);
				return;
			}

			if (!ttnode.storeLose(P)) {
				TTNode bigttnode = new TTNodeBig((TTNodeSmall)ttnode);
				bigttnode.storeLose(P);
				_tt[moveno].put(hashObj, bigttnode);
			}
		} else {
			// 1st time, only store a flag, next time will be stored.
			_tt[moveno].put(hashObj, _onlyOnePass); 
		}
	}

	public void onMove(int moveno) {
		_curGeneration = moveno;
		Runtime rt = Runtime.getRuntime();
		rt.gc();
		long memory = rt.freeMemory();
		for (int i=0; i<moveno; i++) {
			_tt[i] = new HashMap<Long,TTNode>(_boardSize);
		}

		int recycled = 0;
		for (int i=0; i<_tt.length; i++) {
			Collection<TTNode> values = _tt[i].values();
			for ( Iterator<TTNode> iter = values.iterator(); iter.hasNext(); ) {
				TTNode value = iter.next();
				if (value instanceof TTNodeOnlyOnePass
					|| value._generation + MAX_GENERATION_AGE <= _curGeneration) {
					_tt[i].remove(value);
					recycled++;
				}
			}
		}
		
		rt.gc();
		memory = rt.freeMemory() - memory;
		System.err.println(this + "  " + recycled + " recycled. " + memory/1024 + " Freeded KBytes, Total Free " + rt.freeMemory() / 1024 + " KBytes.");
	}

}
