/*
 * Copyright (C) 2006,2007 Eduardo Sabbatella Riccardi
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * Email: esabb <at> users.sourceforge.net
 */

package org.javago.mc;

import java.util.Formatter;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;

import org.javago.base.Board;
import org.javago.base.Game;
import org.javago.base.Move;
import org.javago.base.impl.GameImpl;
import org.javago.base.impl.MoveFactory;
import org.javago.base.util.GameHelper;
import org.javago.base.util.impl.GameHelperImpl;
import org.javago.ctrl.Engine;
import org.javago.mc.impl.FixedTimeStrategy;

/*
 * This class implements a base montecarlo engine. <br>
 * Including: <br>
 * <li> Generic properties set
 * <li> Multicore automatic workers
 * 
 */
public abstract class BaseMonteCarloEngine implements Engine {

	protected Game _game;
	protected TimeStrategy _timeStrategy;
	
	protected GameHelper _gh;
	protected MoveFactory _mf;

	protected Random _rnd;
	protected long _randseed;
	protected long _cputime;
		
	protected int MAX_THREADS = Runtime.getRuntime().availableProcessors() + 1;
	//XXX: This value should be set by configuration.
	
	/**
	 * Default constructor should be call by implementing class.
	 */
	protected BaseMonteCarloEngine() {
		_game = new GameImpl(19);
		_gh = new GameHelperImpl();
		_mf = MoveFactory.getInstance();
		_randseed = System.currentTimeMillis();
		_rnd = new Random( _randseed );
		_timeStrategy = new FixedTimeStrategy();
	}
	
	public abstract String getVersion();

	public abstract String getName();
	
	/**
	 * Derived method should care about using a copy of current game
	 * (not destroying it). <br>
	 * Method should be thread safe as this base class will call this 
	 * method multiple times from different threads. <br>
	 * Finally, implementor should care about storing information to be
	 * used later by getBestMove()
	 */
	protected abstract void simulateAGame();
	
	/**
	 * Retrieves current best move for specified player at current game
	 * state. 
	 * @return a move, a null object means resign.
	 */
	protected abstract Move getBestMove(int player);

	
	public void setTimeStrategy(TimeStrategy timeStrategy) {
		_timeStrategy = timeStrategy;
	}
	
	public void setRandomSeed(long seed) {
		_randseed = seed;
		_rnd.setSeed(_randseed);
	}

	public long getRandomSeed() {
		return _randseed;
	}
	
	public boolean setKomi(float komi) {
		try {
			_game.setKomi(komi);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public boolean setHandicap(int stones) {
		try {
			_game.setHandicap(stones);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public void setBoardSize(int size) {
		_game = new GameImpl(size);
	}
	
	public Game getGame() {
		return _game;
	}
		
	public Board getBoard() {
		return _game.getBoard();
	}
	
	public void clearBoard() {
		int size = _game.getBoard().getSize();
		_game = new GameImpl( size );
	}
	

	public void correctTime(int color, int time, int stones) {
		System.err.println(this+": correctTime not implemented.");
	}

	public void setTime(int main, int byoYomi, int stones) {
		System.err.println(this+": setTime not implemented.");
	}

	public void finish() {
		System.err.println(this+": finish not implemented.");
	}

	public void reset() {
		System.err.println(this+": reset not implemented.");
	}
	
	public long getCpuTimeInMillis() {
		return _cputime;
	}
	
	public boolean undo() {
		return false;
	}

	public boolean play(Move move) {
		return _game.play(move);
	}

	public String calcScore() {
		// XXX: RESIGN????????????
		// XXX: result can be "cannot score"
		// XXX: Please tiddy this method.
		float komi = _game.getKomi();
		int[] scores = _gh.getChineseScore(_game);
		if (scores[Board.EMPTY]>komi) return "can't score";
 		float sc = (float)scores[Board.WHITE]+komi-(float)scores[Board.BLACK];
		if (sc>0) {
			return new Formatter().format("%s+%.1f", "W", sc).toString();
		} else {
			return new Formatter().format("%s+%.1f", "B", -sc).toString();
		}
	}

	/**
	 * Worker thread
	 * @author esabb
	 */
	private class Worker extends Thread {
		BaseMonteCarloEngine _owner;
		AtomicLong _counter;
		boolean finish;
		public Worker(BaseMonteCarloEngine owner, AtomicLong counter) {
			_owner = owner;
			_counter = counter;
			finish = false;
		}
		public void pleaseFinish() {
			finish = true;
		}
		public void run() {
			System.err.print("^"); System.err.flush();
			long i = 0;
			while (!finish) {
				if (++i%1000==0) {
					System.err.print("."); System.err.flush();
				}
				_owner.simulateAGame();
				_counter.incrementAndGet();
			}
			System.err.print("v"); System.err.flush();
		}
	}

	public Move genMove(int player) {
		
		// if player!=current player, lets introduce an oponent pass
		if (player!=_game.playerToPlay()) {
			play(_mf.get(_game.playerToPlay()));
		}
		
		long startMs = System.currentTimeMillis();
		AtomicLong counter = new AtomicLong();

		// MC -- Starts Workers
		Worker[] workers = new Worker[MAX_THREADS];
		for (int i=0; i<MAX_THREADS; i++) {
			workers[i] = new Worker(this, counter);
			workers[i].setPriority( Thread.NORM_PRIORITY );
			workers[i].start();
		}
		
		// Runs the simulation using the TimeStrategy
		long timeToRun = _timeStrategy.getMs(_game);
		long elapseTime = System.currentTimeMillis()-startMs;
		while (timeToRun>elapseTime) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {};
			
			elapseTime = System.currentTimeMillis()-startMs;
			timeToRun = _timeStrategy.updateMs(_game, elapseTime, counter.get());
		}
		
		// Notify all workers to finish
		for (int i = 0; i<workers.length; i++)
			workers[i].pleaseFinish();
		
		// Join Workers
		boolean joining = true;
		while (joining) {
			joining = false;
			for (int i=0; i<workers.length; i++) {
				if (workers[i] != null) {
					joining = true;
					try {
						workers[i].join(10);
					} catch (InterruptedException e) {}
					if (!workers[i].isAlive()) workers[i] = null;
				}
			}
		}
		System.err.println();
		
		// maintaing cputime
		elapseTime = System.currentTimeMillis()-startMs;
		_cputime += elapseTime;
		System.err.println("Elapsed time = " + elapseTime + "ms for " + counter.get() +" games ("+ counter.get()*1000/elapseTime + " pps)" );

		// returns the best move
		Move move = getBestMove(player);
		if (move!=null) play(move);
		return move;
	}

	public Move genMove() {
		return genMove(_game.playerToPlay());
	}

}
