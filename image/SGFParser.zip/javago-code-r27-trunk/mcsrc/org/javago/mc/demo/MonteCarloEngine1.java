/*
 * Copyright (C) 2006,2007 Eduardo Sabbatella Riccardi
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * Email: esabb <at> users.sourceforge.net
 */

package org.javago.mc.demo;

import org.javago.base.Board;
import org.javago.base.Game;
import org.javago.base.Move;
import org.javago.mc.BaseMonteCarloEngine;
import org.javago.mc.TranspositionTable;
import org.javago.mc.impl.DynamicTranspositionTableImpl;
import org.javago.mc.impl.FixedSimulationStrategy;

/**
 * Very Very Very vanila/simple MCGO just to ilustrate.
 * @author esabb
 *
 */
public class MonteCarloEngine1 extends BaseMonteCarloEngine {

	private TranspositionTable _tt;
	
	protected float RESIGN_THRESHOLD = 0.20f;
	protected float PASS_THRESHOLD = 0.99f;
	protected int MAX_MOVE = 130;
	
	
	public MonteCarloEngine1() {
		super();
		_timeStrategy = new FixedSimulationStrategy(10000);
		int size = getBoard().getSize();
		_tt = new DynamicTranspositionTableImpl( (size*size)+1 );
	}
	
	public void setBoardSize(int size) {
		super.setBoardSize(size);
		_tt = new DynamicTranspositionTableImpl( (size*size) + 1 );
	}
	
	public Move genMove(int player) {
		_tt.onMove( _game.moveToPlay() ); // XXX: this value? or value -1 ?
		return super.genMove(player);
	}
	
	public String getName() {
		return "MonteCarloEngine1 demo engine";
	}

	public String getVersion() {
		return "1";
	}

	protected Move getBestMove(int player) {
		Board board = _game.getBoard();
		int moveno = _game.moveToPlay();
		long hash = _game.getBoard().getHash();
		int[] blackWinsTable = _tt.getBlackWinsTable(moveno, hash);
		int[] playedTable = _tt.getPlayedTable(moveno, hash);
		if (playedTable==null || blackWinsTable==null) return null;
		
		Move move = null;
		int P = -1;
		float Pratio = Float.MIN_VALUE;

		for (int i=0; i<playedTable.length; i++) {

			float played = (player == Board.BLACK)
					?(float)blackWinsTable[i]
					:(float)playedTable[i]-(float)blackWinsTable[i];
	
			float ratio = (playedTable[i]>0)
						?played / (float)playedTable[i]
						:Float.MIN_VALUE;
						
			if (ratio>Pratio) {
				// XXX: invalid moves should´nt be explored at all.. 
				// perhaps because of transposition caching data.
				move = (i == playedTable.length-1)
					?_mf.get(player)
					:_mf.get( board.getXfromP(i), board.getYfromP(i), player);
				if ( _game.isValidMove(move)) {
					Pratio = ratio;
					P = i;
				}
			}
		}
		
		// P==-1 ? something wrong. Force resign.
		if (P == -1) return null;
		
		// ratio below threshold ? resign.
		if (Pratio < RESIGN_THRESHOLD) return null;
		
		// if Pratio > PASS_THRESHOLD, pass. Its win.
		if (Pratio > PASS_THRESHOLD) 
			return _mf.get(player);
		
		// ok, move.
		System.err.println("P("+move+") = " + Pratio);
		return move;
	}
	
	protected void simulateAGame() {
		Game gameCopy = _game.clone();
		recursiveSim(gameCopy);
	}
	
	private int recursiveSim(Game game) {

		// Base Step
		if (game.finished() || game.moveToPlay() > MAX_MOVE) {
			int[] scores = _gh.getChineseScore(game);
	 		float sc = (float)scores[Board.WHITE]+ game.getKomi()-(float)scores[Board.BLACK];
	 		if (sc < 0) {
	 			return Board.WHITE;
	 		} else {
	 			return Board.BLACK;
	 		}
		}
		
		// Recursive Step
		Board board = game.getBoard();
		int moveno = game.moveToPlay();
		int player = game.playerToPlay();
		long hash = board.getHash();
		int size = board.getSize();
		
		Move nextMove = _mf.get(_rnd.nextInt(size), _rnd.nextInt(size), player);
		int tries = 0;
		while (!game.isValidMove(nextMove)) {
			if (tries++>80)
				nextMove = _mf.get(player);
			else 
				nextMove = _mf.get(_rnd.nextInt(size), _rnd.nextInt(size), player);
		}
		int P = (nextMove.isPass())? size*size : game.getBoard().convertToP(nextMove.getX(), nextMove.getY());
		
		game.play(nextMove);
		
		int res = recursiveSim(game);

		// rollback storing values
		if (res == Board.BLACK) {
			_tt.storeBlackWin(moveno, hash, P);
		} else {
			_tt.storeLose(moveno, hash, P);
		}
		
		return res;
	}

}
