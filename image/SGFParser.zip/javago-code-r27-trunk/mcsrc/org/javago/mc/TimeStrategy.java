/*
 * Copyright (C) 2006,2007 Eduardo Sabbatella Riccardi
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * Email: esabb <at> users.sourceforge.net
 */

package org.javago.mc;

import org.javago.base.Game;

/**
 * This class will decides how much time spend on a move calculation.
 * Different implementors could implement different strategies.
 * Its dynamic, it could decide to alloc a determined amount of time to
 * calculate the next movement, but dynamically it could change and
 * stop later or earlier. (i.e. a determined confidence level was
 * reached so no more search is required).
 * @author esabb
 *
 */
public interface TimeStrategy {

	/**
	 * Calculates the initial ammount of millisecs to run the simulation.
	 * @param game current game state.
	 * @return the ammount of millisecs to run.
	 */
	long getMs(Game game);
	
	/**
	 * This method will be called every second (approx). It will update
	 * the ammount of time to run the simulation.
	 * @param game current game state.
	 * @param ms millisecs already executed from begining.
	 * @param simulations number of simulations executed up to this moment.
	 * @return the final ammount of millisecs to run. if return value is 
	 * minor than already executed millisecs, simulation will be stop asap.
	 */
	long updateMs(Game game, long ms, long simulations);

}
