/*
 * Copyright (C) 2006,2007 Eduardo Sabbatella Riccardi
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * Email: esabb <at> users.sourceforge.net
 */

package org.javago.mc;

public interface TranspositionTable {
	
	// P=boardLength => pass
	
	int[] getBlackWinsTable(int moveno, long hash);
	int[] getPlayedTable(int moveno, long hash);
	
	int	getBlackWins(int moveno, long hash, int P);
	int getPlayed(int moveno, long hash, int P);
	
	long getSumPlayed(int moveno, long hash);
	
	void storeLose(int moveno, long hash, int P);
	void storeBlackWin(int moveno, long hash, int P);

	/*
	 * Informs the GameCache that we are currently playing move number moveno, so it can
	 * invalidate all cache entries for moves before current one.
	 * This call could take longer as it may do housekeeping.
	 */
	void onMove(int moveno);

}
