/*
 * Copyright (C) 2006,2007 Eduardo Sabbatella Riccardi
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * Email: esabb <at> users.sourceforge.net
 */

package org.javago.ctrl;

import java.util.ArrayList;
import java.util.List;

import org.javago.base.Board;
import org.javago.base.Game;
import org.javago.base.Move;
import org.javago.base.impl.GameImpl;

public class MockEngine implements Engine {
	
	List<String> history;
	
	public MockEngine() {
		history = new ArrayList<String>();
	}
	
	public List getHistory() {
		return history;
	}

	public String calcScore() {
		history.add("calcScore()");
		return "cannot score";
	}

	public void clearBoard() {
		history.add("clearBoard()");
	}

	public void correctTime(int color, int time, int stones) {
		history.add("correctTime("+color+","+time+","+stones+")");
	}

	public void finish() {
		history.add("finish()");
	}

	public Move genMove() {
		history.add("genMove()");
		return null;
	}
	
	public Move genMove(int player) {
		history.add("genMove("+player+")");
		return null;
	}
	
	public Board getBoard() {
		history.add("getBoard()");
		return null;
	}

	public Game getGame() {
		history.add("getGame()");
		return new GameImpl(19);
	}

	public String getName() {
		history.add("getName()");
		return "MockEngine";
	}

	public String getVersion() {
		history.add("getVersion()");
		return null;
	}

	public boolean play(Move move) {
		history.add("play("+move.toString()+")");
		return false;
	}

	public void reset() {
		history.add("reset()");
	}

	public void setBoardSize(int size) {
		history.add("setBoardSize("+size+")");
	}

	public boolean setHandicap(int stones) {
		history.add("setHandicap("+stones+")");
		return false;
	}

	public boolean setKomi(float komi) {
		history.add("setKomi("+komi+")");
		return true;
	}

	public void setTime(int main, int byoYomi, int stones) {
		history.add("setTime("+main+","+byoYomi+","+stones+")");
	}

	public boolean undo() {
		history.add("undo()");
		return false;
	}

	public long getRandomSeed() {
		history.add("getRandomSeed()");
		return 0;
	}

	public void setRandomSeed(long seed) {
		history.add("setRandomSeed("+seed+")");
	}

	public long getCpuTimeInMillis() {
		history.add("getCpuTimeInMillis()");
		return 0;
	}

}
