/*
 * Copyright (C) 2006,2007 Eduardo Sabbatella Riccardi
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * Email: esabb <at> users.sourceforge.net
 */

package org.javago.ctrl.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

import org.javago.ctrl.MockEngine;
import junit.framework.TestCase;

public class GoTextProtocolImplTest extends TestCase {
	
	GoTextProtocolImpl gtp;
	MockEngine engine;
	InputStream in;
	ByteArrayOutputStream out;
	Object[] engineCmds;
	String[] outputCmds;
	int e;
	int o;

	
	protected void setUp() throws Exception {
		gtp = new GoTextProtocolImpl();
		engine = new MockEngine();
		gtp.setEngine(engine);
		
		out = new ByteArrayOutputStream();
	}

	protected void tearDown() throws Exception {
		gtp = null;
		engine = null;
		in = null;
		out = null;
		engineCmds = null;
		outputCmds = null;
		e = 0;
		o = 0;
	}
	
	private void runWithInput(String instr) {
		in = new ByteArrayInputStream(instr.getBytes());
		gtp.setStreams(in, out);
		gtp.run();
		engineCmds = engine.getHistory().toArray();
		e = 0;
		String outputString = out.toString();
		outputString = outputString.replaceAll("\n\n", "|");
		assertTrue(outputString.indexOf('\n') != 0); // All GTP Replies should be double \n "\n\n".
		outputCmds = outputString.split("\\|");
		o = 0;
	}

	public void testQuit() {
		runWithInput ("quit\n");
		assertEquals(1, engine.getHistory().size());
		assertEquals("finish()", engineCmds[0] );
	}
	
	public void testProtocolVersion() {
		runWithInput("protocol_version\n" +
					"quit\n");
		assertEquals(1, engineCmds.length);
		assertEquals("finish()", engineCmds[0]);
	}

	public void testEmptyInput() {
		runWithInput("");
		assertEquals(1, engineCmds.length);
		assertEquals("finish()", engineCmds[0]);
	}
	
	public void testInvalidCommand() {
		runWithInput("this_is_an_invalid_command\n");
		assertTrue(outputCmds[0].startsWith("? "));
	}
	
	public void testNewLineSeparator() {
		runWithInput("\n\n\nname\n" +
					 "name\n" +
					 "name\n\r\r\r\r\r" +
					 "name\r\n"+
					 "name\n\r\r\r\r\r\r\r\n\r\r\r\n");
		System.out.println(out);
		assertEquals(6, engineCmds.length); // 5 names + 1 finish
		assertEquals("getName()", engineCmds[e++]);
		assertEquals("getName()", engineCmds[e++]);
		assertEquals("getName()", engineCmds[e++]);
		assertEquals("getName()", engineCmds[e++]);
		assertEquals("getName()", engineCmds[e++]);
		assertEquals("finish()", engineCmds[e++]);
	}
	
	public void testBasicSetup() {
		runWithInput("protocol_version\n" +
				"name\n");
		// protocol_version
		assertEquals("= 2", outputCmds[o++]);
		// name
		assertEquals("getName()", engineCmds[e++]);
		assertEquals("= MockEngine", outputCmds[o++]);		
		// finish
		assertEquals("finish()", engineCmds[e++]);
	}
	
	public void testGenMoveReturnsNullIsResign() {
		runWithInput("genmove\n");
		assertEquals("= resign", outputCmds[o++]);
	}
	

}
