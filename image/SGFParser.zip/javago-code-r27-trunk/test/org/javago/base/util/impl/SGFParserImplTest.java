/*
 * Copyright (C) 2006,2007 Eduardo Sabbatella Riccardi
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * Email: esabb <at> users.sourceforge.net
 */

package org.javago.base.util.impl;

import org.javago.base.GameTree;
import org.javago.base.util.SGFParser;
import junit.framework.TestCase;

public class SGFParserImplTest extends TestCase {
	
	SGFParser p;
	GameTree gt;
	
	protected void setUp() throws Exception {
		p = new SGFParserImpl();
		gt = null;
	}

	protected void tearDown() throws Exception {
		p = null;
		gt = null;
	}

	public void testEmptyData() {
		gt = p.parse("");
		assertNull(gt);
	}
	
	public void testNullData() {
		gt = p.parse((String)null);
		assertNull(gt);
	}
	
	public void testCRLFHandledOk() {
		// at the end of the file also!
		gt = p.parse("(;GM[1]\n\rC[ok]\nAP[esabbhandmadeeditor])\n");
		assertNotNull(gt);
		assertEquals("ok",gt.getGameComment());
	}

	public void testSpacesInBeginningAndEnd() {
		// at the end of the file also!
		gt = p.parse(" \n  \n  (;GM[1]\n\rC[ok]\nAP[esabbhandmadeeditor]) \n  \n  ");
		assertNotNull(gt);
		assertEquals("ok",gt.getGameComment());
	}

	public void testCommentsCanContainHookIfEscapedCorrectly() {
		gt = p.parse("(;GM[1]C[olala\\]fdfdk])");
		assertNotNull(gt);
		assertEquals("olala\\]fdfdk",gt.getGameComment());
	}
	
	public void testSetupValues() {
		gt = p.parse("(;GM[1]FF[4]CA[UTF-8]AP[CGoban:2]ST[2]RU[Japanese]SZ[19]KM[5.50]" +
				"PW[Player White]PB[Player Black]C[Game Comment])");
		assertEquals(gt.getBlackName(), "Player Black");
		assertEquals(gt.getWhiteName(), "Player White");
		assertEquals(gt.getGameComment(), "Game Comment");
		assertEquals(gt.getBoardSize(), 19);
		assertEquals(gt.getKomi(), 5.5f);
		assertTrue(gt.last());
	}
	
	public void testJustOneMove() {
		gt = p.parse("(;GM[1]FF[4]CA[UTF-8]AP[CGoban:2]ST[2]RU[Japanese]SZ[19]KM[5.50]" +
				"PW[player White]PB[Player Black]C[Game Comment]"+
				";B[dp]CR[dp])");	
		gt.next();
		assertEquals("B D4", gt.getMove().toString());
	}
	
	public void test10MovesWithComments() {
		gt = p.parse("(;GM[1]FF[4]CA[UTF-8]AP[CGoban:2]ST[2]\n" +
				"RU[Japanese]SZ[13]KM[5.50]\n" +
				"PW[blanquito]PB[negrito]\n" +
				";B[dj]CR[dj]\n" +
				";W[jd]CR[jd]\n" +
				";B[jj]CR[jj]C[three]\n" +
				";W[dd]CR[dd]\n" +
				";B[cc]CR[cc]\n" +
				";W[dc]CR[dc]C[Commenting sixth move]\n" +
				";B[cd]CR[cd]\n" +
				";W[ce]CR[ce]\n" +
				";B[be]CR[be]\n" +
				";W[cf]CR[cf])");
		
		gt.next(); // 1
		assertEquals("B D4", gt.getMove().toString());
		gt.next(); // 2
		assertEquals("W K10", gt.getMove().toString());
		gt.next(); // 3
		assertEquals("B K4", gt.getMove().toString());
		assertEquals("three", gt.getComment());
		gt.next(); // 4
		assertEquals("W D10", gt.getMove().toString());
		gt.next(); // 5
		assertEquals("B C11", gt.getMove().toString());
		gt.next(); // 6
		assertEquals("W D11", gt.getMove().toString());
		assertEquals("Commenting sixth move", gt.getComment());
		gt.next(); // 7
		assertEquals("B C10", gt.getMove().toString());
		gt.next(); // 8
		assertEquals("W C9", gt.getMove().toString());
		gt.next(); // 9
		assertEquals("B B9", gt.getMove().toString());
		gt.next(); // 10
		assertEquals("W C8", gt.getMove().toString());
		assertTrue(gt.last());
	}
	
	public void testThreeRootNodes() {
		gt = p.parse("(;GM[1]FF[4]CA[UTF-8]AP[CGoban:2]ST[2]\n" +
				"RU[Japanese]SZ[9]KM[5.50]\n" +
				"PW[blanquito]PB[negrito]\n" +
				"(;B[bh]CR[bh])\n" +
				"(;B[ci]CR[ci])\n" +
				"(;B[ag]CR[ag]))");
		
		assertEquals(3, gt.variantsInThisNode());
		gt.next(0);
		assertEquals("B B2",gt.getMove().toString());
		gt.prev();
		gt.next(1);
		assertEquals("B C1",gt.getMove().toString());
		gt.prev();
		gt.next(2);
		assertEquals("B A3",gt.getMove().toString());
	}
	
	public void testPassMove() {
		gt = p.parse("(;GM[1]FF[4]CA[UTF-8]AP[CGoban:2]ST[2]\n" +
				"RU[Japanese]SZ[13]KM[5.50]\n" +
				"PW[blanquito]PB[negrito]\n" +
				";B[tt]CR[tt]\n" +
				";W[]CR[]\n)");
		gt.next();
		assertEquals("B PASS", gt.getMove().toString());
		gt.next();
		assertEquals("W PASS", gt.getMove().toString());
	}

	public void testWrite() {
		String sgfOrig = "(;GM[1]FF[4]CA[UTF-8]AP[CGoban:2]ST[2]RU[Japanese]SZ[19]KM[5.5]" +
				"PW[Player White]PB[Player Black]C[Game Comment]\n)\n"; 
		gt = p.parse(sgfOrig);
		String sgfWritten = p.write(gt);
		assertEquals(sgfOrig, sgfWritten);
	}
	
	public void testWriterCompler() {
		String sgfOrig = "(;GM[1]FF[4]CA[UTF-8]AP[CGoban:2]ST[2]RU[Japanese]SZ[19]KM[5.5]PW[blanquito]PB[negrito]\n"+
						";B[dp]\n"+
						"(;W[gp])\n"+
						"(;W[dm]C[COMMENT])\n"+
						"(;W[fn]))\n";
		gt = p.parse(sgfOrig);
		String sgfWritten = p.write(gt);
		assertEquals(sgfOrig, sgfWritten);
	}
}
