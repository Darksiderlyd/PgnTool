/*
 * Copyright (C) 2006,2007 Eduardo Sabbatella Riccardi
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * Email: esabb <at> users.sourceforge.net
 */

package org.javago.base.util.impl;

import org.javago.base.Board;
import org.javago.base.impl.BoardImpl;
import org.javago.base.util.BoardUtil;
import junit.framework.TestCase;

public class BoardUtilImplTest extends TestCase {
	
	int size;
	BoardUtil bu;
	Board board;
	
	protected void setUp() throws Exception {
		size = 19;
		bu = BoardUtilImpl.getInstance();
		board = new BoardImpl(size);
	}
	
	protected void tearDown() throws Exception {
		size = -1;
		bu = null;
		board = null;
	}
	
	public void testFlipHorizontal() {
		board.set(0, 0, Board.BLACK);
		board.set(0, 18, Board.WHITE);
		board.set(1, 1, Board.BLACK);
		bu.flipHorizontal(board);
		assertEquals(board.get(0,0), Board.WHITE);
		assertEquals(board.get(0,18), Board.BLACK);
		assertEquals(board.get(1,17), Board.BLACK);
		assertEquals(board.get(1,1), Board.EMPTY);
	}
	
	public void testFlipFlipHorizontalEndsSameHash() {
		// XXX: THE FOLLOWING TEST SHOULD NOT EXIST, AS HASH SHOULD BE TESTED BY ITS OWNS TESTS.
		board.set(0, 0, Board.BLACK);
		board.set(0, 18, Board.WHITE);
		board.set(1, 1, Board.BLACK);
		long origHash = board.getHash();
		bu.flipHorizontal(board);
		bu.flipHorizontal(board);
		assertEquals(origHash, board.getHash());
	}
	
	public void testFlipVertical() {
		board.set(0,0, Board.BLACK);
		board.set(18,0, Board.WHITE);
		board.set(9,9, Board.WHITE);
		bu.flipVertical(board);
		assertEquals(board.get(18,0), Board.BLACK);
		assertEquals(board.get(0,0), Board.WHITE);
		assertEquals(board.get(9,9), Board.WHITE);
	}
	
	public void testFlipFlipVerticalEndsSameHash() {
		// XXX: THE FOLLOWING TEST SHOULD NOT EXIST, AS HASH SHOULD BE TESTED BY ITS OWNS TESTS.
		board.set(0, 0, Board.BLACK);
		board.set(0, 18, Board.WHITE);
		board.set(1, 1, Board.BLACK);
		long origHash = board.getHash();
		bu.flipVertical(board);
		bu.flipVertical(board);
		assertEquals(origHash, board.getHash());
	}
	
	public void testRotateClockwise() {
		board.set(0,0, Board.BLACK);
		board.set(9,9, Board.WHITE);
		board.set(1,1, Board.WHITE);
		bu.rotateClockwise(board);
		assertEquals(board.get(0,0),  Board.EMPTY);
		assertEquals(board.get(18,0), Board.BLACK);
		assertEquals(board.get(9,9), Board.WHITE);
		assertEquals(board.get(1,1), Board.EMPTY);
		assertEquals(board.get(17,1), Board.WHITE);
	}
	
	public void testRotateClockwiseFourTimesEndsSameHash() {
		// XXX: THE FOLLOWING TEST SHOULD NOT EXIST, AS HASH SHOULD BE TESTED BY ITS OWNS TESTS.
		board.set(0, 0, Board.BLACK);
		board.set(0, 18, Board.WHITE);
		board.set(1, 1, Board.BLACK);
		long origHash = board.getHash();
		bu.rotateClockwise(board);
		bu.rotateClockwise(board);
		bu.rotateClockwise(board);
		bu.rotateClockwise(board);
		assertEquals(origHash, board.getHash());
	}
	
	public void testInvert() {
		board.set("A1", Board.BLACK);
		board.set("A2", Board.WHITE);
		board.set("I5", Board.BLACK);
		bu.invert(board);
		assertEquals(board.get("A1"), Board.WHITE);
		assertEquals(board.get("A2"), Board.BLACK);
		assertEquals(board.get("I5"), Board.WHITE);
		assertEquals(board.get("B1"), Board.EMPTY);
	}
	
	public void testAllFlipInvertCombinationsSize() {
		Board[] combs = bu.allFlipInvertCombinations(board);
		assertEquals(combs.length, 16);		
	}
	
	public void testAllFlipInvertCombinationsNotNull() {
		Board[] combs = bu.allFlipInvertCombinations(board);
		for (int i=0; i<combs.length; i++) {
			assertNotNull(combs[i]);
		}
	}

	public void testAllFlipInvertCombinationsAllDifferent() {
		board.set("B1", Board.BLACK);
		board.set("B2", Board.BLACK);	
		board.set("C2", Board.WHITE);
		Board[] combs = bu.allFlipInvertCombinations(board);
		for (int a=0; a<combs.length; a++) {
			for (int b=a+1; b<combs.length; b++) {
				assertTrue(combs[a] != combs[b]);
				assertTrue(combs[a].getHash() != combs[b].getHash());
			}
		}
	}
	
	public void testAllUniqueFlipInvertCombinationsSize() {
		board.set("A1", Board.BLACK);
		Board[] combs = bu.allUniqueFlipInvertCombinations(board);
		assertEquals(combs.length, 8);
	}

	public void testEye1_IsolatedEmptySpaceIsNotEye() {
		assertEquals(Board.INVALID, bu.isEye(board, size*size/2));
	}

	public void testEye2_DiagonalIsNotEyeAtAll() {
		board.set("A2", Board.BLACK);
		board.set("B1", Board.BLACK);
		assertEquals(Board.INVALID, bu.isEye(board, board.convertToP(0,0)));
	}

	public void testEye3_SmallestEye() {
		board.set("A2", Board.WHITE);
		board.set("B1", Board.WHITE);
		board.set("B2", Board.WHITE);
		assertEquals(Board.WHITE, bu.isEye(board, board.convertToP(0,0)));
	}

	public void testEye4_CompleteEye() {
		board.set("A1", Board.BLACK);
		board.set("A2", Board.BLACK);
		board.set("A3", Board.BLACK);
		board.set("B1", Board.BLACK);
		//B2
		board.set("B3", Board.BLACK);
		board.set("C1", Board.BLACK);
		board.set("C2", Board.BLACK);
		board.set("C3", Board.BLACK);
		assertEquals(Board.BLACK, bu.isEye(board, board.convertToP(1,1)));
	}

	public void testEye5_CompleteEyeWithoutOneDiagonal() {
		board.set("A1", Board.BLACK);
		board.set("A2", Board.BLACK);
		board.set("A3", Board.BLACK);
		board.set("B1", Board.BLACK);
		//B2
		board.set("B3", Board.BLACK);
		board.set("C1", Board.BLACK);
		board.set("C2", Board.BLACK);
		//C3
		assertEquals(Board.BLACK, bu.isEye(board, board.convertToP(1,1)));
	}

	public void testEye5_NotEyeWithoutTwoDiagonal() {
		board.set("A1", Board.BLACK);
		board.set("A2", Board.BLACK);
		board.set("A3", Board.BLACK);
		board.set("B1", Board.BLACK);
		//B2
		board.set("B3", Board.BLACK);
		//C1
		board.set("C2", Board.BLACK);
		//C3
		assertEquals(Board.INVALID, bu.isEye(board, board.convertToP(1,1)));
	}


	
	
	
}
