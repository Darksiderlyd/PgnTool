/*
 * Copyright (C) 2006,2007 Eduardo Sabbatella Riccardi
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * Email: esabb <at> users.sourceforge.net
 */

package org.javago.base.util.impl;

import org.javago.base.Board;
import org.javago.base.Game;
import org.javago.base.impl.GameImpl;
import org.javago.base.util.GameHelper;
import org.javago.base.util.impl.GameHelperImpl;
import junit.framework.TestCase;

public class GameHelperImplTest extends TestCase {
	
	Game game;
	GameHelper gh;
	int boardSize;
	int maxValidMoves;
	
	protected void setUp() throws Exception {
		boardSize = 19;
		maxValidMoves = (boardSize*boardSize)+1;	// all board positions plus pass
		game = new GameImpl(boardSize);
		gh = new GameHelperImpl();
	}
	
	protected void tearDown() throws Exception {
		game = null;
		gh = null;
		boardSize = 0;
		maxValidMoves = 0;
	}
	
	private void checkNonDuplicatedEntries(int[] entries) {
		int[] matrix = new int[ maxValidMoves ];
		for (int i=0; i<entries.length; i++)
			matrix[ entries[i] ]++;
	
		for (int i=0; i<matrix.length; i++)
			assertTrue( matrix[i]<=1 );
	}
	
	private void checkPnotIn(int[] entries, int P) {
		for (int i=0; i<entries.length; i++)
			assertTrue( entries[i] != P );
	}
	
	public void testEmptyGame() {
		int res[] = gh.getValidMoves(game);
		assertEquals(maxValidMoves, res.length);
		checkNonDuplicatedEntries(res);
	}
	
	public void testOneMoveGame() {
		game.play("BLACK A1");
		int res[] = gh.getValidMoves(game);
		assertEquals(maxValidMoves-1, res.length);
		checkNonDuplicatedEntries(res);
	}
	
	public void testThreeMovesGameWithInvalidMove() {
		game.play("BLACK A2");
		game.play("WHITE F2");
		game.play("BLACK B1"); // A1 is not valid
		int res[] = gh.getValidMoves(game);
		assertEquals(maxValidMoves-3-1, res.length);
		checkNonDuplicatedEntries(res);
		checkPnotIn(res, 0); // A1 is not valid move
	}

	
	public void testVeryBasicChineseGame() {
		int res[] = gh.getChineseScore(game);
		assertEquals(0,res[Board.BLACK]);
		assertEquals(0,res[Board.WHITE]);
		assertEquals(boardSize*boardSize, res[Board.EMPTY]);
	}
	
	public void testVeryBasicChineseGame2() {
		game.play("BLACK A2");
		game.play("WHITE F2");
		game.play("BLACK B1");
		int res[] = gh.getChineseScore(game);
		assertEquals(3,res[Board.BLACK]);
		assertEquals(1,res[Board.WHITE]);		
		assertEquals( (boardSize*boardSize)-4, res[Board.EMPTY]);
		// 3 stones are not empty
	}

	
	public void testVeryBasicChineseGame3() {
		game.play("BLACK A2");
		game.play("WHITE F2");
		game.play("BLACK B1");
		game.play("WHITE F3");
		game.play("BLACK B2");
		int res[] = gh.getChineseScore(game);
		assertEquals(4,res[Board.BLACK]);
		assertEquals(2,res[Board.WHITE]);
		assertEquals( (boardSize*boardSize)-4-2 , res[Board.EMPTY]);
	}
	
	
}
