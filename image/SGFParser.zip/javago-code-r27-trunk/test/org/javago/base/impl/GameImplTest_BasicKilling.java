/*
 * Copyright (C) 2006,2007 Eduardo Sabbatella Riccardi
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * Email: esabb <at> users.sourceforge.net
 */

package org.javago.base.impl;

import junit.framework.TestCase;
import org.javago.base.Board;
import org.javago.base.Game;
import org.javago.base.Move;


public class GameImplTest_BasicKilling extends TestCase {

	Game game;
	Move move;
	int size;

	public void setUp() throws Exception {
		size = 19;
		game = new GameImpl(19);
	}

	public void tearDown() throws Exception {
		size = -1;
		game = null;
	}
	
	public void testZeroDeads() {
		assertEquals(0, game.getDeadStones(Board.WHITE));
		assertEquals(0, game.getDeadStones(Board.BLACK));		
	}
	
	public void testSimplestKill() {
		game.play("b b1");
		game.play("w a1");
		game.play("b a2");
		assertTrue(game.getBoard().get("a1") == Board.EMPTY);
		assertEquals(1, game.getDeadStones(Board.WHITE));
	}

	public void testSimplestKill2() {
		/*
		 *  ABCDEFGHIJKLMNOPQRS
		 * 1...................1
		 * 2...................2
		 * 3...................3
		 * 4...................4
		 * 5...................5
		 * 6...................6
		 * 7...................7
		 * 8...X....OO.........8
		 * 9...X...O..O........9
		 * 0...X...O..O........0
		 * 1...X....OO.........1
		 * 2...................2
		 * 3...................3
		 * 4...................4
		 * 5...................5
		 * 6...................6
		 * 7...................7
		 * 8...................8
		 * 9...................9
		 * ABCDEFGHIJKLMNOPQRS
		 */
		game.play("b k10");
		game.play("w l10");
		game.play("b k9");
		game.play("w l9");
		game.play("b j10");
		game.play("w k11");
		game.play("b j9");
		game.play("w j11");
		game.play("b d10");
		game.play("w h10");
		game.play("b d9");
		game.play("w h9");
		game.play("b d8");
		game.play("w j8");
		game.play("b d11");
		game.play("w k8");
//		System.out.println( game.getBoard().toString());
		assertTrue(game.getBoard().get("k10") == Board.EMPTY);
		assertTrue(game.getBoard().get("j9") == Board.EMPTY);
		assertTrue(game.getBoard().get("j10") == Board.EMPTY);
		assertTrue(game.getBoard().get("k9") == Board.EMPTY);
		assertEquals(0,game.getDeadStones(Board.WHITE));
		assertEquals(4,game.getDeadStones(Board.BLACK));
	}

	public void testSimplestKillThenDobleKill() {
		game.play("b k10");
		game.play("w l10");
		game.play("b k9");
		game.play("w l9");
		game.play("b j10");
		game.play("w k11");
		game.play("b j9");
		game.play("w j11");
		game.play("b d10");
		game.play("w h10");
		game.play("b d9");
		game.play("w h9");
		game.play("b d8");
		game.play("w j8");
		game.play("b d11");
		game.play("w k8");  // eat 4
		game.play("b k10");
		game.play("w j10");
		game.play("b j9");
		game.play("w k9"); // eats 2 different groups
		assertTrue(game.getBoard().get("k10") == Board.EMPTY);
		assertTrue(game.getBoard().get("j9") == Board.EMPTY);
		assertTrue(game.getBoard().get("j10") == Board.WHITE);
		assertTrue(game.getBoard().get("k9") == Board.WHITE);
	}
	
	public void testBasicKO() {
		/*
		 *  5 . . . . . . . . .
		 *  4 . . . + . . . . . 
		 *  3 X X . . . . . . . 
		 *  2 . X . . . . . . .  
		 *  1(X)O O O . . . . . 
		 *    A B C D E F G H J   
		 */
		assertTrue( game.play("b a1") );
		assertTrue( game.play("w b1") );
		assertTrue( game.play("b a3") );
		assertTrue( game.play("w c1") );
		assertTrue( game.play("b b2") );
		assertTrue( game.play("w a2") );  // eat, valid.
		assertFalse(game.isValidMove("b a1")); // invalid.
		assertTrue( game.play("b b3") );
		assertTrue( game.isValidMove("w a1")); // white can finish ko
		assertTrue( game.play("w d1") );
		assertTrue( game.play("b a1")); // now black can eat again
		assertFalse(game.play("w a2")); // and white can´t eat at A2 because its a KO
	}

}
