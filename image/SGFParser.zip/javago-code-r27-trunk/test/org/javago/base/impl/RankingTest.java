/*
 * Copyright (C) 2006,2007 Eduardo Sabbatella Riccardi
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * Email: esabb <at> users.sourceforge.net
 */

package org.javago.base.impl;

import org.javago.base.Ranking;
import junit.framework.TestCase;

public class RankingTest extends TestCase {
	
	Ranking r;
	Ranking r2;
	
	protected void setUp() throws Exception {
		r = null;
		r2 = null;
	}
	
	protected void tearDown() throws Exception {
		r = null; 
		r2 = null;
	}
	
	public void testBasicConstructor() {
		r = new RankingImpl(Ranking.DAN, 9);
		assertEquals( r.getRankType(), Ranking.DAN );
		assertEquals( r.getRankNo(), 9 );
	}
	
	public void testInvalidRankingNumber() {
		r = new RankingImpl(Ranking.DAN, 10);
		assertFalse(r.isValid());
		r = new RankingImpl(Ranking.DAN, 0);
		assertFalse(r.isValid());
		r = new RankingImpl(Ranking.PRO, 12);
		assertFalse(r.isValid());
		r = new RankingImpl(Ranking.PRO, -1);
		assertFalse(r.isValid());
		r = new RankingImpl(Ranking.KYU, 40);
		assertFalse(r.isValid());
		r = new RankingImpl(Ranking.KYU, 0);
		assertFalse(r.isValid());
	}
	
	public void testValidRanking() {
		r = new RankingImpl(Ranking.KYU, 10);
		assertTrue(r.isValid());
	}
	
	public void testCompareEqualsKYUs() {
		r = new RankingImpl(Ranking.KYU, 20);
		r2 = new RankingImpl(Ranking.KYU, 20);	
		assertTrue( ((RankingImpl)r).compareTo(r2) == 0 );
	}
	
	public void testCompareDifferentRanks() {
		r = new RankingImpl(Ranking.KYU, 20);
		r2 = new RankingImpl(Ranking.KYU, 21);	
		Ranking r3 = new RankingImpl(Ranking.DAN, 5);
		Ranking r4 = new RankingImpl(Ranking.PRO, 9);
		
		assertTrue( ((RankingImpl)r).compareTo(r2) > 0);
		assertTrue( ((RankingImpl)r2).compareTo(r3) < 0);
		assertTrue( ((RankingImpl)r3).compareTo(r4) < 0);
		assertTrue( ((RankingImpl)r4).compareTo(r) > 0);	
	}
	
	public void testStonesDifference() {
		r = new RankingImpl(Ranking.KYU, 20);
		r2 = new RankingImpl(Ranking.KYU, 21);	
		Ranking r3 = new RankingImpl(Ranking.DAN, 5);
		Ranking r4 = new RankingImpl(Ranking.PRO, 9);

		assertTrue (r.stones() == 10);
		assertTrue (r2.stones() == 9);
		assertTrue (r3.stones() == 30 + 5);
		assertTrue (r4.stones() == 30 + 6 + 9);
	}

	
	// make tests on isValid(int, int)

}
