/*
 * Copyright (C) 2006,2007 Eduardo Sabbatella Riccardi
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * Email: esabb <at> users.sourceforge.net
 */

package org.javago.base.impl;

import junit.framework.TestCase;
import org.javago.base.Board;
import org.javago.base.Move;


public class MoveImplTest extends TestCase {
	
	public void testPass() {
		Move m = new MoveImpl(Board.WHITE);
		assertTrue(m.isPass());
		assertTrue(m.getPlayer() == Board.WHITE);
		assertTrue(m.getX() == Board.INVALID);
		assertTrue(m.getY() == Board.INVALID);
	}

	public void testMove() {
		Move m = new MoveImpl(3,15,Board.WHITE);
		assertFalse(m.isPass());
		assertTrue(m.getPlayer() == Board.WHITE);
		assertTrue(m.getX() == 3);
		assertTrue(m.getY() == 15);
	}
	
	public void testFromStringPass() {
		Move m = MoveImpl.fromString("white pass");
		assertTrue(m.getPlayer() == Board.WHITE);
		assertTrue(m.isPass() );
	}
	
	public void testFromStringWhiteC10() {
		Move m = MoveImpl.fromString("White C10");
		assertTrue( m.getPlayer() == Board.WHITE);
		assertTrue( m.getX() == 2);
		assertTrue( m.getY() == 9);
		assertFalse( m.isPass() );
	}

	public void testFromStringBlackE4() {
		Move m = MoveImpl.fromString("black e4");
		assertTrue( m.getPlayer() == Board.BLACK);
		assertTrue( m.getX() == 4);
		assertTrue( m.getY() == 3);
		assertFalse( m.isPass() );
	}
	
	public void testFromStringInvalid() {
		Move m = MoveImpl.fromString("");
		assertTrue(m==null);
		
		m = MoveImpl.fromString("Black");		
		assertTrue(m==null);

		m = MoveImpl.fromString(" B10");		
		assertTrue(m==null);
	}
	
	public void testMoveToString() {
		Move m = MoveImpl.fromString("B E4");
		assertEquals("B E4", m.toString());
	}

	public void testMoveToStringPass() {
		Move m = MoveImpl.fromString("white pass");
		assertEquals("W PASS", m.toString());
	}
	
}
