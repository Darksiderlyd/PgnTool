/*
 * Copyright (C) 2006,2007 Eduardo Sabbatella Riccardi
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * Email: esabb <at> users.sourceforge.net
 */

package org.javago.base.impl;

import java.io.FileNotFoundException;
import java.io.FileReader;

import org.javago.base.Game;
import org.javago.base.GameTree;
import org.javago.base.util.SGFParser;
import org.javago.base.util.impl.SGFParserImpl;
import junit.framework.TestCase;

public class GameImplTest_GameRegression extends TestCase {
	
	SGFParser sgfp;
	GameTree gt;
	Game game;
	
	protected void setUp() throws Exception {
		sgfp = new SGFParserImpl();
	}
	
	protected void tearDown() throws Exception {
		gt = null;
		game = null;
	}
	
	public void testReplay_6000() throws FileNotFoundException {
		gt = sgfp.parse( new FileReader("data/tests/6000.sgf"));
		game = new GameImpl(gt.getBoardSize());
		gt.next();
		
		while (!gt.last()) {
//			System.out.println(gt.moveNo() + ": " + gt.getMove());
			assertTrue ( game.isValidMove(gt.getMove()) );
			game.play( gt.getMove() );
			gt.next();
		}
		game.play( gt.getMove() );
//		System.out.println(game.getBoard().toString());
	}
	
	public void testReplay_6016() throws FileNotFoundException {
		gt = sgfp.parse( new FileReader("data/tests/6016.sgf"));
		game = new GameImpl(gt.getBoardSize());
		gt.next();
		
		while (!gt.last()) {
//			System.out.println(gt.moveNo() + ": " + gt.getMove());
			assertTrue ( game.isValidMove(gt.getMove()) );
			game.play( gt.getMove() );
			gt.next();
		}
		game.play( gt.getMove() );
//		System.out.println(game.getBoard().toString());
	}

	public void testReplay_6039() throws FileNotFoundException {
		gt = sgfp.parse( new FileReader("data/tests/6039.sgf"));
		game = new GameImpl(gt.getBoardSize());
		gt.next();
		
		while (!gt.last()) {
//			System.out.println(gt.moveNo() + ": " + gt.getMove());
			assertTrue ( game.isValidMove(gt.getMove()) );
			game.play( gt.getMove() );
			gt.next();
		}
		game.play( gt.getMove() );
//		System.out.println(game.getBoard().toString());
	}

	public void testReplay_tango9_vs_tommy2626() throws FileNotFoundException {
		gt = sgfp.parse( new FileReader("data/tests/tango9-tommy2626_W-C2_is_invalid.sgf"));
		game = new GameImpl(gt.getBoardSize());
		gt.next();
		while(!gt.last()) {
			assertTrue( game.isValidMove(gt.getMove()));
			game.play( gt.getMove() );
			gt.next();
		}
		game.play( gt.getMove() );
		assertFalse( game.isValidMove("W C2") );
	}
}
