/*
 * Copyright (C) 2006,2007 Eduardo Sabbatella Riccardi
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * Email: esabb <at> users.sourceforge.net
 */

package org.javago.base.impl;

import org.javago.base.GameTree;
import junit.framework.TestCase;

public class GameTreeImplTest extends TestCase {

	GameTree gt;
	
	protected void setUp() throws Exception {
		gt = new GameTreeImpl();
	}
	
	protected void tearDown() throws Exception {
		gt = null;
	}
	
	public void testSetBlackName() {
		gt.setBlackName("blackname");
		assertEquals("blackname", gt.getBlackName());
	}
	
	public void testEmptyBlackName() {
		assertEquals(null, gt.getBlackName());
	}

	public void testSetWhiteName() {
		gt.setWhiteName("whitename");
		assertEquals("whitename", gt.getWhiteName());
	}

	public void testEmptyWhiteName() {
		assertEquals(null, gt.getWhiteName());
	}
	
	public void testSetBoardSize() {
		gt.setBoardSize(11);
		assertEquals(11, gt.getBoardSize());
	}
	
	public void testInvalidBoardSize() {
		gt.setBoardSize(-1);
		assertFalse(gt.getBoardSize() == -1);
	}
	
	public void testSetHandicap() {
		gt.setHandicapStones(9);
		assertEquals(9, gt.getHandicapStones());
	}
	
	public void testInvalidHandicap() {
		gt.setHandicapStones(10);
		assertFalse(gt.getHandicapStones() == 10);
		gt.setHandicapStones(-1);
		assertFalse(gt.getHandicapStones() == -1);		
	}
	
	public void testDefaultHandicap() {
		assertEquals(0, gt.getHandicapStones());
	}
	
	public void testSetKomi() {
		gt.setKomi(6.5f);
		assertEquals(6.5f, gt.getKomi());
	}
	
	public void testInvalidKomi() {
		gt.setKomi(2.1f);
		assertFalse(gt.getKomi() == 2.1f);
		gt.setKomi(-1.0f);
		assertFalse(gt.getKomi() == -1.0f);
	}

	
	public void testOneMoveEvenInvalid() {
		gt.addMove( MoveImpl.fromString("white B1"));
		assertEquals("W B1", gt.getMove().toString());
		assertTrue (gt.moveNo() == 1);
		assertTrue (gt.variantsInThisNode() == 0);
		assertTrue (gt.last());
	}
	
	public void testOneMoveThenBack() {
		gt.addMove( MoveImpl.fromString("B D4"));
		gt.prev();
		assertTrue(gt.moveNo() == 0);
		assertFalse(gt.last());
		assertTrue(gt.variantsInThisNode() == 1);
	}
	
	public void testOneMoveThenRewind() {
		gt.addMove("B D4");
		gt.rewind();
		assertTrue(gt.moveNo() == 0);
		assertFalse(gt.last());
		assertTrue(gt.variantsInThisNode() == 1);
	}

	public void testTwoRootMovesThenRewind() {
		gt.addMove("B D4");
		gt.prev();
		gt.addMove("B D3");
		gt.rewind();
		assertTrue(gt.moveNo() == 0);
		assertFalse(gt.last());
		assertTrue(gt.variantsInThisNode() == 2);
	}
	
	public void testOneMoveWithTwoSubMoves() {
		gt.addMove(MoveImpl.fromString("B A1"));
		gt.addMove(MoveImpl.fromString("W B2"));
		gt.prev();
		gt.addMove(MoveImpl.fromString("W C3"));
		gt.prev();
		assertTrue( gt.variantsInThisNode() == 2 );
	}
	
	public void testTwoRootMoves() {
		gt.addMove("B A1");
		gt.prev();
		gt.addMove("B A2");
		gt.prev();
		assertTrue( gt.variantsInThisNode() == 2);
	}
	
	public void testIssuePrevEmptyTree() {
		assertFalse (gt.prev());
	}
	
	public void testNextEmptyTree() {
		assertFalse (gt.next());
	}
	
	public void testNextInTwoRootVariants() {
		gt.addMove("B A1");
		gt.prev();
		gt.addMove("W A1");
		gt.prev();
		gt.next(); 
		assertEquals("B A1", gt.getMove().toString());		
	}

	public void testNextNoDefaultInTwoRootVariants() {
		gt.addMove("B A1");
		gt.prev();
		gt.addMove("W A1");
		gt.prev();
		gt.next(1); 
		assertEquals("W A1", gt.getMove().toString());		
	}

	public void testNextInTwoNonRootVariants() {
		gt.addMove("B C3");
		gt.addMove("B A1");
		gt.prev();
		gt.addMove("W A1");
		gt.prev();
		gt.next(); 
		assertEquals("B A1", gt.getMove().toString());		
	}

	public void testNextNoDefaultInTwoNonRootVariants() {
		gt.addMove("B C3");
		gt.addMove("B A1");
		gt.prev();
		gt.addMove("W A1");
		gt.prev();
		gt.next(1); 
		assertEquals("W A1", gt.getMove().toString());		
	}
	
	public void test5MovesCount() {
		gt.addMove("B C1");
		gt.addMove("B C2");
		gt.addMove("B C3");
		gt.addMove("B C4");
		gt.addMove("B C5");
		assertEquals(gt.moveNo(), 5);		
	}
	
	public void testLastIncludingInNewSubtree() {
		assertTrue(gt.last());
		gt.addMove("B C1");
		gt.addMove("B C2");
		gt.addMove("B C3");
		gt.addMove("B C4");
		gt.prev();
		assertFalse(gt.last());
		gt.next();
		assertTrue(gt.last());
		gt.prev();
		gt.addMove("W C4");
		assertTrue(gt.last());
	}
	
	public void testCommentNoNode() {
		gt.setComment("commenting before any move");
		assertTrue (gt.getComment() == null);
	}

	public void testCommentNode() {
		gt.addMove("B B2");
		gt.setComment("LALA");
		gt.prev();
		gt.next();
		assertEquals("LALA",gt.getComment());
	}
	
	public void testGameComment() {
		assertTrue (gt.getGameComment() == null);
		gt.setGameComment("comment");
		assertEquals("comment", gt.getGameComment());
	}
	
	public void testReadingMoveInRoot() {
		assertNull (gt.getMove());		
	}
	

}
