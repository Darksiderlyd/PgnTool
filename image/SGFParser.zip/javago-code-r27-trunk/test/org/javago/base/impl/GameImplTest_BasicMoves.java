/*
 * Copyright (C) 2006,2007 Eduardo Sabbatella Riccardi
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * Email: esabb <at> users.sourceforge.net
 */

package org.javago.base.impl;

import org.javago.base.Board;
import org.javago.base.Game;
import org.javago.base.Move;
import junit.framework.TestCase;


public class GameImplTest_BasicMoves extends TestCase {
	
	Game game;
	Move move;
	int size;
	
	protected void setUp() throws Exception {
		size = 19;
		game = new GameImpl(19);
	}
	
	protected void tearDown() throws Exception {
		size = -1;
		game = null;
	}
	
	
	public void testBasicSetup1() {
		game = new GameImpl(5);
		assertTrue(game.moveToPlay()==1);
		assertTrue(game.playerToPlay() == Board.BLACK);
		assertTrue(game.getHandicap() == 0);
		assertTrue(game.getBoard().getSize() == 5);
	}
	
	public void testBasicInvalidMove() {
		move = MoveImpl.fromString("white B10"); 
		assertFalse ( game.isValidMove(move) );
	}
	
	public void testBasicValidMove() {
		move = MoveImpl.fromString("black d4");
		assertTrue (game.isValidMove(move));
	}

	public void testSimpleMove() {
		move = MoveImpl.fromString("black d5");
		assertTrue (game.play(move));
		assertTrue (game.moveToPlay() == 2);
		assertTrue (game.playerToPlay()== Board.WHITE);
		assertTrue (game.getBoard().get(3,4) == Board.BLACK);
		assertFalse (game.finished());
	}
	
	public void testTwoSimpleMoves() {
		move = MoveImpl.fromString("black e4");
		game.play(move);
		move = MoveImpl.fromString("white j15");
		game.play(move);
		assertTrue (game.moveToPlay() == 3);
		assertTrue (game.playerToPlay() == Board.BLACK);
		assertTrue (game.getBoard().get(4,3) == Board.BLACK);
		assertTrue (game.getBoard().get(8,14) == Board.WHITE);
		assertFalse (game.finished());
	}

	public void testTwoMovesInSamePlace() {
		move = MoveImpl.fromString("black e4");
		game.play(move);
		
		move = MoveImpl.fromString("white e4");
		assertFalse (game.play(move));
	}
	
	public void testTwoMovesSecondInvalidPlayer() {
		game.play("black A3");
		assertFalse (game.play("black G5"));
	}

	public void testTwoMovesThirdInvalidPlayer() {
		game.play("black A3");
		game.play("white A6");
		assertFalse (game.play("white F2"));
	}
	
	public void testSimpleFinishGame() {
		game.play("black a1");
		game.play("white pass");
		game.play("black pass");
		assertTrue(game.finished());
	}

	public void testNotSoSimpleFinishGame() {
		game.play("black a1");
		game.play("white pass");
		game.play("black g10");
		game.play("white f10");
		game.play("black pass");
		game.play("white pass");
		assertTrue(game.finished());
	}
	
	public void testIsValidMove_complex1() {
		assertTrue(game.isValidMove("b k10"));	game.play("b k10");
		assertTrue(game.isValidMove("w l10"));	game.play("w l10");
		assertTrue(game.isValidMove("b k9"));	game.play("b k9");
		assertTrue(game.isValidMove("w l9"));	game.play("w l9");
		assertTrue(game.isValidMove("b j10"));	game.play("b j10");
		assertTrue(game.isValidMove("w k11"));	game.play("w k11");
		assertTrue(game.isValidMove("b j9"));	game.play("b j9");
		assertTrue(game.isValidMove("w j11"));	game.play("w j11");
		assertTrue(game.isValidMove("b d10"));	game.play("b d10");
		assertTrue(game.isValidMove("w h10"));	game.play("w h10");
		assertTrue(game.isValidMove("b d9"));	game.play("b d9");
		assertTrue(game.isValidMove("w h9"));	game.play("w h9");
		assertTrue(game.isValidMove("b d8"));	game.play("b d8");
		assertTrue(game.isValidMove("w j8"));	game.play("w j8");
		assertTrue(game.isValidMove("b d11"));	game.play("b d11");
		assertTrue(game.isValidMove("w k8"));	game.play("w k8");
	}
	
	public void testIsValidMove_complex2() {
		assertTrue(game.isValidMove("b k10"));	game.play("b k10");
		assertTrue(game.isValidMove("w l10"));	game.play("w l10");
		assertTrue(game.isValidMove("b k9"));	game.play("b k9");
		assertTrue(game.isValidMove("w l9"));	game.play("w l9");
		assertTrue(game.isValidMove("b j10"));	game.play("b j10");
		assertTrue(game.isValidMove("w k11"));	game.play("w k11");
		assertTrue(game.isValidMove("b j9"));	game.play("b j9");
		assertTrue(game.isValidMove("w j11"));	game.play("w j11");
		assertTrue(game.isValidMove("b d10"));	game.play("b d10");
		assertTrue(game.isValidMove("w h10"));	game.play("w h10");
		assertTrue(game.isValidMove("b d9"));	game.play("b d9");
		assertTrue(game.isValidMove("w h9"));	game.play("w h9");
		assertTrue(game.isValidMove("b d8"));	game.play("b d8");
		assertTrue(game.isValidMove("w j8"));	game.play("w j8");
		assertTrue(game.isValidMove("b d11"));	game.play("b d11");
		assertTrue(game.isValidMove("w k8"));	game.play("w k8");  // eat 4
		assertTrue(game.isValidMove("b k10"));	game.play("b k10");
		assertTrue(game.isValidMove("w j10"));	game.play("w j10");
		assertTrue(game.isValidMove("b j9"));	game.play("b j9");
		assertTrue(game.isValidMove("w k9"));	game.play("w k9");  // eat 2 chains of 1 each one	
	}
	
	public void testSuicideNotValidSimple() {
		/*
			+-----
			|.X...
			|X....
			|.....
			A1 is not a valid move, detected developing GameHelperImpl
		*/
		game.play("b a2");
		game.play("w f10");
		game.play("b b1");
		assertFalse( game.isValidMove("w a1") );
	}
	
	
	
}
