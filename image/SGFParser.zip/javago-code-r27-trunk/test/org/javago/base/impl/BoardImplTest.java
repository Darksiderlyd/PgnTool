/*
 * Copyright (C) 2006,2007 Eduardo Sabbatella Riccardi
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * Email: esabb <at> users.sourceforge.net
 */

package org.javago.base.impl;

import org.javago.base.Board;
import junit.framework.TestCase;

public class BoardImplTest extends TestCase {

	int size;
	Board board;
	
	protected void setUp() throws Exception {
		size = 19;
		board = new BoardImpl(size);
	}
	
	protected void tearDown() throws Exception {
		size = -1;
		board = null;
	}
	
	public void testEmptyBoard() {
		for (int x=0; x<size; x++)
			for(int y=0; y<size; y++) {
				assertTrue ( board.get(x, y) == Board.EMPTY);
			}
	}
	
	public void testInvalidPositions() {
		assertEquals( board.get(-1, 1), Board.INVALID );
		assertEquals( board.get(1, -1), Board.INVALID );
		assertEquals( board.get(size+1, 1), Board.INVALID );
		assertEquals( board.get(1, size+1), Board.INVALID );

		assertEquals( board.get(-1, -1), Board.INVALID );
		assertEquals( board.get(size+1, size+1), Board.INVALID );
	}
	
	public void testSettingValues() {
		assertTrue(board.get(1, 1) == Board.EMPTY);
		board.set(1, 1, Board.BLACK);
		assertTrue(board.get(1, 1) == Board.BLACK);
		board.set(1, 1, Board.WHITE);
		assertTrue(board.get(1, 1) == Board.WHITE);
		board.set(1, 1, Board.EMPTY);
		assertTrue(board.get(1, 1) == Board.EMPTY);
		board.set(1, 1, Board.INVALID);
		assertFalse(board.get(1, 1) == Board.INVALID);
		assertTrue(board.get(1, 1) == Board.EMPTY);
	}
	
	public void testSettingInvalidGoMoves() {
		board.set(1, 0, Board.BLACK);
		board.set(0, 1, Board.BLACK);  // .X.
		board.set(2, 1, Board.BLACK);  // XOX
		board.set(1, 2, Board.BLACK);  // .X.
		board.set(1, 1, Board.WHITE);
		
		assertTrue( board.get(1,0) == Board.BLACK );
		assertTrue( board.get(0,1) == Board.BLACK );
		assertTrue( board.get(2,1) == Board.BLACK );
		assertTrue( board.get(1,2) == Board.BLACK );
		assertTrue( board.get(1,1) == Board.WHITE );
	}
	
	public void testGetArray() {
		board.set(1, 2, Board.BLACK);	
		int[] arr = board.getArray();
		assertTrue(arr.length == size*size);
		assertTrue( arr[(2*size)+1] == Board.BLACK);
	}
	
	public void testSetArray() {
		int[] arr = new int[size*size];		
		arr[((size-1)*size)+2] = Board.BLACK;
		board.setArray(arr);
		assertTrue( board.get(2,size-1) == Board.BLACK);
	}
	
	public void testCopyBoard() {
		board.set(0, 1, Board.BLACK);
		board.set(4, 1, Board.WHITE);
		Board board2 = new BoardImpl(board);		
		for(int x=0;x<size;x++) {
			for (int y=0; y<size; y++) {
				assertTrue(board2.get(x, y) == board.get(x, y));
			}
		}
		board.set(5, 2, Board.BLACK);
		assertFalse(board2.get(5,2) == board.get(5, 2));
	}
	
	public void testFromStringSimple() {
		int[] xy;
		xy = BoardImpl.fromString("A19");
		assertTrue(xy[0]==0 && xy[1] == 18);
	}

	public void testFromStringInvalid() {
		int[] xy;
		xy = BoardImpl.fromString("AAA");
		assertTrue(xy == null);
	}
	

	public void testConvertToP() {
		assertEquals( board.convertToP(10, 5), 5*size+10);
	}
	
	public void testGetXfromP() {
		assertEquals( board.getXfromP(120), 120%size);
	}

	public void testGetXfromP_2() {
		assertEquals( board.getXfromP(size+1), 1);
	}
	
	public void testGetYfromP() {
		assertEquals( board.getYfromP(130), 130/size);
	}

	public void testGetYfromP_2() {
		assertEquals( board.getYfromP(size+size+(size/2)), 2);
	}

	public void testGetNearP() {
		int[] p = board.getNearP( board.convertToP(5, 5) );
		assertEquals(p.length, 4);
	}

	public void testGetNearP_2() {
		int[] p = board.getNearP( board.convertToP(0, 5) );
		assertEquals(p.length, 3);
	}

	public void testGetP() {
		board.set(5, 2, Board.BLACK);
		assertEquals( board.getP(board.convertToP(5, 2)), Board.BLACK );
	}
		
	public void testHashStart() {
		assertTrue(board.getHash() != 0);
	}

	public void testHashOneMove_SetP() {
		board.setP(5, Board.WHITE);
		assertTrue(board.getHash() != 0);
	}

	public void testHashOneMove_set() {
		board.set(3,5, Board.WHITE);
		assertTrue(board.getHash() != 0);
	}

	public void testHashOneMove_setString() {
		board.set("J2", Board.WHITE);
		assertTrue(board.getHash() != 0);
	}

	public void testHashFiveMoves() {
		board.set("C5", Board.BLACK);
		long h1 = board.getHash();
		board.set("F8", Board.WHITE);
		long h2 = board.getHash();
		board.set("D4", Board.BLACK);
		long h3 = board.getHash();
		board.set("B1", Board.WHITE);
		long h4 = board.getHash();
		board.set("H12", Board.BLACK);
		long h5 = board.getHash();
		
		assertTrue( h1 != 0);
		assertTrue( h1 != h2);
		assertTrue( h1 != h3);
		assertTrue( h1 != h4);
		assertTrue( h1 != h5);

		assertTrue( h2 != h3);
		assertTrue( h2 != h4);
		assertTrue( h2 != h5);
		
		assertTrue( h3 != h4);
		assertTrue( h3 != h5);

		assertTrue( h4 != h5);
	}
	

	public void testHashSetArray() {
		Board board2 = new BoardImpl(size);
		board2.set("J2", Board.WHITE);
		board.setArray( board2.getArray() );
		
		assertEquals(board.getHash(), board2.getHash());
	}
	
	
	public void testTwoDifferentBoardsButWithSameMovesShouldHaveSameHash() {
		Board board2 = new BoardImpl(size);
		board.set("A2", Board.WHITE);
		board2.set("A2", Board.WHITE);
		board.set("G10", Board.BLACK);
		board2.set("G10", Board.BLACK);
		assertTrue(board.getHash() == board2.getHash());
	}
	
	public void testSetMoveReturnMoveHashShouldReturn() {
		long oldHash = board.getHash();
		board.set("A2", Board.WHITE);
		board.set("A2", Board.EMPTY);
		assertTrue( oldHash == board.getHash());
	}
	
	public void testGetDiagonalP_1() {
		int[] p = board.getDiagonalP(0);
		assertEquals(1, p.length);
	}

	public void testGetDiagonalP_1bis() {
		int[] p = board.getDiagonalP(1);
		assertEquals(2, p.length);
	}

	public void testGetDiagonalP_2() {
		int[] p = board.getDiagonalP(2);
		assertEquals(2, p.length);
	}

	public void testGetDiagonalP_2bis() {
		int[] p = board.getDiagonalP( (size*size)-(size/2) );
		assertEquals(2, p.length);
	}

	public void testGetDiagonalP_4() {
		int[] p = board.getDiagonalP( (size*size)/2 );
		assertEquals(4, p.length);
	}
	
}
