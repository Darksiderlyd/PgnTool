/*
 * Copyright (C) 2006,2007 Eduardo Sabbatella Riccardi
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * Email: esabb <at> users.sourceforge.net
 */

package org.javago.base.impl;

import org.javago.base.ChainsLiberties;
import junit.framework.TestCase;

public class ChainsLibertiesImplTest extends TestCase {

	ChainsLiberties cl;

	protected void setUp() throws Exception {
		cl = new ChainsLibertiesImpl();
	}
	
	protected void tearDown() throws Exception {
		cl = null;
	}
	
	public void testEmpty() {
		assertEquals(cl.size(), 0);
	}
	
	public void testAddOne() {
		cl.addGroup(100, new int[] {1,2});
		assertEquals(cl.size(), 1);
	}
	
	public void testGetGroupWithChain_NoResult() {
		assertTrue (cl.getGroupWithChainPoint(100) == -1);
	}

	public void testGetGroupWithChain_NoResult2() {
		cl.addGroup(100, new int[] {1,2});
		cl.addGroup(101, new int[] {4,5});
		assertTrue (cl.getGroupWithChainPoint(200) == -1);
	}

	public void testGetGroupWithChain_Simplest() {
		cl.addGroup(100, new int[] {1,2});
		assertTrue (cl.getGroupWithChainPoint(100) != -1);
	}

	public void testGetGroupWithChain_TwoDifferentGroupsShouldBeDifferentResult() {
		cl.addGroup(100, new int[] {1,2});
		cl.addGroup(101, new int[] {4,5});
		assertTrue (cl.getGroupWithChainPoint(100) != -1);
		assertTrue (cl.getGroupWithChainPoint(101) != -1);
		assertTrue (cl.getGroupWithChainPoint(100) != cl.getGroupWithChainPoint(101));
	}
	
	public void testgetGroupsWithLibertyPoint_empty() {
		int[] r = cl.getGroupsWithLibertyPoint(1);
		assertTrue (r.length == 0);
	}

	public void testgetGroupsWithLibertyPoint_empty2() {
		cl.addGroup(100, new int[] {1,2});
		cl.addGroup(101, new int[] {4,5});
		int[] r = cl.getGroupsWithLibertyPoint(60);
		assertTrue (r.length == 0);
	}

	public void testgetGroupsWithLibertyPoint_OneResult() {
		cl.addGroup(100, new int[] {1,2});
		cl.addGroup(101, new int[] {4,5});
		int[] r = cl.getGroupsWithLibertyPoint(1);
		assertTrue (r.length == 1);
	}
	
	public void testgetGroupsWithLibertyPoint_TwoResults() {
		cl.addGroup(100, new int[] {1,2});
		cl.addGroup(101, new int[] {4,5});
		cl.addGroup(102, new int[] {4,7});
		int[] r = cl.getGroupsWithLibertyPoint(4);
		assertTrue (r.length == 2);
	}
	
	
	public void testgetLibertiesPoints_empty() {
		assertEquals( cl.getLibertiesPoints(113), null );
	}

	public void testgetLibertiesPoints_ResultSimple() {
		cl.addGroup(100, new int[] {1,2});
		assertEquals( cl.getLibertiesPoints( cl.getGroupWithChainPoint(100) ).length, 2 );
	}	

	
	
	public void testgetChainPoints_empty() {
		assertEquals( cl.getChainPoints(113), null );
	}

	public void testgetChainPoints_ResultSimple() {
		cl.addGroup(100, new int[] {1,2});
		assertEquals( cl.getChainPoints( cl.getGroupWithChainPoint(100) ).length, 1 );
	}	
	
	public void testgetChainPoints_ResultSimple2() {
		cl.addGroup(100, new int[] {1,2});
		int g = cl.getGroupWithChainPoint(100);
		cl.addToGroup(g, 101, new int[]{3,4});
		assertEquals( cl.getChainPoints(g).length, 2 );
	}	
	
	public void testAddToGroup_simple() {
		cl.addGroup(100, new int[] {1,2});
		int g = cl.getGroupWithChainPoint(100);
		cl.addToGroup(g, 101, new int[]{3,4});
		assertEquals( cl.getChainPoints(g).length, 2);
		assertEquals( cl.getLibertiesPoints(g).length, 4);		
	}
	
	public void testAddToGroup_WithRepeatedLiberties() {
		cl.addGroup(100, new int[] {1,2});
		int g = cl.getGroupWithChainPoint(100);
		cl.addToGroup(g, 101, new int[]{1,2,9});
		assertEquals( cl.getChainPoints(g).length, 2);
		assertEquals( cl.getLibertiesPoints(g).length, 3);		
	}
	
	
	public void testUnion_simple() {
		cl.addGroup(100, new int[] {1,2,3});
		cl.addGroup(101, new int[] {4,5});
		cl.addGroup(102, new int[] {4,7,3});
		int g = cl.getGroupWithChainPoint(100);
		int g1 = cl.getGroupWithChainPoint(102);
		cl.unionGroups(g,g1);
		g = cl.getGroupWithChainPoint(100);
		
		assertTrue (cl.size() == 2);
		assertEquals(cl.getLibertiesPoints(g).length, 5);
		assertEquals(cl.getChainPoints(g).length, 2);
	}
	
	public void testUnion_simple2() {
		cl.addGroup(100, new int[] {1,2,3});
		cl.addGroup(101, new int[] {4,5});
		cl.addGroup(102, new int[] {4,7,3});
		cl.addGroup(103, new int[] {4,7,3});
		cl.addGroup(104, new int[] {4,7,2,3});
		cl.addGroup(105, new int[] {4,7,54,3});
		int g = cl.getGroupWithChainPoint(100);
		int g1 = cl.getGroupWithChainPoint(102);
		cl.unionGroups(g,g1);
		g = cl.getGroupWithChainPoint(100);
		
		assertTrue (cl.size() == 5);
		assertEquals(cl.getLibertiesPoints(g).length, 5);
		assertEquals(cl.getChainPoints(g).length, 2);
	}
	
	public void testGetLibertiesCount() {
		cl.addGroup(100, new int[] {1,2,3});
		int g = cl.getGroupWithChainPoint(100);
		assertEquals(cl.getLibertiesCount(g), 3);
	}
	
	public void testGetLibertiesCount_invalidGroup() {
		assertEquals(cl.getLibertiesCount(23), -1);
	}
	
	public void testDeleteGroup() {
		cl.addGroup(100, new int[] {1,2,3});
		int g = cl.getGroupWithChainPoint(100);
		cl.deleteGroup(g);
		assertEquals(cl.size(), 0);
	}
	
	public void testDeleteLiberty_basic() {
		cl.addGroup(100, new int[] {1,2,3});
		int g = cl.getGroupWithChainPoint(100);
		cl.deleteLiberty(g, 2);
		assertEquals(cl.getLibertiesCount(g), 2);
	}

	public void testDeleteLiberty_DeleteNotExistentLiberty() {
		cl.addGroup(100, new int[] {1,2,3});
		int g = cl.getGroupWithChainPoint(100);
		cl.deleteLiberty(g, 20);
		assertEquals(cl.getLibertiesCount(g), 3);
	}
	
}
