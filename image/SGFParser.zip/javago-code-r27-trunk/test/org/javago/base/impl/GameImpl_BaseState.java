/*
 * Copyright (C) 2006,2007 Eduardo Sabbatella Riccardi
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * Email: esabb <at> users.sourceforge.net
 */

package org.javago.base.impl;

import org.javago.base.Game;
import org.javago.base.Move;

import junit.framework.TestCase;

public class GameImpl_BaseState extends TestCase {

	Game game;
	Move move;
	int size;

	public void setUp() throws Exception {
		size = 19;
		game = new GameImpl(19);
	}

	public void tearDown() throws Exception {
		size = -1;
		game = null;
	}
	
	public void testKomiSimpleKomiSet() {
		game.setKomi(0.5f);
		assertEquals(0.5f, game.getKomi());
	}
	
	public void testDefaultKomi() {
		assertEquals(5.5f, game.getKomi());
	}
	
	public void testValidKomiValue() {
		try {
			game.setKomi( 0.123f ); 
			fail("Komi set with fractional part different to 1/2!!!");			
		} catch (IllegalArgumentException e) {
		}
	}
	
	public void testGameStartedCantChangeKomi() {
		game.play("BLACK A1");
		try {
			game.setKomi( 0.5f );
			fail("Komi changed after game started!!!");
		} catch (IllegalStateException e) {
		}
	}

	public void testSimpleHandicapSet() {
		game.setHandicap(2);
		assertEquals(2, game.getHandicap());
	}
	
	public void testDefaultHandicap() {
		assertEquals(0, game.getHandicap());
	}
}
