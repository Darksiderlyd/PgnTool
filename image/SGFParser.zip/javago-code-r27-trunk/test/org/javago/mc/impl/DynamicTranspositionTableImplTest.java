/*
 * Copyright (C) 2006,2007 Eduardo Sabbatella Riccardi
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * Email: esabb <at> users.sourceforge.net
 */

package org.javago.mc.impl;

import org.javago.mc.TranspositionTable;
import junit.framework.TestCase;

public class DynamicTranspositionTableImplTest extends TestCase {

	TranspositionTable tt;
	long hash;
	int moveno;
	int P;
	int boardLength;
	
	protected void setUp() throws Exception {
		boardLength = 361;
		tt = new DynamicTranspositionTableImpl(boardLength);
		hash = 0xdeadbeef;
		P = boardLength/2;
		moveno = 10;
	}
	
	protected void tearDown() throws Exception {
		tt = null;
		hash = -1;
		moveno = -1;
		P = -1;
	}
	
	public void testSimpleWin() {
		tt.storeBlackWin(moveno, hash, P);
		assertEquals(1, tt.getBlackWins(moveno, hash, P));
		assertEquals(1, tt.getPlayed(moveno, hash, P));
	}

	public void testSimpleLose() {
		tt.storeLose(moveno, hash, P);
		assertEquals(0, tt.getBlackWins(moveno, hash, P));
		assertEquals(1, tt.getPlayed(moveno, hash, P));
	}
	
	public void testMultiple() { 
		tt.storeLose(moveno, hash, P);
		tt.storeLose(moveno, hash, P);
		tt.storeLose(moveno, hash, P);
		tt.storeBlackWin(moveno, hash, P);
		tt.storeBlackWin(moveno, hash, P);
		assertEquals(2, tt.getBlackWins(moveno, hash, P));
		assertEquals(5, tt.getPlayed(moveno, hash, P));
	}
	
	public void testOnMove() {
		tt.storeBlackWin(moveno, hash, P);
		tt.onMove(moveno+1);
		assertEquals(0, tt.getBlackWins(moveno, hash, P));
		assertEquals(0, tt.getPlayed(moveno, hash, P));
	}

	public void testALotOfPlays() {
		int maxItems = 10000;
		for (int i=0; i<maxItems;i++) {
			tt.storeBlackWin(moveno, hash, P);
			tt.storeLose(moveno, hash, P);
		}
		assertEquals(maxItems, tt.getBlackWins(moveno, hash, P));
		assertEquals(maxItems*2, tt.getPlayed(moveno, hash, P));
	}

	public void testALotOfDifferentHashs() {
		int maxHash = 10000;
		for (int i=0; i<maxHash;i++) {
			tt.storeBlackWin(moveno, i, P);
			tt.storeLose(moveno, i, P);
		}
		for (int i=0; i<maxHash;i++) {
			assertEquals(1, tt.getBlackWins(moveno, i, P));
			assertEquals(2, tt.getPlayed(moveno, i, P));	
		}
	}

	public void testALotOfMixedHashsAndItems() {
		int maxHash = 5000;
		int maxItems = 100;
		for (int i=0; i<maxHash;i++) {
			for (int p=0; p<maxItems; p++) {
				tt.storeBlackWin(moveno, i, p);
				tt.storeLose(moveno, i, p);
			}
		}
		for (int i=0; i<maxHash;i++) {
			for (int p=0; i<maxItems;i++) {
				assertEquals(1, tt.getBlackWins(moveno, i, p));
				assertEquals(2, tt.getPlayed(moveno, i, p));
			}
		}
	}
	
	public  void testPlayedTable() {
		tt.storeLose(moveno, hash, P);
		tt.storeBlackWin(moveno, hash, P);
		tt.storeBlackWin(moveno, hash+1, P);
		tt.storeBlackWin(moveno, hash+1, P+1);
		
		int[] table = tt.getPlayedTable(moveno, hash);
		assertEquals(2,table[P]);
		for (int i=0; i<boardLength; i++) {
			if (i==P) {
				assertEquals(2,table[i]);
			} else {
				assertEquals(0,table[i]);				
			}
		}
	}

	public  void testWinsTable() {
		tt.storeLose(moveno, hash, P);
		tt.storeBlackWin(moveno, hash, P);
		tt.storeBlackWin(moveno, hash+1, P);
		tt.storeBlackWin(moveno, hash+1, P+1);
		
		int[] table = tt.getBlackWinsTable(moveno, hash);
		assertEquals(1,table[P]);
		for (int i=0; i<boardLength; i++) {
			if (i==P) {
				assertEquals(1,table[i]);
			} else {
				assertEquals(0,table[i]);				
			}
		}
	}
	
	public void testStoresInAllTable() {
		for (int i=0; i<boardLength; i++) {
			tt.storeBlackWin(moveno, hash, i);
			tt.storeLose(moveno, hash, i);
		}
		int[] winsTable = tt.getBlackWinsTable(moveno, hash);
		int[] playedTable = tt.getPlayedTable(moveno, hash);
		
		for (int i=0; i<boardLength; i++) {
			assertEquals(1, winsTable[i]);
			assertEquals(2, playedTable[i]);
		}	
	}
	
	public void testPass() {
		tt.storeBlackWin(moveno, hash, boardLength);
		assertEquals(0, tt.getPlayed(moveno, hash, 0));
		assertEquals(0, tt.getPlayed(moveno, hash, 0));
		assertEquals(1, tt.getPlayed(moveno, hash, boardLength));
		assertEquals(1, tt.getBlackWins(moveno, hash, boardLength));
	}
	
//	System.gc();
//	System.out.println( Runtime.getRuntime().freeMemory() );
//	System.gc();

}
