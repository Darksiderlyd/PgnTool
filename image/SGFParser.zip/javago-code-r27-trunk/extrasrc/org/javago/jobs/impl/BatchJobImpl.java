/*
 * Copyright (C) 2006,2007 Eduardo Sabbatella Riccardi
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * Email: esabb <at> users.sourceforge.net
 */

package org.javago.jobs.impl;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import org.javago.jobs.BatchJob;
import org.javago.jobs.Collector;
import org.javago.jobs.Filter;
import org.javago.jobs.Processor;

public class BatchJobImpl implements BatchJob {
	
	List<Filter> _filters;
	Collector _collector;
	Iterator _items;
	Processor _processor;
	
	boolean _started;
	boolean _stop;
	boolean _pause;
	boolean _finished;
	Integer _processed;
	Thread[] _thpool;
	
	long _startTime;
	long _endTime;
	
	
	public BatchJobImpl() {
		_filters = new Vector<Filter>();
		_pause = false;
		_started = false;
		_stop = false;
		_finished = false;
		_processed = new Integer(0);
	}

	public boolean pauseJob() {
		if (_started && !_stop && !_finished && !_pause) {
			_pause = true;
			return true;
		} else {
			return false;
		}
	}

	public boolean resumeJob() {
		if (_started && !_stop && !_finished && _pause) {
			_pause = false;
			return true;
		} else {
			return false;
		}
	}

	public boolean stopJob() {
		if (_started && !_stop && !_finished) {
			_stop = true;
			return true;
		} else {
			return false;
		}
	}
	
	public boolean isFinished() {
		if (_finished) return true;
		
		boolean isNowFinished = true;
		for (int t=0; t<_thpool.length; t++) {
			try {
				if (_thpool[t]!=null) {
					_thpool[t].join();
					_thpool[t]=null;
				}
			} catch (InterruptedException e) {
				isNowFinished = false;
			}
		}
		if (isNowFinished) {
			_finished = true;
			synchronized (_collector) {
				_collector.finished();
			}
			_endTime = System.currentTimeMillis();
		}

		return _finished;
	}

	public boolean startJob(int threads) {
		if (_started) return false;

		_started = true;
		_startTime = System.currentTimeMillis();
		_endTime = _startTime;
		
		_thpool = new Thread[threads];
		for (int t=0; t<threads; t++) {
			_thpool[t] = new Thread("Processor "+t) {
				public void run() {
					System.out.println("Starting " + this.getName());
					
					while (true) {

						Object item = null;
						synchronized (_items) {
							if (_items.hasNext()) {
								item = _items.next();
							} else {
								System.out.println("Ending " + this.getName());
								return; // END
							}
						}

						boolean pass = true;
						Iterator<Filter> filters = _filters.iterator();
						while (pass && filters.hasNext()) {
							Filter filter = filters.next();
							pass = pass && filter.pass(item);
						}

						if (pass) {
							Object result = _processor.process(item);
							synchronized (_processed) { // XXX: I´m replacing processed, should it work?
								int _newpr = _processed.intValue() + 1;
								_processed = new Integer(_newpr);
							}
							synchronized (_collector) {
								_collector.store(result);							
							}
						}

					}
					
				}
			};
			_thpool[t].start();
		}
		
		return true;
	}

	public boolean startJob() {
		return startJob(1);
	}

	
	public int processed() {
		synchronized (_processed) {
			return _processed.intValue();
		}
	}

	public void addFilter(Filter filter) {
		_filters.add(filter);
	}

	public void setCollector(Collector collector) {
		_collector = collector;
	}

	public void setProcessor(Processor processor) {
		_processor = processor;
	}

	public void setItemIterator(Iterator items) {
		_items = items;
	}

	public long time() {
		if (_startTime==_endTime) {
			return System.currentTimeMillis()-_startTime;
		} else {
			return _endTime - _startTime;
		}
	}

}
