/*
 * Copyright (C) 2006,2007 Eduardo Sabbatella Riccardi
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * Email: esabb <at> users.sourceforge.net
 */

package org.javago.jobs.impl;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;

import org.javago.base.GameTree;
import org.javago.base.util.SGFParser;
import org.javago.base.util.impl.SGFParserImpl;

public class GameStoreIterator implements Iterator {

	String _path;
	ZipFile _zip;
	Enumeration _zipEntries;
	GameTree _nextGT;
	SGFParser _parser;
	
	public GameStoreIterator(String path) {
		_path = path;
		_parser = new SGFParserImpl();
		
		try {
			_zip = new ZipFile( new File(path) );
		} catch (ZipException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		_zipEntries = _zip.entries();
		loadsNextGT();
	}
	
	private void loadsNextGT() {
		_nextGT = null;
		while (_nextGT==null) {
			if (!_zipEntries.hasMoreElements()) return;
			
			ZipEntry ze = (ZipEntry)_zipEntries.nextElement();
			
			if (ze.getName().toUpperCase().endsWith(".SGF") 
				||ze.getName().toUpperCase().endsWith(".MGT")) {
				InputStream input;
				try {
					input = _zip.getInputStream(ze);
					_nextGT = _parser.parse( new InputStreamReader(input) );
				} catch (IOException e) {}
			}

		}
	}
	
	public boolean hasNext() {
		return (_nextGT != null);
	}

	public Object next() {
		Object ret = _nextGT;
		loadsNextGT();
		return ret;
	}

	public void remove() {
	}

}
