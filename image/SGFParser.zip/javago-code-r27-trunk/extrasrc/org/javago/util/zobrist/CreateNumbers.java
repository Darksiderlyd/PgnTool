/*
 * Copyright (C) 2006,2007 Eduardo Sabbatella Riccardi
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * Email: esabb <at> users.sourceforge.net
 */

package org.javago.util.zobrist;

/*
 * This class create a set of numbers which complies that between any two of them the Hamming
 * distance is between (*_HAMMING_MINDIST, *_HAMMING_MAXDIST)
 */
public class CreateNumbers {
	
	int LONG_HAMMING_MINDIST = 19;//20;
	int LONG_HAMMING_MAXDIST = 45;//44;
	
	
	int hammingDist(long n1, long n2) {
		String zeros = "0000000000000000000000000000000000000000000000000000000000000000000000";
		String sn1 = Long.toBinaryString(n1);
		String sn2 = Long.toBinaryString(n2);
		
		if (sn1.length()<64)
			sn1= zeros.substring(0,64-sn1.length()) + sn1;
		if (sn2.length()<64)
			sn2= zeros.substring(0,64-sn2.length()) + sn2;

		int dist = 0;
		for (int i=0; i<sn1.length(); i++)
			if (sn1.charAt(i)!=sn2.charAt(i)) dist++;
		
		return dist;
	}
	
	String getLongInHex(long number) {
		String zeros = "0000000000000000";
		String res = Long.toHexString(number);
		if (res.length()<16)
			res = zeros.substring(0,16-res.length()) + res;
		return "0x"+res+"L";
	}
	
	
	
	void createNumbersLong(int qty, int groups) {
		DevRandom rnd = new DevRandom();
		long ns[] = new long[qty];
		
		System.out.println("Setting up initial array...");
		for (int i=0; i<qty; i++) {
			ns[i] = rnd.nextLong();
			System.out.print(".");
			if (i%50==49) System.out.println();
		}
			
		
		System.out.println("Basic tidy...");
		// zero is not allowed, neither FFFFFFFF.
		boolean nozeros = false;
		while (!nozeros) {
			nozeros = true;
			for (int i=0; i<qty; i++) {
				if (ns[i] == 0 || ns[i] == Long.MAX_VALUE || ns[i] == Long.MIN_VALUE) {
					nozeros = false;
					ns[i] = rnd.nextLong();
				}
			}
		}

		// so, i want to assure that the distance between 2 numbers are not
		System.out.println("Assuring Hamming distance ... takes time.");
		boolean hammingok = false;
		while (!hammingok) {
			hammingok = true;
			int hammingWrongQty = 0;
			
			for (int i=0; i<qty; i++) {
				for (int j=0; j<qty; j++) {
					if (i!=j) {
						int dist = hammingDist(ns[i], ns[j]);
						if (dist<LONG_HAMMING_MINDIST || dist>LONG_HAMMING_MAXDIST) {
							//ns[i] = rnd.nextLong();
							ns[j] = rnd.nextLong();
							hammingWrongQty++;
							hammingok = false;
							break;
						}
					}
				}
			}
			if (!hammingok) System.out.println("hamming .. " + hammingWrongQty);
		}

		System.out.println("Done, we got the numbers:");
		System.out.println("{");
		for (int i=0; i<qty; i++) {
			System.out.print( getLongInHex(ns[i]) + ", " );
			if (i%4 == 3) System.out.println("");
			if (i%(qty/groups) == ((qty/groups)-1)) 
				System.out.println("},\n {");
		}
		System.out.println("};");		
	}

	
	
	public static void main(String[] args) {
		CreateNumbers me = new CreateNumbers();
		me.createNumbersLong(19*19*3, 3);

	}

}
