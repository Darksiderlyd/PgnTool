SGFJ is a set of Java libraries to parse and handle Smart Game Format (SGF):
  SGFJ library is based on GNU Go parser implementation.
  TinySGF library uses LALR parser generator CUP and scanner generator JFlex.

GNU Go:  http://www.gnu.org/software/gnugo/gnugo.html
CUP:     http://www2.cs.tum.edu/projects/cup/
JFlex:   http://jflex.de/

See http://sf.net/projects/tinygo/ for release information.

Copyright (C) 2006, 2007  Alexey Klimkin
