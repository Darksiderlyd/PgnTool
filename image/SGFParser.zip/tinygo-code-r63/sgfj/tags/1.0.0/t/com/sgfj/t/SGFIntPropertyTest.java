/**
 * TinyGoTests is the collection of tests for TinyGo project.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, 
 * MA 02110-1301, USA.
 */
package com.sgfj.t;

import com.sgfj.SGFIntProperty;
import com.sgfj.SGFInvalidDataRequestException;
import com.sgfj.SGFPropertyName;

import junit.framework.TestCase;

/**
 * @author Alexey Klimkin
 *
 */
public class SGFIntPropertyTest extends TestCase {

    /**
     * Test method for {@link sgfj.SGFIntProperty#equals(java.lang.Object)}.
     */
    public void testEqualsObject() {
        SGFIntProperty p1 = new SGFIntProperty(SGFPropertyName.SZ, 1);
        SGFIntProperty p2 = new SGFIntProperty(SGFPropertyName.SZ, 1);
        assertEquals(p1, p2);
        p2 = new SGFIntProperty(SGFPropertyName.SZ, 2);
        assertFalse(p1.equals(p2));
        p2 = new SGFIntProperty(SGFPropertyName.HA, 1);
        assertFalse(p1.equals(p2));
    }

    /**
     * Test method for {@link sgfj.SGFIntProperty#getInt()}.
     */
    public void testGetInt() {
        SGFIntProperty p1 = new SGFIntProperty(SGFPropertyName.SZ, 1);
        assertEquals(1, p1.getInt());
    }

    /**
     * Test method for {@link sgfj.SGFProperty#getText()}.
     */
    public void testGetText() {
        SGFIntProperty p1 = new SGFIntProperty(SGFPropertyName.SZ, 1);
        try {
            p1.getText();
            fail("Should generate SGFInvalidDataRequestException.");
        } catch (SGFInvalidDataRequestException e) {
        }
    }

}
