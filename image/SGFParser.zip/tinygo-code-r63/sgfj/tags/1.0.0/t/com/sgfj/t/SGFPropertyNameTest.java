/**
 * TinyGoTests is the collection of tests for TinyGo project.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, 
 * MA 02110-1301, USA.
 */
package com.sgfj.t;

import com.sgfj.SGFParser;
import com.sgfj.SGFPropertyName;

import junit.framework.TestCase;

/**
 * @author Alexey Klimkin
 *
 */
public class SGFPropertyNameTest extends TestCase {

    boolean equal(char[] d1, char[] d2) {
        if (d1.length != d2.length)
            return false;
        for (int i = 0; i < d1.length; i++)
            if (d1[i] != d2[i])
                return false;
        return true;
    }

    public void testToCharArray() {
        char[] ca1 = new char[]{'B'};
        char[] ca2 = new char[]{'S', 'Z'};
        SGFPropertyName n1 = SGFParser.parsePropertyName(ca1);
        assertTrue(equal(ca1, n1.toCharArray()));
        n1 = SGFParser.parsePropertyName(ca2);
        assertTrue(equal(ca2, n1.toCharArray()));
    }

    public void testAllowingRange() {
        assertTrue(SGFPropertyName.AB.allowingRange());
        assertFalse(SGFPropertyName.SZ.allowingRange());
    }

    public void testParse() {
        SGFPropertyName n1 = SGFParser.parsePropertyName("SZ".toCharArray());
        assertSame(SGFPropertyName.SZ, n1);

        n1 = SGFParser.parsePropertyName("C".toCharArray());
        assertSame(SGFPropertyName.C, n1);

        char[] unknown = new char[]{'X', 'X'};
        SGFPropertyName n2 = SGFParser.parsePropertyName(unknown);
        assertTrue(equal(unknown, n2.toCharArray()));
        SGFPropertyName n3 = SGFParser.parsePropertyName(unknown);
        assertSame(n3, n2);
    }

    public void testIsKnown() {
        assertTrue(SGFPropertyName.isKnown("SZ".toCharArray()));
        char[] unknown = new char[]{'Y', 'Y'};
        assertFalse(SGFPropertyName.isKnown(unknown));
    }
}
