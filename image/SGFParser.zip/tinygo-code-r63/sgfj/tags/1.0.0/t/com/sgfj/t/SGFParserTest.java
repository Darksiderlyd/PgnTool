/**
 * TinyGoTests is the collection of tests for TinyGo project.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 */
package com.sgfj.t;

import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;

import com.sgfj.SGFEOFException;
import com.sgfj.SGFNode;
import com.sgfj.SGFNodeIterator;
import com.sgfj.SGFParser;
import com.sgfj.SGFPoint;
import com.sgfj.SGFPointProperty;
import com.sgfj.SGFProperty;
import com.sgfj.SGFPropertyName;

import junit.framework.TestCase;

/**
 * @author Alexey Klimkin
 *
 */
public class SGFParserTest extends TestCase {

    static final String cgobanData = "(;GM[1]FF[4]CA[UTF-8]AP[CGoban:3]ST[2]RU[Japanese]SZ[9]HA[3]KM[5.50]PW[Белые]PB[Черные]AB[gc][cg][gg];W[ed]CR[ee]TR[cc][gc](;B[ec]CR[ec]LB[dd:A])(;B[eg]CR[eg];W[];B[ge]))";
    static final String jagoData = "(GE[life and death]DI[8k]DP[47]SO[unkx80]CO[7];FF[4]GM[1]SZ[19]AP[Jago:Version 4.21]AB[cr][dr][er][ep][fp][gq][gr]AW[gp][hp][hq][hr][br][bq][cq][co][do][eo][fo][dq][jr]C[Black first to live.]GN[goproblem_x01](;B[fs];W[eq](;B[fq];W[hs](;B[gs]C[RIGHTEasy one :-)])(;B[cs];W[gs]))(;B[cs];W[fq]))(;B[eq];W[cs](;B[ds];W[fs](;B[gs];W[fr])(;B[fr];W[gs]))(;B[gs];W[ds](;B[es];W[fr])(;B[fr];W[es])))(;B[fq];W[fs])(;B[fr];W[eq])(;B[cs];W[eq];B[fq];W[fs])(;B[gs];W[eq];B[fq];W[cs]))";
    static final String problemData = "(;(;W[ba]  (;B[ca]C[Well done! RIGHT])  (;B[ac]C[WRONG])  (;B[aa]))(;W[ab]))";

    /**
     * Test method for {@link com.sgfj.t.SGFParser#parse(java.io.Reader)}.
     */
    public void testParse() {
        try {
            SGFParser reader = new SGFParser(cgobanData);
            //FileInputStream is = new FileInputStream("data/1850-11-17-Shusaku-Ito.Showa.sgf");
            SGFNode tree = reader.parse();
            assertNotNull("Emty tree received.", tree);

            SGFNodeIterator i = tree.iterator();
            SGFPointProperty move;

            assertFalse(i.current().hasProperty(SGFPropertyName.W));
            assertFalse(i.current().hasProperty(SGFPropertyName.B));
            assertNull(i.prev(false));
            assertNull(i.prevVariant(false));
            assertNull(i.nextVariant(false));

            i.next(true);
            move = (SGFPointProperty) i.current().getProperty(SGFPropertyName.W);
            assertEquals(new SGFPointProperty(SGFPropertyName.W, new SGFPoint(4, 3)), move);
            assertFalse(i.current().hasProperty(SGFPropertyName.B));
            assertSame(tree, i.prev(false));
            assertNull(i.prevVariant(false));
            assertNull(i.nextVariant(false));

            i.next(true);
            move = (SGFPointProperty) i.current().getProperty(SGFPropertyName.B);
            assertEquals(move, new SGFPointProperty(SGFPropertyName.B, new SGFPoint(4, 2)));
            assertFalse(i.current().hasProperty(SGFPropertyName.W));
            //assertSame(p.getParent(), tree);
            assertNull(null, i.next(false));
            assertNull(null, i.prevVariant(false));
            //assertNotSame(p.getNext(), null);

            i.nextVariant(true);
            move = (SGFPointProperty) i.current().getProperty(SGFPropertyName.B);
            assertEquals(new SGFPointProperty(SGFPropertyName.B, new SGFPoint(4, 6)), move);
            assertFalse(i.current().hasProperty(SGFPropertyName.W));
            //assertSame(p.getParent(), tree);
            //assertSame(p.next(), null);
            assertNull(i.nextVariant(false));
            //assertNotSame(p.getNext(), null);

        } catch (Exception e) {
            e.printStackTrace();
            fail("No exceptions are expected.");
        }
    }

    public void testParseEmpty() {
        byte[] ba = new byte[] {};
        try {
            try {
                SGFParser reader = new SGFParser(new InputStreamReader(new ByteArrayInputStream(ba)));
                SGFNode n = reader.parse();
                assertNull(n);
            } catch (SGFEOFException e) {
            }
        } catch (Exception e) {
            e.printStackTrace();
            fail("No exceptions are expected.");
        }
    }


    /**
     * Jago tends to add extra properties before root node.
     * (GE[life and death] ;FF[4]GM[1]...
     */
    public void testParseJagoSGF() {
        try {
            SGFParser reader = new SGFParser(jagoData);
            SGFNode tree = reader.parse();
            assertNotNull("Emty tree received.", tree);

            SGFProperty p;
            p = tree.getProperty(SGFPropertyName.FF);
            assertEquals(4, p.getInt());

        } catch (Exception e) {
            e.printStackTrace();
            fail("No exceptions are expected.");
        }
    }

    /**
     * Test if some node is marked "RIGHT", then following nodes are GOOD.
     */
    public void _testParseProblemRIGHTInTheMiddle() {
        // TODO: not passing
        try {
            String data = "(;SZ[19](;B[da]C[RIGHT];W[ab])(;B[ad]))";
            SGFParser parser = new SGFParser(data);
            SGFNode tree = parser.parseProblem();
            SGFNodeIterator i = tree.iterator();
            SGFNode node = i.current();
            assertTrue((node.bits & SGFNode.GOOD_MOVE) != 0 && (node.bits & SGFNode.BAD_MOVE) != 0);
            node = i.next(true);
            assertTrue((node.bits & SGFNode.GOOD_MOVE) != 0 && (node.bits & SGFNode.BAD_MOVE) == 0);
            node = i.nextVariant(false);
            assertTrue((node.bits & SGFNode.GOOD_MOVE) == 0 && (node.bits & SGFNode.BAD_MOVE) != 0);
            node = i.next(true);
            assertTrue((node.bits & SGFNode.GOOD_MOVE) != 0 && (node.bits & SGFNode.BAD_MOVE) == 0);
            node = i.next(true);
            assertTrue((node.bits & SGFNode.GOOD_MOVE) != 0 && (node.bits & SGFNode.BAD_MOVE) == 0);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected!");
        }
    }

    public void testParseProblem() {
        try {
            SGFParser reader = new SGFParser(problemData);
            SGFNode tree = reader.parseProblem();
            assertNotNull("Emty tree received.", tree);

            SGFNodeIterator i = tree.iterator();
            SGFNode node;
            node = i.next(true);
            assertTrue((node.bits & SGFNode.GOOD_MOVE) != 0 && (node.bits & SGFNode.BAD_MOVE) == 0);
            node = i.nextVariant(false);
            assertTrue((node.bits & SGFNode.GOOD_MOVE) == 0 && (node.bits & SGFNode.BAD_MOVE) != 0);
            node = i.next(true);
            assertTrue((node.bits & SGFNode.GOOD_MOVE) != 0 && (node.bits & SGFNode.BAD_MOVE) == 0);
            node = i.nextVariant(true);
            assertTrue((node.bits & SGFNode.GOOD_MOVE) == 0 && (node.bits & SGFNode.BAD_MOVE) != 0);
            node = i.nextVariant(true);
            assertTrue((node.bits & SGFNode.GOOD_MOVE) == 0 && (node.bits & SGFNode.BAD_MOVE) != 0);

        } catch (Exception e) {
            e.printStackTrace();
            fail("No exceptions are expected.");
        }
    }

    public void testParseHead() {
        try {
            String data = "(;GM[1]FF[4]CA[UTF-8]AP[CGoban:3]ST[2]RU[Japanese]SZ[9]HA[3]KM[5.50]PW[Белые]PB[Черные]AB[gc][cg][gg];W[ed]CR[ee]TR[cc][gc](;B[ec]CR[ec]LB[dd:A])(;B[eg]CR[eg];W[];B[ge]))";
            SGFParser reader = new SGFParser(data);
            SGFNode tree = reader.parseHead();
            assertNotNull("Emty tree received.", tree);

            assertNull(tree.iterator().next(false));
        } catch (Exception e) {
            e.printStackTrace();
            fail("No exceptions are expected.");
        }
    }

    public void testParseUnicode() {
        try {
            String data = "(;GM[1]FF[4]CA[UTF-8]AP[CGoban:3]ST[2]RU[Japanese]PW[\u0403\u0490\u00ab\u043b\u0490])";
            SGFParser reader = new SGFParser(data);
            SGFNode tree = reader.parseHead();
            assertNotNull("Emty tree received.", tree);

            assertNull(tree.iterator().next(false));
        } catch (Exception e) {
            e.printStackTrace();
            fail("No exceptions are expected.");
        }
    }
}
