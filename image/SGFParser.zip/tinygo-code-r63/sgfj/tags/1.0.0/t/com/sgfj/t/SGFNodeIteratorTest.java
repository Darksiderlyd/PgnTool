/**
 * TinyGoTests is the collection of tests for TinyGo project.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, 
 * MA 02110-1301, USA.
 */
package com.sgfj.t;

import com.sgfj.SGFNode;
import com.sgfj.SGFNodeIterator;

import junit.framework.TestCase;

public class SGFNodeIteratorTest extends TestCase {

    public void testWalk() {
        SGFNode n1 = new SGFNode();
        SGFNode n2v1 = new SGFNode();
        SGFNode n2v2 = new SGFNode();
        n1.add(n2v1);
        n1.add(n2v2);

        SGFNodeIterator iterator = n2v2.iterator();
        assertSame(n2v2, iterator.current());
        assertSame(n1, iterator.prev(true));
        assertSame(null, iterator.prev(true));
        assertSame(n2v2, iterator.next(true));
        assertSame(null, iterator.next(true));
        assertSame(n2v1, iterator.prevVariant(true));
        assertSame(null, iterator.prevVariant(true));
        assertSame(n1, iterator.prev(true));
        assertSame(n2v1, iterator.next(true));
        assertSame(n2v2, iterator.nextVariant(true));
        assertSame(null, iterator.nextVariant(true));
    }

    public void testWalk2() {
        SGFNode n1 = new SGFNode();
        SGFNode n2v1 = new SGFNode();
        SGFNode n2v2 = new SGFNode();
        SGFNode n3 = new SGFNode();
        n1.add(n2v1);
        n1.add(n2v2);
        n2v1.add(n3);

        SGFNodeIterator it = n1.iterator();
        assertSame(n2v1, it.next(true));
        assertSame(n2v2, it.nextVariant(true));
        assertSame(n2v1, it.prevVariant(true));
        assertSame(n3, it.next(true));
    }
}
