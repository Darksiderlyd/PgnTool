/**
 * TinyGoTests is the collection of tests for TinyGo project.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 */
package com.sgfj.t;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import com.sgfj.SGFIntProperty;
import com.sgfj.SGFMove;
import com.sgfj.SGFNode;
import com.sgfj.SGFParser;
import com.sgfj.SGFPropertyName;
import com.sgfj.SGFWriter;

import junit.framework.TestCase;

public class SGFWriterTest extends TestCase {

    public void testWrite() {
        try {
            String data = "(;GM[1]FF[4]CA[UTF-8]AP[CGoban:3]ST[2]RU[Japanese]SZ[9]HA[3]KM[5.50]PW[Белые]PB[Черные]AB[gc][cg][gg];W[ed]CR[ee]TR[cc][gc](;B[ec]CR[ec]LB[dd:A])(;B[eg]CR[eg];W[];B[ge]))";
            SGFParser reader = new SGFParser(data);
            SGFNode tree = reader.parse();
            assertNotNull("Emty tree received.", tree);

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            OutputStreamWriter w = new OutputStreamWriter(baos);
            SGFWriter.write(w, tree);
            w.close();

            //System.out.println(baos.toString());
            ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
            reader = new SGFParser(new InputStreamReader(bais));
            SGFNode tree2 = reader.parse();

            assertEquals(tree, tree2);
            assertEquals(SGFWriter.toString(tree), SGFWriter.toString(tree2));
        } catch (Exception e) {
            e.printStackTrace();
            fail("No exceptions are expected.");
        }
    }

    public void testWriteSynth() {
        try {
            SGFNode root = new SGFNode();
            root.addProperty(new SGFIntProperty(SGFPropertyName.SZ, 9));
            root.addProperty(new SGFIntProperty(SGFPropertyName.HA, 0));

            SGFNode n;
            String s;

            n = new SGFNode();
            n.addMoveProperty(new SGFMove(0, 0, SGFMove.BLACK));
            root.add(n);
            s = SGFWriter.toString(root);
            assertEquals("(;SZ[9]HA[0];B[aa])", s);

            n = new SGFNode();
            n.addMoveProperty(new SGFMove(1, 1, SGFMove.WHITE));
            root.add(n);
            s = SGFWriter.toString(root);
            assertEquals("(;SZ[9]HA[0](;B[aa])(;W[bb]))", s);
        } catch (IOException e) {
            e.printStackTrace();
            fail("No exceptions are expected.");
        }
    }
}
