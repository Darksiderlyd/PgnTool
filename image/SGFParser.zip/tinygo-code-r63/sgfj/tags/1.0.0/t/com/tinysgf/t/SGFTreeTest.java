/**
 * TinyGoTests is the collection of tests for TinyGo project.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, 
 * MA 02110-1301, USA.
 */
package com.tinysgf.t;

import com.tinysgf.SGFTree;

import junit.framework.TestCase;

public class SGFTreeTest extends TestCase {

    public void testCollection() {
        SGFTree collection = new SGFTree();
        int root1 = collection.newNode();
        int root2 = collection.newNode();
        collection.linkVariant(root1, root2);
        assertEquals(SGFTree.ROOT, root1);
        assertEquals(SGFTree.NULL, collection.getPrev(root1));
        assertEquals(SGFTree.NULL, collection.getPrev(root2));
        assertEquals(root2, collection.getNextVariant(root1));
    }

    public void testNewNode() {
        SGFTree tree = new SGFTree();
        assertEquals(SGFTree.NONE, tree.getMoveProperty(SGFTree.ROOT));

        int m = tree.newNode();

        // add simple node
        int m1 = tree.newNode(m, SGFTree.BLACK_MOVE, 3, 4);
        assertEquals(SGFTree.BLACK_MOVE, tree.getMoveProperty(m1));
        assertEquals(3, tree.getMoveX(m1));
        assertEquals(4, tree.getMoveY(m1));
        assertEquals(m, tree.getPrev(m1));
        assertEquals(SGFTree.NULL, tree.getNext(m1));
        assertEquals(SGFTree.NULL, tree.getNextVariant(m1));
        assertEquals(m1, tree.getNext(m));

        // add variant
        int m2 = tree.newNode(m, SGFTree.BLACK_MOVE, 5, 6);
        assertEquals(m, tree.getPrev(m2));
        assertEquals(SGFTree.NULL, tree.getNext(m2));
        assertEquals(SGFTree.NULL, tree.getNextVariant(m2));
        assertEquals(m2, tree.getNextVariant(m1));
        assertEquals(m1, tree.getNext(m));
    }

    public void testLinkNode() {
        SGFTree tree = new SGFTree();
        int m = tree.newNode();
        int m1 = tree.newNode(SGFTree.BLACK_MOVE, 3, 4);
        tree.linkNode(m, m1);
        assertEquals(SGFTree.BLACK_MOVE, tree.getMoveProperty(m1));
        assertEquals(3, tree.getMoveX(m1));
        assertEquals(4, tree.getMoveY(m1));
        assertEquals(m, tree.getPrev(m1));
        assertEquals(SGFTree.NULL, tree.getNext(m1));
        assertEquals(SGFTree.NULL, tree.getNextVariant(m1));
        assertEquals(m1, tree.getNext(m));
    }

    public void testRemoveNode() {
        SGFTree tree = new SGFTree();
        int m1 = tree.newNode(SGFTree.BLACK_MOVE, 3, 4);
        int m2 = tree.newNode(m1, SGFTree.WHITE_MOVE, 3, 5);
        int m2v2 = tree.newNode(m1, SGFTree.WHITE_MOVE, 3, 7);
        int m2v3 = tree.newNode(m1, SGFTree.WHITE_MOVE, 3, 8);
        int m3 = tree.newNode(m2, SGFTree.BLACK_MOVE, 4, 4);

        tree.removeNode(m3);
        assertEquals(SGFTree.NULL, tree.getNext(m2));
        int m3_ = tree.newNode(m2, SGFTree.BLACK_MOVE, 4, 9);
        assertEquals(m3_, m3);

        tree.removeNode(m2v2);
        assertEquals(m2v3, tree.getNextVariant(m2));
        tree.removeNode(m2);
        assertEquals(m2v3, tree.getNext(m1));
    }

    public void testGetHead() {
        SGFTree tree = new SGFTree();
        int m1 = tree.newNode(SGFTree.BLACK_MOVE, 3, 4);
        int m2 = tree.newNode(m1, SGFTree.WHITE_MOVE, 3, 5);
        int m3 = tree.newNode(m2, SGFTree.BLACK_MOVE, 4, 4);
        assertEquals(m1, tree.getHead(m3));
    }
}
