/**
 * TinyGoTests is the collection of tests for TinyGo project.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, 
 * MA 02110-1301, USA.
 */
package com.tinysgf.t;

import com.tinysgf.SGFProp;

import junit.framework.TestCase;

public class SGFPropTest extends TestCase {

    public void testGetLabel() {
        SGFProp p = new SGFProp(SGFProp.LB, "ab:A".toCharArray());
        assertEquals("A", p.getLabel());
        p = new SGFProp(SGFProp.LB, "ab:".toCharArray());
        assertEquals("", p.getLabel());
    }

    public void testGetX() {
        SGFProp p = new SGFProp(SGFProp.LB, "ab:A".toCharArray());
        assertEquals(0, p.getX());
        SGFProp p2 = new SGFProp(SGFProp.LB, "CB:A".toCharArray());
        assertEquals(2, p2.getX());
    }

    public void testGetY() {
        SGFProp p = new SGFProp(SGFProp.LB, "ab:A".toCharArray());
        assertEquals(1, p.getY());
    }

    public void testGetInt() {
        SGFProp p = new SGFProp(SGFProp.SZ, "123".toCharArray());
        assertEquals(123, p.getInt());
    }

    public void testGetFloat() {
        SGFProp p = new SGFProp(SGFProp.KM, "5.5".toCharArray());
        assertTrue(p.getFloat() == (float)5.5);
    }

    public void testGetText() {
        SGFProp p = new SGFProp(SGFProp.C, "RIGHT".toCharArray());
        assertEquals("RIGHT", p.getText());
    }

    public void testToString() {
        SGFProp p = new SGFProp(SGFProp.SZ, "123".toCharArray());
        assertEquals("SZ[123]", p.toString());
    }

}
