/**
 * TinyGoTests is the collection of tests for TinyGo project.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, 
 * MA 02110-1301, USA.
 */
package com.sgfj.t;

import com.sgfj.SGFMove;
import com.sgfj.SGFNode;
import com.sgfj.SGFNodeBoundsVisitor;

import junit.framework.TestCase;

public class SGFNodeBoundsVisitorTest extends TestCase {

    public void testWalk() {
        SGFNode node = new SGFNode();
        SGFMove wPass = new SGFMove(SGFMove.WHITE);
        node.addMoveProperty(wPass);
        SGFNode node2 = new SGFNode();
        SGFMove bPlay = new SGFMove(1, 10, SGFMove.BLACK);
        SGFMove wPlay = new SGFMove(3, 4, SGFMove.WHITE);
        node2.addMoveProperty(bPlay);
        node.add(node2);
        SGFNode node3 = new SGFNode();
        node3.addMoveProperty(wPlay);
        node.add(node3);

        SGFNodeBoundsVisitor bounds = new SGFNodeBoundsVisitor(0, 0, 19, 19);
        node.eval(bounds);
        assertEquals(1, bounds.xmin);
        assertEquals(4, bounds.ymin);
        assertEquals(3, bounds.xmax);
        assertEquals(10, bounds.ymax);

        bounds = new SGFNodeBoundsVisitor(0, 0, 5, 5);
        node.eval(bounds);
        assertEquals(3, bounds.xmin);
        assertEquals(4, bounds.ymin);
        assertEquals(3, bounds.xmax);
        assertEquals(4, bounds.ymax);

        bounds = new SGFNodeBoundsVisitor(0, 0, 1, 1);
        node.eval(bounds);
        assertFalse(bounds.hasPoints());
    }
}
