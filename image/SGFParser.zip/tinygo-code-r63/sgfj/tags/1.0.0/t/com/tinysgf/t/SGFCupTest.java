/**
 * TinyGoTests is the collection of tests for TinyGo project.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, 
 * MA 02110-1301, USA.
 */
package com.tinysgf.t;

import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;

import com.tinysgf.SGFCup;
import com.tinysgf.SGFLex;
import com.tinysgf.SGFTree;

import junit.framework.TestCase;

public class SGFCupTest extends TestCase {

    public void testParse() {
        try {
            String[] data = {
                "(;SZ[19](;B[da]C[RIGHT];W[ab])(;B[ad]))",
                "(;)",
                "(;;B[ad])(;;B[da])",
                "(;C[\\[\\]\\t\\n\\r\\f\\b\\\\])",
            };

            for (int i = 0; i < data.length; i++) {
                InputStreamReader isr = new InputStreamReader(
                        new ByteArrayInputStream(data[i].getBytes()), "UTF8");
                SGFCup parser = new SGFCup(new SGFLex(isr));
                parser.parse();
                SGFTree tree = parser.tree;
/*				System.out.println(i);
                System.out.println(tree.toString());
                System.out.println(data[i]);
*/				assertEquals(data[i], tree.toString());
            }
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected!");
        }
    }

    public void testGrow() {
        try {
            String data = "(;SZ[19](;B[da]C[RIGHT];W[ab])(;B[ad]))";
            InputStreamReader isr = new InputStreamReader(
                    new ByteArrayInputStream(data.getBytes()), "UTF8");
            SGFCup parser = new SGFCup(new SGFLex(isr));
            parser.tree = new SGFTree(1, 1);
            parser.parse();
            assertEquals(data, parser.tree.toString());
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected!");
        }
    }
}
