/**
 * TinyGoTests is the collection of tests for TinyGo project.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 */
package com.sgfj.t;

import com.sgfj.SGFIntProperty;
import com.sgfj.SGFMove;
import com.sgfj.SGFNode;
import com.sgfj.SGFNodeIterator;
import com.sgfj.SGFParser;
import com.sgfj.SGFPoint;
import com.sgfj.SGFPointProperty;
import com.sgfj.SGFProperty;
import com.sgfj.SGFPropertyName;
import com.sgfj.SGFPropertyNotFoundException;
import com.sgfj.SGFTextProperty;

import junit.framework.TestCase;

/**
 * @author Alexey Klimkin
 *
 */
public class SGFNodeTest extends TestCase {

    static final String moveData = "(;SZ[19]EV[My desktop]PB[al]BR[18k]PW[al2]WR[18k]KM[0]RE[B+99]DT[2006-09-09,18]PC[Krasnogorsk, Russia]US[klimkin@gmail.com];B[qd];W[op])";
    SGFNode tree = null;

    /**
     * @param name
     */
    public SGFNodeTest(String name) {
        super(name);
    }

    /* (non-Javadoc)
     * @see junit.framework.TestCase#setUp()
     */
    protected void setUp() throws Exception {
        super.setUp();
        SGFParser reader = new SGFParser(moveData);
        tree = reader.parse();
        assertNotNull("Emty tree received.", tree);
    }

    /* (non-Javadoc)
     * @see junit.framework.TestCase#tearDown()
     */
    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testGetProperty() {
        try {
            setUp();
            SGFProperty prop = tree.getProperty(SGFPropertyName.SZ);
            assertEquals(SGFPropertyName.SZ, prop.name());
            assertEquals(19, prop.getInt());

            prop = tree.getProperty("SZ".toCharArray());
            assertEquals(SGFPropertyName.SZ, prop.name());
            assertEquals(19, prop.getInt());

            prop = tree.getProperty(23123);
            assertEquals(SGFPropertyName.SZ, prop.name());
            assertEquals(19, prop.getInt());
        } catch (Exception e) {
            e.printStackTrace();
            fail("No exceptions are expected.");
        }
    }

    public void testGetProperty2() {
        try {
            SGFNode node = new SGFNode();
            SGFPointProperty pprop = new SGFPointProperty(SGFPropertyName.W, new SGFPoint(1, 2));
            node.addPropertyNoCheck(pprop);
            assertEquals(pprop, node.getProperty(SGFPropertyName.W));

            SGFIntProperty iprop = new SGFIntProperty(SGFPropertyName.SZ, 19);
            node.addPropertyNoCheck(iprop);
            assertEquals(iprop, node.getProperty(SGFPropertyName.SZ));
        } catch (Exception e) {
            e.printStackTrace();
            fail("No exceptions are expected.");
        }
    }

    public void testGetComment() {
        try {
            SGFNode node = new SGFNode();
            try {
                node.getCommentProperty();
                fail("SGFPropertyNotFoundException expected!");
            } catch (SGFPropertyNotFoundException e) {
            }
            node.addProperty(new SGFTextProperty(SGFPropertyName.C, "a".toCharArray()));
            node.addProperty(new SGFTextProperty(SGFPropertyName.C, "b".toCharArray()));
            assertEquals("ab", node.getCommentProperty());
        } catch (Exception e) {
            e.printStackTrace();
            fail("No exceptions are expected.");
        }
    }

    public void testGetMove() {
        try {
            setUp();
            SGFNodeIterator i = tree.iterator();
            assertEquals(new SGFMove(16, 3, SGFMove.BLACK), i.next(true).getMoveProperty());
            assertEquals(new SGFMove(14, 15, SGFMove.WHITE), i.next(true).getMoveProperty());
            assertEquals(null, i.next(true));
        } catch (Exception e) {
            e.printStackTrace();
            fail("No exceptions are expected.");
        }
    }

    public void testAddMove() {
        try {
            SGFNode node = new SGFNode();
            node.addMoveProperty(new SGFMove(16, 3, SGFMove.BLACK));
            assertEquals(new SGFMove(16, 3, SGFMove.BLACK), node.getMoveProperty());
        } catch (Exception e) {
            e.printStackTrace();
            fail("No exceptions are expected.");
        }
    }

    public void testRemove() {
        SGFNode root = new SGFNode();
        SGFNode v1 = new SGFNode();
        SGFNode v2 = new SGFNode();
        SGFNode v3 = new SGFNode();
        SGFNode v3c = new SGFNode();
        root.add(v1);
        root.add(v2);
        root.add(v3);
        v2.add(v3c);

        v2.remove();
        assertSame(v1, root.iterator().next(false));
        assertSame(v3, v1.iterator().nextVariant(false));
        assertSame(null, v3.iterator().nextVariant(false));
        assertSame(null, v1.iterator().next(false));
        assertSame(null, v3.iterator().next(false));

        v1.remove();
        assertSame(v3, root.iterator().next(false));
        assertSame(null, v3.iterator().nextVariant(false));
        assertSame(null, v3.iterator().next(false));
    }

    public void testPlay() {
        SGFNode root = new SGFNode();
        SGFMove m1 = new SGFMove(0, 0, SGFMove.WHITE);
        SGFMove m2 = new SGFMove(0, 1, SGFMove.BLACK);
        SGFMove m3 = new SGFMove(1, 0, SGFMove.BLACK);
        root.play(m1);
        root.iterator().next(false).play(m2);
        root.iterator().next(false).play(m3);
        root.iterator().next(false).play(m2);
        SGFNodeIterator it = root.iterator();
        try {
            assertEquals(m1, it.next(true).getMoveProperty());
            assertEquals(m2, it.next(true).getMoveProperty());
            assertEquals(m3, it.nextVariant(true).getMoveProperty());
            assertEquals(null, it.nextVariant(true));
        } catch (SGFPropertyNotFoundException e) {
            e.printStackTrace();
            fail("Unexpected!");
        }
    }

    public void testEquals() {
        try {
            setUp();
            SGFNode tmp = tree;
            tree = null;
            setUp();
            assertEquals(tmp, tree);
        } catch (Exception e) {
            e.printStackTrace();
            fail("No exceptions are expected.");
        }
    }
}
