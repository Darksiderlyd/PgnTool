/**
 * TinyGo is a MIDlet to play and review Go board games.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, 
 * MA 02110-1301, USA.
 */
package com.sgfj;

import java.util.Enumeration;
import java.util.Vector;

/**
 * @author Alexey Klimkin
 *
 */
public class SGFNode {

    /**
     * Properties of the node.
     */
    protected Vector props = new Vector(0, 1);

    protected SGFNode prev = null;
    protected SGFNode next = null;
    protected SGFNode prevVariant = null;
    protected SGFNode nextVariant = null;
    protected SGFNode walkPath = null;

    public int bits;
    public static int GOOD_MOVE = 1;
    public static int BAD_MOVE  = 2;

    public final Enumeration getProperties() {
        return props.elements();
    }

    public final SGFNodeIterator iterator() {
        return new SGFNodeIterator(this);
    }

    public boolean equals(Object obj) {
        SGFNode node = (SGFNode) obj;
        if (node == null)
            return false;
        if (props.size() != node.props.size())
            return false;
        Enumeration e1 = props.elements();
        Enumeration e2 = node.props.elements();
        while (e1.hasMoreElements())
            if (!e1.nextElement().equals(e2.nextElement()))
                return false;
        if (!(nextVariant == node.nextVariant || nextVariant != null && nextVariant.equals(node.nextVariant)))
            return false;
        if (!(next == node.next || next != null && next.equals(node.next)))
            return false;
        return true;
    }

    public void add(SGFNode newChild) {
        newChild.prev = this;
        if (next == null) {
            next = newChild;
            //newChild.goodMove = goodMove;
        } else
            next.addVariant(newChild);
    }

    public void addVariant(SGFNode newVariant) {
        SGFNode p = this;
        while (p.nextVariant != null)
            p = p.nextVariant;
        p.nextVariant = newVariant;
        newVariant.prevVariant = p;
        newVariant.prev = prev;
        //if (prev != null)
            //newVariant.goodMove = prev.goodMove;
    }

    protected SGFNode newNode() {
        return new SGFNode();
    }

    public void play(SGFMove childMove) {
        SGFNode node;
        // try to find node with same move first
        for (node = next; node != null; node = node.nextVariant)  {
            try {
                SGFMove m = node.getMoveProperty();
                //System.out.println("play: " + childMove.toString() + ", variant: " + m.toString());
                if (m.equals(childMove))
                    break;
            } catch (SGFPropertyNotFoundException e) {
                // no move info in the node
                // DO NOTHING
            }
        }
        // new node should be created
        if (node == null) {
            node = newNode();
            node.addMoveProperty(childMove);
            add(node);
        }
        walkPath = node;
    }

    /*public void pass() {
        SGFNode node;
        // try to find node with same move first
        for (node = next; node != null; node = node.nextVariant)  {
            try {
                node.getMoveProperty();
            } catch (SGFPropertyNotFoundException e) {
                // no move node found
                break;
            }
        }
        // new node should be created
        if (node == null) {
            node = newNode();
            add(node);
        }
        walkPath = node;
    }*/

    /**
     * Remove node and node's subtree.
     */
    public void remove() {
        if (prev.next == this)
            // first variant, fix parent's child pointer
            prev.next = nextVariant;
        else
            prevVariant.nextVariant = nextVariant;
        if (nextVariant != null)
            nextVariant.prevVariant = null;
        if (prev.walkPath == this)
            prev.walkPath = (prevVariant != null ? prevVariant : (nextVariant != null ? nextVariant : null));
    }

    public void addProperty(SGFProperty p) {
        // TODO: add more robust fuctions to operate with properties
/*        for (Enumeration e = props.elements(); e.hasMoreElements(); ) {
            SGFProperty oldp = (SGFProperty) e.nextElement();
            if (oldp.hasSameName(p))
                break;
        }*/
        props.addElement(p);
    }

    public void addPropertyNoCheck(SGFProperty p) {
        props.addElement(p);
    }

    public boolean hasProperty(SGFPropertyName name) {
        for (Enumeration e = props.elements(); e.hasMoreElements(); ) {
            SGFProperty p = (SGFProperty) e.nextElement();
            if (p.name().equals(name))
                return true;
        }
        return false;
    }

    public SGFProperty getProperty(int nameCode) throws SGFPropertyNotFoundException {
        for (Enumeration e = props.elements(); e.hasMoreElements(); ) {
            SGFProperty p = (SGFProperty) e.nextElement();
            if (p.name().code == nameCode)
                return p;
        }
        throw new SGFPropertyNotFoundException();
    }

    public final SGFProperty getProperty(SGFPropertyName name) throws SGFPropertyNotFoundException {
        return getProperty(name.code);
    }

    public final SGFProperty getProperty(char[] name) throws SGFPropertyNotFoundException {
        short code = SGFPropertyName.toCode(name);
        return getProperty(code);
    }

    public String getCommentProperty() throws SGFPropertyNotFoundException {
        StringBuffer b = null;
        for (Enumeration e = props.elements(); e.hasMoreElements(); ) {
            SGFProperty prop = (SGFProperty) e.nextElement();
            if (prop.name().equals(SGFPropertyName.C)) {
                try {
                    String c = prop.getText();
                    if (b == null)
                        b = new StringBuffer(c);
                    else
                        b.append(c);
                } catch (SGFInvalidDataRequestException e1) {
                    // DO NOTHING
                }
            }
        }
        if (b == null)
            throw new SGFPropertyNotFoundException();
        return b.toString();
    }

    public boolean hasMoveProperty() {
        for (Enumeration e = props.elements(); e.hasMoreElements(); ) {
            SGFProperty p = (SGFProperty) e.nextElement();
            SGFPropertyName name = p.name();
            if (name.equals(SGFPropertyName.W) || name.equals(SGFPropertyName.B))
                return true;
        }
        return false;
    }

    public SGFMove getMoveProperty() throws SGFPropertyNotFoundException {
        for (Enumeration e = props.elements(); e.hasMoreElements(); ) {
            SGFProperty prop = (SGFProperty) e.nextElement();
            SGFPropertyName name = prop.name();
            try {
                if (name.equals(SGFPropertyName.W)) {
                    SGFPoint p = prop.getPoint();
                    return new SGFMove(p.x, p.y, SGFMove.WHITE);
                } else if (name.equals(SGFPropertyName.B)) {
                    SGFPoint p = prop.getPoint();
                    return new SGFMove(p.x, p.y, SGFMove.BLACK);
                }
            } catch (SGFInvalidDataRequestException ex) {
            }
        }
        throw new SGFPropertyNotFoundException();
    }

    public void addMoveProperty(SGFMove move) {
        SGFPropertyName name = null;
        if (move.color == SGFMove.WHITE)
            name = SGFPropertyName.W;
        else if (move.color == SGFMove.BLACK)
            name = SGFPropertyName.B;
        if (name != null)
            addProperty(new SGFPointProperty(name, new SGFPoint(move)));
    }

    public String toString() {
        String s = "";
        for (Enumeration e = props.elements(); e.hasMoreElements(); )
            s += e.nextElement().toString();
        return s;
    }

    public void eval(SGFNodeVisitor visitor) {
        Vector nodes = new Vector(4);

        nodes.addElement(this);
        for (int i = 0; i < nodes.size(); i++) {
            SGFNode node = (SGFNode) nodes.elementAt(i);
            for (SGFNode v = node.next; v != null; v = v.nextVariant)
                nodes.addElement(v);
        }

        // evaluate in backward run
        for (int i = nodes.size() - 1; i >= 0; i--) {
            SGFNode node = (SGFNode) nodes.elementAt(i);
            visitor.eval(node);
        }
    }
}
