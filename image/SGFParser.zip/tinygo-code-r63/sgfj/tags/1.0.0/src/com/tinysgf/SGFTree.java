/**
 * TinyGo is a MIDlet to play and review Go board games.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 */
package com.tinysgf;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.Hashtable;

/**
 * @author Alexey Klimkin
 *
 */
public class SGFTree {
	private static final int POSITION_BITS = 5;
	private static final int POSITION_MASK = 0x1f;

	public static final int NONE       = 0x07 << POSITION_BITS * 2;
	public static final int WHITE_MOVE = 0x00 << POSITION_BITS * 2;
	public static final int BLACK_MOVE = 0x02 << POSITION_BITS * 2;
	public static final int WHITE_PASS = 0x04 << POSITION_BITS * 2;
	public static final int BLACK_PASS = 0x06 << POSITION_BITS * 2;
	private static final int MOVE_PROPERTY_MASK = 0x07 << POSITION_BITS * 2;

	public static final int NULL = -1;
	public static final int ROOT = 0;

	private static final int MOVE_I    = 0;
	private static final int NEXT_I    = 1;
	private static final int PREV_I    = 2;
	private static final int NEXTV_I   = 3;
	private static final int NODE_SIZE = 4;

	int[] nodes;
	int capacityIncrement;
	int emptyNode;
	Hashtable properties = new Hashtable();

	public SGFTree() {
		this(256);
	}

	public SGFTree(int initialCapacity) {
		this(initialCapacity, initialCapacity);
	}

	public SGFTree(int initialCapacity, int capacityIncrement) {
		this.capacityIncrement = capacityIncrement;
		nodes = new int[initialCapacity * NODE_SIZE];
		for (int i = 0; i < nodes.length; i++)
			nodes[i] = NULL;
		emptyNode = ROOT;
	}

	void grow() {
		int newLength = nodes.length + capacityIncrement * NODE_SIZE;
		//System.out.println("Tree grow: " + nodes.length + " -> " + newLength);
		int[] _nodes = new int[newLength];
		for (int i = nodes.length; i < _nodes.length; i++)
			_nodes[i] = NULL;
		System.arraycopy(nodes, 0, _nodes, 0, nodes.length);
		emptyNode = nodes.length;
		nodes = _nodes;
	}

	void invalidate(int node) {
		for (int i = 0; i < NODE_SIZE; i++)
			nodes[node + i] = NULL;
	}

	public final int getMoveProperty(int nodeId) {
		return nodes[nodeId + MOVE_I] & MOVE_PROPERTY_MASK;
	}

	public final void setMoveProperty(int node, int moveProperty, int x, int y) {
		nodes[node + MOVE_I] = moveProperty | ((y & POSITION_MASK) << POSITION_BITS) | (x & POSITION_MASK);
	}

	public final int getMoveX(int node) {
		return nodes[node + MOVE_I] & POSITION_MASK;
	}

	public final int getMoveY(int node) {
		return (nodes[node + MOVE_I] >> POSITION_BITS) & POSITION_MASK;
	}

	public final int getNext(int node) {
		return nodes[node + NEXT_I];
	}

	public final int getPrev(int node) {
		return nodes[node + PREV_I];
	}

	public final int getNextVariant(int node) {
		return nodes[node + NEXTV_I];
	}

	public final int getFirstVariant(int node) {
		return nodes[nodes[node + PREV_I] + NEXT_I];
	}

	public int getHead(int node) {
		while (true) {
			int j = nodes[node + PREV_I];
			if (j == NULL)
				return node;
			node = j;
		}
	}

	public int newNode() {
		if (emptyNode == NULL)
			grow();

		int j = NULL;

		int node = emptyNode;
		boolean isVariant = false;
		// find leaf node
		while (true) {
			int n = nodes[node + NEXT_I];
			int v = nodes[node + NEXTV_I];
			if (n == NULL && v == NULL)
				break;
			j = node;
			isVariant = n == NULL;
			node = isVariant ? v : n;
		}
		if (node == emptyNode) {
			// advance, if no removed nodes left
			emptyNode += NODE_SIZE;
			if (emptyNode >= nodes.length)
				emptyNode = NULL;
		} else {
			// cut taken node from garbage and clean it
			nodes[j + (isVariant ? NEXTV_I : NEXT_I)] = NULL;
			nodes[node + MOVE_I] = nodes[node + PREV_I] = NULL; // leaf has other vars NULL already
		}

		return node;
	}

	public int newNode(int moveProperty, int x, int y) {
		int node = newNode();
		setMoveProperty(node, moveProperty, x, y);
		return node;
	}

	public int newNode(int parentNode, int moveProperty, int x, int y) {
		int node = newNode(moveProperty, x, y);
		linkNode(parentNode, node);
		return node;
	}

	public void linkNode(int parentNode, int node) {
		int j = nodes[parentNode + NEXT_I];
		if (j == NULL)
			nodes[parentNode + NEXT_I] = node;
		else
			linkVariant(j, node);
		nodes[node + PREV_I] = parentNode;
	}

	public void linkVariant(int node1, int node) {
		int j = node1;
		while (true) {
			int i = nodes[j + NEXTV_I];
			if (i == NULL)
				break;
			j = i;
		}
		nodes[j + NEXTV_I] = node;
	}

	public void removeNode(int node) {
		if (node == ROOT) {
			emptyNode = ROOT;
			invalidate(node);
		} else {
			int i = emptyNode;
			// link to the end of garbage
			while (nodes[i + NEXT_I] != NULL)
				i = nodes[i + NEXT_I];
			nodes[i + NEXT_I] = node;

			i = nodes[node + PREV_I];
			if (nodes[i + NEXT_I] == node)
				nodes[i + NEXT_I] = nodes[node + NEXTV_I];
			else {
				i = nodes[i + NEXT_I];
				while (nodes[i + NEXTV_I] != node)
					i = nodes[i + NEXTV_I];
				nodes[i + NEXTV_I] = nodes[node + NEXTV_I];
			}
		}
	}

	public void addProperty(int node, SGFProp props) {
		for (SGFProp p = props, pp = null; p != null; pp = p, p = p.next) {
            if (p.id == SGFProp.W) {
            	if (p.value.length == 0)
            		setMoveProperty(node, SGFTree.WHITE_PASS, 0, 0);
            	else {
            		int x = p.value[0] - 'a';
            		int y = p.value[1] - 'a';
            		setMoveProperty(node, SGFTree.WHITE_MOVE, x, y);
            	}
            	if (pp != null)
            		pp.next = p.next;
            	else
            		props = p.next;
            } else if (p.id == SGFProp.B) {
            	if (p.value.length == 0)
            		setMoveProperty(node, SGFTree.BLACK_PASS, 0, 0);
            	else {
            		int x = p.value[0] - 'a';
            		int y = p.value[1] - 'a';
            		setMoveProperty(node, SGFTree.BLACK_MOVE, x, y);
            	}
            	if (pp != null)
            		pp.next = p.next;
            	else
            		props = p.next;
            }
		}
		if (props != null)
			properties.put(new Integer(node), props);
	}

	void writeNode(Writer writer, int node) throws IOException {
		int moveProperty = getMoveProperty(node);
		if (moveProperty != NONE) {
			if (moveProperty == WHITE_PASS)
				writer.write("W[]");
			else if (moveProperty == BLACK_PASS)
				writer.write("B[]");
			else {
				char x = (char)('a' + getMoveX(node));
				char y = (char)('a' + getMoveY(node));
				if (moveProperty == WHITE_MOVE)
					writer.write("W[");
				else if (moveProperty == BLACK_MOVE)
					writer.write("B[");
				writer.write(x);
				writer.write(y);
				writer.write("]");
			}
		}
		SGFProp p = (SGFProp)properties.get(new Integer(node));
		for (; p != null; p = p.next)
			writer.write(p.toString());
	}

    void writeSequence(Writer writer, int node) throws IOException {
        for (; node != NULL && getNextVariant(node) == NULL; node = getNext(node)) {
            writer.write(';');
            writeNode(writer, node);
        }
        for (; node != NULL; node = getNextVariant(node)) {
            writer.write('(');
            writer.write(';');
            writeNode(writer, node);
            writeSequence(writer, getNext(node));
            writer.write(')');
        }
    }

    public void write(Writer writer, int node) throws IOException {
    	if (node == ROOT && getNextVariant(node) != NULL)
    		writeSequence(writer, node);
    	else {
    		writer.write('(');
    		writeSequence(writer, node);
    		writer.write(')');
    	}
    }

    public String toString() {
    	try {
			return toString(ROOT);
		} catch (IOException e) {
			return null;
		}
    }

    public String toString(int node) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        OutputStreamWriter w = new OutputStreamWriter(baos);
        write(w, node);
        w.close();
        return baos.toString();
    }
}
