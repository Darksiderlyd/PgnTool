/**
 * TinyGo is a MIDlet to play and review Go board games.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, 
 * MA 02110-1301, USA.
 */
package com.sgfj;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;

/**
 * @author Alexey Klimkin
 *
 */
public class SGFWriter {

    protected static void writeNode(Writer writer, SGFNode node) throws IOException {
        for (; node != null && node.nextVariant == null; node = node.next) {
            writer.write(';');
            writer.write(node.toString());
        }
        for (; node != null; node = node.nextVariant) {
            writer.write('(');
            writer.write(';');
            writer.write(node.toString());
            writeNode(writer, node.next);
            writer.write(')');
        }
    }

    public static void write(Writer writer, SGFNode root) throws IOException {
        writer.write('(');
        writeNode(writer, root);
        writer.write(')');
    }

    public static String toString(SGFNode tree) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        OutputStreamWriter w = new OutputStreamWriter(baos, "UTF8");
        write(w, tree);
        w.close();
        return baos.toString();
    }
}
