/**
 * TinyGo is a MIDlet to play and review Go board games.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, 
 * MA 02110-1301, USA.
 */
package com.sgfj;

/**
 * @author Alexey Klimkin
 *
 */
public class SGFFactory implements SGFFactoryInterface {

	public SGFNode newNode() {
		return new SGFNode();
	}

    public SGFProperty newProperty(SGFPropertyName name) {
        return new SGFProperty(name);
    }
    
    public SGFProperty newProperty(SGFPropertyName name, int value) {
        return new SGFIntProperty(name, value);
    }
    
    public SGFProperty newProperty(SGFPropertyName name, float value) {
        return new SGFFloatProperty(name, value);
    }
    
    public SGFProperty newProperty(SGFPropertyName name, char[] value) {
        return new SGFTextProperty(name, value);
    }

    public SGFProperty newProperty(SGFPropertyName name, SGFPoint value) {
        return new SGFPointProperty(name, value);
    }

    public SGFProperty newProperty(SGFPropertyName name, SGFPoint value, char[] label) {
        return new SGFLabelProperty(name, value, label);
    }
}
