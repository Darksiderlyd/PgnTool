/**
 * TinyGo is a MIDlet to play and review Go board games.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, 
 * MA 02110-1301, USA.
 */
package com.sgfj;


/**
 * @author Alexey Klimkin
 *
 */
public class SGFNodeIterator {

	protected SGFNode current;
	
	protected SGFNodeIterator(SGFNode node) {
		this.current = node;
	}
	
    public SGFNode first(boolean walk) {
        SGFNode p = current;
        while (p.prev != null)
            p = p.prev;
        if (walk)
            current = p;
        return p;
    }
    
    public final SGFNode current() {
    	return current;
    }
    
	public final SGFNode next(boolean walk) {
		if (current.next == null)
			return null;
		SGFNode node;
		if (current.walkPath == null)
			node = current.next;
		else
			node = current.walkPath;
		if (walk)
			current = current.walkPath = node;
		return node;
	}
	
	public final SGFNode prev(boolean walk) {
		if (!walk || current.prev == null)
			return current.prev;
		current.prev.walkPath = current;
		current = current.prev;
		return current;
	}

    public SGFNode firstVariant(boolean walk) {
        SGFNode p = current;
        while (p.prevVariant != null)
            p = p.prevVariant;
        if (walk)
            current = p;
        return p;
    }
    
	public final SGFNode nextVariant(boolean walk) {
		if (!walk || current.nextVariant == null)
			return current.nextVariant;
		current = current.prev.walkPath = current.nextVariant;
		return current;
	}
	
	public final SGFNode prevVariant(boolean walk) {
		if (!walk || current.prevVariant == null)
			return current.prevVariant;
		current = current.prev.walkPath = current.prevVariant;
		return current;
	}
}
