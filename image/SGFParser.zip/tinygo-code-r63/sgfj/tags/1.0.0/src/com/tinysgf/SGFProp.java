/**
 * TinyGo is a MIDlet to play and review Go board games.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 */
package com.tinysgf;

/**
 * @author Alexey Klimkin
 *
 */
public class SGFProp {
    public static final short C = 8259;
    public static final short B = 8258;
    public static final short W = 8279;
    public static final short SZ = 23123;
    public static final short LB = 16972;
    public static final short KM = 19787;

    public short id;
    public char[] value;
    public SGFProp next = null;

    public SGFProp() {
    }

    public SGFProp(short id, char[] value) {
        this.id = id;
        this.value = value;
    }

    public static final short toCode(char c0) {
        return (short) (c0 | (' ' << 8));
    }

    public static final short toCode(char c0, char c1) {
        return (short) (c0 | c1 << 8);
    }

    public static final short toCode(char[] name) {
        return name.length == 1 ? toCode(name[0]) : toCode(name[0], name[1]);
    }

    private int charIndex(char[] data, char c) {
        for (int i = 0; i < data.length; i++)
            if (data[i] == c)
                return i;
        return -1;
    }

    private static final int char2pos(char c) {
        return Character.toLowerCase(c) - 'a';
    }

    public String getLabel() {
        int i = charIndex(value, ':');
        return i < 0 ? null : new String(value).substring(i + 1);
    }

    public int getX() {
        if (value.length < 1)
            return -1;
        return char2pos(value[0]);
    }

    public int getY() {
        if (value.length < 2)
            return -1;
        return char2pos(value[1]);
    }

    public int getInt() {
        return Integer.parseInt(new String(value));
    }

    public float getFloat() {
        return Float.parseFloat(new String(value));
    }

    public String getText() {
        return new String(value);
    }

    public String toString() {
        char c0 = (char) (id & 0xff);
        char c1 = (char) (id >> 8);
        StringBuffer sb = new StringBuffer();
        sb.append(c0);
        if (c1 != ' ')
            sb.append(c1);
        sb.append('[');
        sb.append(value);
        sb.append(']');
        return sb.toString();
    }
}
