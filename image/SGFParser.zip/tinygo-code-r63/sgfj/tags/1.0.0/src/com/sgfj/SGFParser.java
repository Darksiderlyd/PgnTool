/**
 * TinyGo is a MIDlet to play and review Go board games.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 */
package com.sgfj;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.util.Vector;

/**
 * @author Alexey Klimkin
 * Parser of SGF
 * ================================================================
 *
 * SGF grammar:
 *
 * Collection = GameTree { GameTree }
 * GameTree   = "(" Sequence { GameTree } ")"
 * Sequence   = Node { Node }
 * Node       = ";" { Property }
 * Property   = PropIdent PropValue { PropValue }
 * PropIdent  = UcLetter { UcLetter }
 * PropValue  = "[" CValueType "]"
 * CValueType = (ValueType | Compose)
 * ValueType  = (None | Number | Real | Double | Color | SimpleText |
 *               Text | Point  | Move | Stone)
 *
 * The above grammar has a number of simple properties which enables us
 * to write a simpler parser:
 *   1) There is never a need for backtracking
 *   2) The only recursion is on gametree.
 *   3) Tokens are only one character
 *
 * We will use a global state to keep track of the remaining input
 * and a global char variable, `lookahead' to hold the next token.
 * The function `nexttoken' skips whitespace and fills lookahead with
 * the new token.
 */
public class SGFParser {

    protected static SGFFactoryInterface factory = new SGFFactory();
    public static int defaultBoardSize    = 19;

    protected static final int STRICT_SGF = 's';
    protected static final int LAX_SGF    = 'l';
    protected static final int EOF		  = -1;
    protected int lineNumber			  = 1;
    protected int charNumber			  = 1;
    protected int charsConsumed			  = 0;
    protected Reader sgffile	  		  = null;
    protected int lookahead;
    protected int boardSize;

    /* ---------------------------------------------------------------- */
    /*                       Parsing primitives                         */
    /* ---------------------------------------------------------------- */

    protected final static boolean isnl(int c) {
        return c == '\n' || c == '\r';
    }
    protected final static boolean isspace(int c) {
        //return Character.isWhitespace(c);
        return c == '\n' || c == '\r' || c == ' ' || c == '\t';
    }
    protected final static boolean isupper(int c) {
        //return Character.isUpperCase(c);
        return 'A' <= c && c <= 'Z';
    }
    protected final static boolean isalpha(int c) {
        //return Character.isLetter(c);
        return ('A' <= c && c <= 'Z') || ('a' <= c && c <= 'z');
    }

    protected int sgf_getch() throws IOException, SGFEOFException {
        int val = sgffile.read();
        if (val == EOF)
            throw new SGFEOFException(lineNumber, charNumber, "Unexpected end of file.");
        charsConsumed++;
        if (isnl(val)) {
            lineNumber++;
            charNumber = 0;
        } else
            charNumber++;
        return val;
    }

    protected void nexttoken() throws IOException, SGFEOFException {
        do {
            lookahead = sgf_getch();
        } while (isspace(lookahead));
    }

    protected void match(int expected) throws SGFParseError, IOException {
        if (lookahead != expected)
            throw new SGFParseError(lineNumber, charNumber, "expected: " + (char)expected);
        else
            nexttoken();
    }

    /* ---------------------------------------------------------------- */
    /*                        The parser proper                         */
    /* ---------------------------------------------------------------- */

    protected char[] propident() throws SGFParseError, IOException {
        char[] buffer = new char[2];
        int size = buffer.length;
        int p = 0;

        if (lookahead == EOF || !isupper(lookahead))
            throw new SGFParseError(lineNumber, charNumber, "Expected an upper case letter.");

        while (lookahead != EOF && isalpha(lookahead)) {
            if (isupper(lookahead) && size > 0) {
                buffer[p++] = (char) lookahead;
                size--;
            }
            nexttoken();
        }

        if (p == 1)
            buffer[p] = ' ';

        return buffer;
    }

    protected char[] propvalue() throws SGFParseError, IOException {
        char[] buffer = new char[40000];
        int size = buffer.length;
        int p = 0;

        match('[');
        while (lookahead != ']' && lookahead != EOF) {
            if (lookahead == '\\') {
                lookahead = sgf_getch();
                /* Follow the FF4 definition of backslash */
                if (lookahead == '\r') {
                    lookahead = sgf_getch();
                    if (lookahead == '\n')
                        lookahead = sgf_getch();
                }
                else if (lookahead == '\n') {
                    lookahead = sgf_getch();
                    if (lookahead == '\r')
                        lookahead = sgf_getch();
                }
            }
            if (size > 1) {
                buffer[p++] = (char) lookahead;
                size--;
            }
            lookahead = sgf_getch();
        }
        match(']');

        /* Remove trailing whitespace */
        while (--p > 0 && isspace(buffer[p]))
            // DO NOTHING
            ;
        ++p;
        char[] result = new char[p];
        System.arraycopy(buffer, 0, result, 0, p);
        return result;
    }

    protected SGFProperty proptype(SGFPropertyName name, char[] value) throws SGFParseError {
        try {
            if (name.hasInt()) {
                int ivalue = Integer.parseInt(new String(value));
                if (name.equals(SGFPropertyName.SZ))
                    boardSize = ivalue;
                return factory.newProperty(name, ivalue);
            } else if (name.hasFloat()) {
                float fvalue = Float.parseFloat(new String(value));
                return factory.newProperty(name, fvalue);
            } else if (name.hasPoint()) {
                SGFPoint pvalue = new SGFPoint();
                if (value.length < 2)
                    pvalue.x = pvalue.y = -1;
                else {
                    pvalue.x = Character.toUpperCase(value[0]) - 'A';
                    pvalue.y = Character.toUpperCase(value[1]) - 'A';
                    /*if (pvalue.x < 0 || pvalue.x >= boardSize || pvalue.y < 0 || pvalue.y >= boardSize)
                    throw new SGFParseError(lineNumber, charNumber,
                            "Point is out of goban: " + pvalue.x + ":" + pvalue.y);*/
                    if (name.hasText()) {
                        char[] label = new char[value.length - 3]; // aa:A
                        System.arraycopy(value, 3, label, 0, label.length);
                        return factory.newProperty(name, pvalue, label);
                    }
                }
                return factory.newProperty(name, pvalue);
            } else {
                return factory.newProperty(name, value);
            }
        } catch (NumberFormatException e) {
            throw new SGFParseError(lineNumber, charNumber, e.toString());
        }
    }

    protected void property(SGFNode n) throws SGFParseError, IOException {
        char[] name = propident();
        do {
            char[] value = propvalue();
            SGFPropertyName sgf_name = parsePropertyName(name);
            if (sgf_name.allowingRange()
                && value.length == 5
                && value[2] == ':') {
                char x1 = value[0];
                char y1 = value[1];
                char x2 = value[3];
                char y2 = value[4];
                char[] new_value = "xy".toCharArray();

                if (x1 <= x2 && y1 <= y2) {
                    for (new_value[0] = x1; new_value[0] <= x2; new_value[0]++) {
                        for (new_value[1] = y1; new_value[1] <= y2; new_value[1]++)
                            n.addPropertyNoCheck(proptype(sgf_name, new_value));
                    }
                }
            } else {
                n.addPropertyNoCheck(proptype(sgf_name, value));
            }
        } while (lookahead == '[');
    }

    protected void node(SGFNode n) throws SGFParseError, IOException {
        match(';');
        while (lookahead != EOF && isupper(lookahead))
            property(n);
    }

    protected SGFNode sequence(SGFNode n) throws SGFParseError, IOException {
        node(n);
        while (lookahead == ';') {
            SGFNode new_node = factory.newNode();
            n.add(new_node);
            n = new_node;
            node(n);
        }
        return n;
    }

    protected SGFNode gametree(SGFNode parent, int mode) throws SGFParseError, IOException {
        if (mode == STRICT_SGF)
            match('(');
        else {
            while (lookahead != '(')
                nexttoken();
            while (lookahead != ';')
                nexttoken();
        }

        SGFNode head = factory.newNode();
        SGFNode last = sequence(head);
        while (lookahead == '(')
            last.add(gametree(last, STRICT_SGF));
        if (mode == STRICT_SGF)
            match(')');

        return head;
    }

    protected SGFNode gamehead(int mode) throws SGFParseError, IOException {
        if (mode == STRICT_SGF)
            match('(');
        else {
            while (lookahead != '(')
                nexttoken();
            while (lookahead != ';')
                nexttoken();
        }

        SGFNode head = factory.newNode();
        node(head);
        return head;
    }

    private static boolean hasComment(SGFNode node, String value) {
        try {
            String c = node.getCommentProperty();
            return c.indexOf(value) >= 0;
        } catch (SGFPropertyNotFoundException e) {
        }
        return false;
    }

    public static void parseMoveHintsProperties(SGFNode head) {
        boolean hasRIGHT = false;
        Vector nodes = new Vector(4);

        // check if we have RIGHT marks
        nodes.addElement(head);
        for (int i = 0; i < nodes.size(); i++) {
            SGFNode node = (SGFNode) nodes.elementAt(i);
            hasRIGHT |= hasComment(node, "RIGHT");
            for (SGFNode v = node.next; v != null; v = v.nextVariant)
                nodes.addElement(v);
        }

        // evaluate hints in backward run
        for (int i = nodes.size() - 1; i >= 0; i--) {
            SGFNode node = (SGFNode) nodes.elementAt(i);
            boolean goodMove;
            if (node.next == null) {
                boolean right = hasComment(node, "RIGHT");
                boolean wrong = hasComment(node, "WRONG");
                goodMove = right || (!hasRIGHT && !wrong);
            } else {
                goodMove = false;
                for (SGFNode v = node.next; v != null; v = v.nextVariant)
                    if ((v.bits & SGFNode.GOOD_MOVE) != 0) {
                        goodMove = true;
                        break;
                    }
            }
            node.bits |= goodMove ? SGFNode.GOOD_MOVE : SGFNode.BAD_MOVE;
        }
    }

    public static SGFPropertyName parsePropertyName(char[] name) {
        short code = SGFPropertyName.toCode(name);
        SGFPropertyName result = (SGFPropertyName) SGFPropertyName.knownNames.get(new Short(code));
        if (result == null)
            result = new SGFPropertyName(code);
        return result;
    }

    public SGFParser(Reader reader) {
        sgffile = reader;
    }

    public SGFParser(String data) {
        ByteArrayInputStream bais = new ByteArrayInputStream(data.getBytes());
        try {
            sgffile = new InputStreamReader(bais, "UTF8");
        } catch (UnsupportedEncodingException e) {
            sgffile = new InputStreamReader(bais);
        }
    }

    public int getCharsConsumed() {
        return charsConsumed;
    }

    /**
     * Read and parse stream into SGFNode tree.
     *
     * @param  reader   Input stream to read characters from.
     * @return Parsed   SGF tree.
     * @throws SGFParseError    Error occured while parsing data.
     * @throws IOException      Error occured while reading input stream.
     * @throws SGFEOFException
     */
    public SGFNode parse() throws SGFParseError, IOException, SGFEOFException {
        boardSize = defaultBoardSize;
        nexttoken();
        return gametree(null, LAX_SGF);
    }

    public SGFNode parseHead() throws SGFParseError, IOException, SGFEOFException {
        boardSize = defaultBoardSize;
        nexttoken();
        return gamehead(LAX_SGF);
    }

    public SGFNode parseProblem() throws SGFParseError, IOException, SGFEOFException {
        SGFNode tree = parse();
        parseMoveHintsProperties(tree);
        return tree;
    }

}
