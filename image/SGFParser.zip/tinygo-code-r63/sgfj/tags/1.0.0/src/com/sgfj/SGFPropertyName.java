/**
 * TinyGo is a MIDlet to play and review Go board games.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, 
 * MA 02110-1301, USA.
 */
package com.sgfj;

import java.util.Hashtable;

/**
 * @author Alexey Klimkin
 *
 */
public final class SGFPropertyName {

    protected short code;
    protected byte  type;

    protected static final byte NONE  = 0;
    protected static final byte INT   = 1;
    protected static final byte FLOAT = 2;
    protected static final byte TEXT  = 4;
    protected static final byte POINT = 8;
    protected static final Hashtable knownNames = new Hashtable(128);

    protected SGFPropertyName(int nameCode) {
        code = (short) nameCode;
        type = TEXT;
        knownNames.put(new Short(code), this);
    }

    protected SGFPropertyName(int nameCode, int propertyType) {
        code = (short) nameCode;
        type = (byte) propertyType;
        knownNames.put(new Short(code), this);
    }

    protected static short toCode(char[] name) {
        short code;
        if (name.length == 1)
            code = (short) (name[0] | (' ' << 8));
        else
            code = (short) (name[0] | (name[1] << 8));
        return code;
    }

    public static boolean isKnown(char[] name) {
        short code = toCode(name);
        return knownNames.containsKey(new Short(code));
    }

    public final boolean equals(Object obj) {
        return code == ((SGFPropertyName)obj).code;
    }

    public final int hashCode() {
        return code;
    }

    public char[] toCharArray() {
        char c0 = (char) (code & 0xff);
        char c1 = (char) (code >> 8);
        if (c1 == ' ')
            return new char[]{c0};
        else
            return new char[]{c0, c1};
    }

    public String toString() {
        return new String(toCharArray());
    }

    public boolean allowingRange() {
        int i;
        for (i = 0; i < propertiesAllowingRanges.length; i++)
            if (code == propertiesAllowingRanges[i].code)
                return true;
        return false;
    }

    public final boolean isNone() {
        return type == NONE;
    }

    public final boolean hasInt() {
        return (type & INT) != 0;
    }

    public final boolean hasFloat() {
        return (type & FLOAT) != 0;
    }

    public final boolean hasText() {
        return (type & TEXT) != 0;
    }

    public final boolean hasPoint() {
        return (type & POINT) != 0;
    }

    // The rest are constant definitions
    //
    /* # */
    /* # This document was taken from the SGF Specfication. See: */
    /* # http://www.red-bean.com/sgf/ */
    /* # */
    /* # [SGF FF[4] - Smart Game Format] */
    /* # */
    /* # FF[4] property index */
    /* # */
    /* # This is an alphabetical index to all properties defined in FF[4]. */
    /* # New properties are marked with '*', changed properties are marked with '!'. */
    /* # */
    /* #ID   Description     property type    property value */
    /* #---- --------------- ---------------  -------------------------------------- */
         /**  Add Black       setup            list of stone */
    public static final SGFPropertyName    AB = new SGFPropertyName(16961, POINT);
         /**  Add Empty       setup            list of point */
    public static final SGFPropertyName    AE = new SGFPropertyName(17729, POINT);
         /**  Annotation      game-info        simpletext */
    public static final SGFPropertyName    AN = new SGFPropertyName(20033);
         /**  Application     root             composed simpletext ':' simpletext */
    public static final SGFPropertyName    AP = new SGFPropertyName(20545);
         /**  Arrow           -                list of composed point ':' point */
    public static final SGFPropertyName    AR = new SGFPropertyName(21057, POINT);
         /**  Who adds stones - (LOA)          simpletext */
    public static final SGFPropertyName    AS = new SGFPropertyName(21313);
         /**  Add White       setup            list of stone */
    public static final SGFPropertyName    AW = new SGFPropertyName(22337, POINT);
         /**  Black           move             move */
    public static final SGFPropertyName    B = new SGFPropertyName(8258, POINT);
         /**  Black time left move             real */
    public static final SGFPropertyName    BL = new SGFPropertyName(19522);
         /**  Bad move        move             double */
    public static final SGFPropertyName    BM = new SGFPropertyName(19778);
         /**  Black rank      game-info        simpletext */
    public static final SGFPropertyName    BR = new SGFPropertyName(21058);
         /**  Black team      game-info        simpletext */
    public static final SGFPropertyName    BT = new SGFPropertyName(21570);
         /**  Comment         -                text */
    public static final SGFPropertyName    C = new SGFPropertyName(8259);
         /**  Charset         root             simpletext */
    public static final SGFPropertyName    CA = new SGFPropertyName(16707);
         /**  Copyright       game-info        simpletext */
    public static final SGFPropertyName    CP = new SGFPropertyName(20547);
         /**  Circle          -                list of point */
    public static final SGFPropertyName    CR = new SGFPropertyName(21059, POINT);
         /**  Dim points      - (inherit)      elist of point */
    public static final SGFPropertyName    DD = new SGFPropertyName(17476, POINT);
         /**  Even position   -                double */
    public static final SGFPropertyName    DM = new SGFPropertyName(19780);
         /**  Doubtful        move             none */
    public static final SGFPropertyName    DO = new SGFPropertyName(20292, NONE);
         /**  Date            game-info        simpletext */
    public static final SGFPropertyName    DT = new SGFPropertyName(21572);
         /**  Event           game-info        simpletext */
    public static final SGFPropertyName    EV = new SGFPropertyName(22085);
         /**  Fileformat      root             number (range: 1-4) */
    public static final SGFPropertyName    FF = new SGFPropertyName(17990, INT);
         /**  Figure          -                none | composed number ":" simpletext */
    public static final SGFPropertyName    FG = new SGFPropertyName(18246);
         /**  Good for Black  -                double */
    public static final SGFPropertyName    GB = new SGFPropertyName(16967);
         /**  Game comment    game-info        text */
    public static final SGFPropertyName    GC = new SGFPropertyName(17223);
         /**  Game            root             number (range: 1-5,7-16) */
    public static final SGFPropertyName    GM = new SGFPropertyName(19783, INT);
         /**  Game name       game-info        simpletext */
    public static final SGFPropertyName    GN = new SGFPropertyName(20039);
         /**  Good for White  -                double */
    public static final SGFPropertyName    GW = new SGFPropertyName(22343);
         /**  Handicap        game-info (Go)   number */
    public static final SGFPropertyName    HA = new SGFPropertyName(16712, INT);
         /**  Hotspot         -                double */
    public static final SGFPropertyName    HO = new SGFPropertyName(20296);
         /**  Initial pos.    game-info (LOA)  simpletext */
    public static final SGFPropertyName    IP = new SGFPropertyName(20553);
         /**  Interesting     move             none */
    public static final SGFPropertyName    IT = new SGFPropertyName(21577, NONE);
         /**  Invert Y-axis   game-info (LOA)  simpletext */
    public static final SGFPropertyName    IY = new SGFPropertyName(22857);
         /**  Komi            game-info (Go)   real */
    public static final SGFPropertyName    KM = new SGFPropertyName(19787, FLOAT);
         /**  Ko              move             none */
    public static final SGFPropertyName    KO = new SGFPropertyName(20299, NONE);
         /**  Label           -                list of composed point ':' simpletext */
    public static final SGFPropertyName    LB = new SGFPropertyName(16972, POINT | TEXT);
         /**  Line            -                list of composed point ':' point */
    public static final SGFPropertyName    LN = new SGFPropertyName(20044, POINT);
         /**  Mark            -                list of point */
    public static final SGFPropertyName    MA = new SGFPropertyName(16717, POINT);
         /**  set move number move             number */
    public static final SGFPropertyName    MN = new SGFPropertyName(20045, INT);
         /**  Nodename        -                simpletext */
    public static final SGFPropertyName    N = new SGFPropertyName(8270);
         /**  OtStones Black  move             number */
    public static final SGFPropertyName    OB = new SGFPropertyName(16975, INT);
         /**  Opening         game-info        text */
    public static final SGFPropertyName    ON = new SGFPropertyName(20047);
         /**  Overtime        game-info        simpletext */
    public static final SGFPropertyName    OT = new SGFPropertyName(21583);
         /**  OtStones White  move             number */
    public static final SGFPropertyName    OW = new SGFPropertyName(22351, INT);
         /**  Player Black    game-info        simpletext */
    public static final SGFPropertyName    PB = new SGFPropertyName(16976);
         /**  Place           game-info        simpletext */
    public static final SGFPropertyName    PC = new SGFPropertyName(17232);
         /**  Player to play  setup            color */
    public static final SGFPropertyName    PL = new SGFPropertyName(19536);
         /**  Print move mode - (inherit)      number */
    public static final SGFPropertyName    PM = new SGFPropertyName(19792, INT);
         /**  Player White    game-info        simpletext */
    public static final SGFPropertyName    PW = new SGFPropertyName(22352);
         /**  Result          game-info        simpletext */
    public static final SGFPropertyName    RE = new SGFPropertyName(17746);
         /**  Round           game-info        simpletext */
    public static final SGFPropertyName    RO = new SGFPropertyName(20306);
         /**  Rules           game-info        simpletext */
    public static final SGFPropertyName    RU = new SGFPropertyName(21842);
         /**  Markup          - (LOA)          point */
    public static final SGFPropertyName    SE = new SGFPropertyName(17747, POINT);
         /**  Selected        -                list of point */
    public static final SGFPropertyName    SL = new SGFPropertyName(19539, POINT);
         /**  Source          game-info        simpletext */
    public static final SGFPropertyName    SO = new SGFPropertyName(20307);
         /**  Square          -                list of point */
    public static final SGFPropertyName    SQ = new SGFPropertyName(20819, POINT);
         /**  Style           root             number (range: 0-3) */
    public static final SGFPropertyName    ST = new SGFPropertyName(21587, INT);
         /**  Setup type      game-info (LOA)  simpletext */
    public static final SGFPropertyName    SU = new SGFPropertyName(21843);
         /**  Size            root             (number | composed number ':' number) */
    public static final SGFPropertyName    SZ = new SGFPropertyName(23123, INT);
         /**  Territory Black - (Go)           elist of point */
    public static final SGFPropertyName    TB = new SGFPropertyName(16980, POINT);
         /**  Tesuji          move             double */
    public static final SGFPropertyName    TE = new SGFPropertyName(17748);
         /**  Timelimit       game-info        real */
    public static final SGFPropertyName    TM = new SGFPropertyName(19796);
         /**  Triangle        -                list of point */
    public static final SGFPropertyName    TR = new SGFPropertyName(21076, POINT);
         /**  Territory White - (Go)           elist of point */
    public static final SGFPropertyName    TW = new SGFPropertyName(22356, POINT);
         /**  Unclear pos     -                double */
    public static final SGFPropertyName    UC = new SGFPropertyName(17237);
         /**  User            game-info        simpletext */
    public static final SGFPropertyName    US = new SGFPropertyName(21333);
         /**  Value           -                real */
    public static final SGFPropertyName    V = new SGFPropertyName(8278, FLOAT);
         /**  View            - (inherit)      elist of point */
    public static final SGFPropertyName    VW = new SGFPropertyName(22358, POINT);
         /**  White           move             move */
    public static final SGFPropertyName    W = new SGFPropertyName(8279, POINT);
         /**  White time left move             real */
    public static final SGFPropertyName    WL = new SGFPropertyName(19543);
         /**  White rank      game-info        simpletext */
    public static final SGFPropertyName    WR = new SGFPropertyName(21079);
         /**  White team      game-info        simpletext */
    public static final SGFPropertyName    WT = new SGFPropertyName(21591);

    /* # */
    /* # These are additions to the SGF spec- old commands and some others */
    /* # */

    /** Outdated FF3 property */
    public static final SGFPropertyName    BS = new SGFPropertyName(21314);
    /** Outdated FF3 property */
    public static final SGFPropertyName    WS = new SGFPropertyName(21335);
    /** Outdated FF3 property */
    public static final SGFPropertyName    ID = new SGFPropertyName(17481);
    /** Outdated FF3 property */
    public static final SGFPropertyName    RG = new SGFPropertyName(18258);
    /** Outdated FF3 property */
    public static final SGFPropertyName    SC = new SGFPropertyName(17235);

    /** Some random ones used by CGoban */
    public static final SGFPropertyName    SY = new SGFPropertyName(22867);

    /** Nonstandard SGF property used by GNU Go to mark illegal moves */
    public static final SGFPropertyName    IL = new SGFPropertyName(19529);

    /** GoProblems: genre
     *      best move
     *      elementary
     *      endgame
     *      fuseki
     *      joseki
     *      life and death
     *      tesuji */
    public static final SGFPropertyName    GE = new SGFPropertyName(17735);
    /** GoProblems: difficulty level (30k - 9d) */
    public static final SGFPropertyName    DI = new SGFPropertyName(18756);
    /** GoProblems: difficulty percentage */
    public static final SGFPropertyName    DP = new SGFPropertyName(20548, INT);
    /** GoProblems: coolness (1 - 10)*/
    public static final SGFPropertyName    CO = new SGFPropertyName(20291, INT);

    protected static final SGFPropertyName[] propertiesAllowingRanges = {
        /* Board setup properties. */
        AB, AW, AE,

        /* Markup properties. */
        CR, MA, SQ,
        TR, DD, SL,

        /* Miscellaneous properties. */
        VW,

        /* Go-specific properties. */
        TB, TW
    };
}
