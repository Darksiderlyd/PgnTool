/**
 * TinyGo is a MIDlet to play and review Go board games.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 */
package com.sgfj;

import java.util.Enumeration;

/**
 * @author Alexey Klimkin
 *
 */
public class SGFNodeBoundsVisitor implements SGFNodeVisitor {

    public int xrmin, yrmin, xrmax, yrmax;  // allowed range
    public int xmin, ymin, xmax, ymax;      // resulting bounds

    public SGFNodeBoundsVisitor(int xrmin, int yrmin, int xrmax, int yrmax) {
        this.xrmin = xrmin;
        this.yrmin = yrmin;
        this.xrmax = xrmax;
        this.yrmax = yrmax;
        this.xmin = xrmax + 1;
        this.ymin = yrmax + 1;
        this.xmax = xrmin - 1;
        this.ymax = yrmin - 1;
    }

    /**
     * @return False, if no points was found in spcified range.
     */
    public final boolean hasPoints() {
        return xmax != xrmin - 1;
    }

    /* (non-Javadoc)
     * @see com.sgf.SGFNodeVisitor#eval(com.sgf.SGFNode)
     */
    public void eval(SGFNode node) {
        for (Enumeration e = node.getProperties(); e.hasMoreElements(); ) {
            SGFProperty prop = (SGFProperty) e.nextElement();
            try {
                SGFPoint p = prop.getPoint();
                if (p.x >= xrmin && p.x <= xrmax && p.y >= yrmin && p.y <= yrmax) {
                    xmin = Math.min(xmin, p.x);
                    ymin = Math.min(ymin, p.y);
                    xmax = Math.max(xmax, p.x);
                    ymax = Math.max(ymax, p.y);
                }
            } catch (SGFInvalidDataRequestException e1) {
            }
        }
    }

}
