/**
 * TinyGo is a MIDlet to play and review Go board games.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 */
package com.tinygo.pdb;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.Vector;

import javax.microedition.io.Connector;
import javax.microedition.io.file.FileConnection;
import javax.microedition.io.file.FileSystemRegistry;
import javax.microedition.rms.InvalidRecordIDException;
import javax.microedition.rms.RecordStore;
import javax.microedition.rms.RecordStoreNotFoundException;

import com.sgfj.SGFEOFException;
import com.sgfj.SGFException;
import com.sgfj.SGFNode;
import com.sgfj.SGFParseError;
import com.sgfj.SGFParser;
import com.sgfj.SGFPropertyName;
import com.tinyutil.FilePath;

/**
 * @author Alexey Klimkin
 *
 */

public class DB {

    public final static int version = 1;
    private final static String MEGA_ROOT = FilePath.separator;
    private final static String rsName = "pdb";

    Vector problems;
    Vector genres;
    Vector paths;

    public void open(boolean clean) {
        if (!clean) {
            try {
                RecordStore rs = RecordStore.openRecordStore(rsName, false);
                byte[] data = rs.getRecord(1);
                rs.closeRecordStore();

                restore(new ByteArrayInputStream(data));
            } catch (RecordStoreNotFoundException e) {
                // DO NOTHING
            } catch (Exception e) {
                //#ifdef debug
                e.printStackTrace();
                //#endif
            }
        }
        if (problems == null)
            problems = new Vector();
        if (paths == null)
            paths = new Vector();
        if (genres == null)
            genres = new Vector();
    }

    public void close() {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            save(baos);

            byte[] data = baos.toByteArray();
            RecordStore rs = RecordStore.openRecordStore(rsName, true);
            try {
                rs.setRecord(1, data, 0, data.length);
            } catch (InvalidRecordIDException e) {
                rs.addRecord(data, 0, data.length);
            }
            rs.closeRecordStore();
        } catch (Exception e) {
            //#ifdef debug
            e.printStackTrace();
            //#endif
        }

        paths = null;
        genres = null;
        problems = null;
    }

    private void save(OutputStream os) throws IOException {
        DataOutputStream dout = new DataOutputStream(os);

        int n;

        n = paths.size();
        dout.writeInt(n);
        for (int i = 0; i < n; i++)
            dout.writeUTF((String)paths.elementAt(i));

        n = genres.size();
        dout.writeInt(n);
        for (int i = 0; i < n; i++)
            dout.writeUTF((String)genres.elementAt(i));

        n = problems.size();
        dout.writeInt(n);
        for (int i = 0; i < n; i++) {
            Problem r = (Problem)problems.elementAt(i);

            dout.writeInt(getSameObjectIndex(paths, r.path));
            dout.writeUTF(r.subPath == null ? "" : r.subPath);
            dout.writeInt(getSameObjectIndex(genres, r.genre));
            dout.writeBoolean(r.resource);
            dout.writeInt(r.offset);
            dout.writeByte(r.difficulty);
            dout.writeByte(r.difficultyP);
            dout.writeByte(r.popularity);
            dout.writeShort(r.tried);
            dout.writeShort(r.solved);
        }
    }

    private void restore(InputStream is) throws IOException {
        DataInputStream din = new DataInputStream(is);

        int n = din.readInt();
        if (paths == null)
            paths = new Vector(n);
        else
            paths.ensureCapacity(paths.size() + n);
        String[] lPaths = new String[n];
        for (int i = 0; i < n; i++)
            lPaths[i] = addPath(din.readUTF());

        n = din.readInt();
        if (genres == null)
            genres = new Vector(n);
        else
            genres.ensureCapacity(genres.size() + n);
        String[] lGenres = new String[n];
        for (int i = 0; i < n; i++)
            lGenres[i] = addGenre(din.readUTF());

        n = din.readInt();
        if (problems == null)
            problems = new Vector(n);
        else
            problems.ensureCapacity(problems.size() + n);
        for (int i = 0; i < n; i++) {
            Problem r = new Problem();

            r.path = lPaths[din.readInt()];
            r.subPath = din.readUTF();
            if (r.subPath.equals(""))
                r.subPath = null;
            r.genre = lGenres[din.readInt()];
            r.resource = din.readBoolean();
            r.offset = din.readInt();
            r.difficulty = din.readByte();
            r.difficultyP = din.readByte();
            r.popularity = din.readByte();
            r.tried = din.readShort();
            r.solved = din.readShort();

            problems.addElement(r);
        }
    }

    private void readIndex(String indexPath, InputStream is, boolean resource) throws IOException {
        DataInputStream din = new DataInputStream(is);

        int version = din.readByte();
        if (version != DB.version)
            // TODO
            ;
        boolean isDir = din.readBoolean();

        // First - read data completely

        int n = din.readInt();
        String[] lGenres = new String[n];
        for (int i = 0; i < n; i++)
            lGenres[i] = din.readUTF();

        n = din.readInt();
        Problem[] lProblems = new Problem[n];
        int[] genreMap = new int[n];
        for (int i = 0; i < n; i++) {
            Problem r = lProblems[i] = new Problem();
            r.subPath = isDir ? din.readUTF() : null;
            genreMap[i] = din.readInt();
            r.resource = resource;
            r.offset = din.readInt();
            r.difficulty = din.readByte();
            r.difficultyP = din.readByte();
            r.popularity = din.readByte();
            //System.out.println(r.offset);
        }

        // Now add complete read data to the database

        if (paths == null)
            paths = new Vector(1);
        String path;
        if (isDir) {
            // Dir index:  "path/name.sgfi" - index, "path/name + / + s" - file
            path = indexPath.substring(0, indexPath.length() - 5);
            path += FilePath.separatorChar;
        } else {
            // File index: "path/name.sgfi" - index, "path/name.sgf" - file
            path = indexPath.substring(0, indexPath.length() - 1);
        }
        removePath(path);
        path = addPath(path);

        if (genres == null)
            genres = new Vector(lGenres.length);
        else
            genres.ensureCapacity(genres.size() + lGenres.length);
        for (int i = 0; i < lGenres.length; i++)
            lGenres[i] = addGenre(lGenres[i]);

        if (problems == null)
            problems = new Vector(lProblems.length);
        else
            problems.ensureCapacity(problems.size() + lProblems.length);
        for (int i = 0; i < lProblems.length; i++) {
            Problem r = lProblems[i];
            r.path = path;
            r.genre = lGenres[genreMap[i]];
            problems.addElement(r);
        }
    }

    private final int getSameObjectIndex(Vector v, Object o) {
        for (int i = 0; i < v.size(); i++)
            if (v.elementAt(i) == o)
                return i;
        return -1;
    }

    private String addPath(String path) {
        int j = paths.indexOf(path);
        if (j < 0)
            paths.addElement(path);
        else
            path = (String)paths.elementAt(j);
        return path;
    }

    private String addGenre(String genre) {
        int j = genres.indexOf(genre);
        if (j < 0)
            genres.addElement(genre);
        else
            genre = (String)genres.elementAt(j);
        return genre;
    }

    public String[] getPaths() {
        String[] result = new String[paths.size()];
        paths.copyInto(result);
        return result;
    }

    public String[] getGenres() {
        String[] result = new String[genres.size()];
        genres.copyInto(result);
        return result;
    }

    public Problem getProblem(int i) {
        try {
            return (Problem)problems.elementAt(i);
        } catch (ArrayIndexOutOfBoundsException e) {
            return null;
        }
    }

    /*public int getProblemIndex(Problem prob) {
        return getSameObjectIndex(problems, prob);
    }*/

    public int addPath(String path, boolean rescan) throws IOException {
        System.out.println("Adding path to DB " + path);
        int probCnt = problems.size();

        if (path.endsWith(".sgfi")) {
            FileConnection fc = (FileConnection) Connector.open(
                    "file://localhost/" + path);
            readIndex(path, fc.openInputStream(), false);
        } else {
            rescan |= paths.indexOf(path) < 0;
            if (rescan) {
                removePath(path);
                path = addPath(path);
                FileConnection fc = (FileConnection) Connector.open(
                        "file://localhost/" + path);
                if (fc.isDirectory())
                    addDir(path, fc, path);
                else
                    addProblems(path, null, fc.openInputStream(), false);
            }
        }
        return problems.size() - probCnt;
    }

    private void addDir(final String path, FileConnection dir, final String topDir) throws IOException {
        System.out.println("Scanning directory " + path);
        Enumeration e;

        if (MEGA_ROOT.equals(path)) {
            dir = null;
            e = FileSystemRegistry.listRoots();
        } else
            e = dir.list();

        while (e.hasMoreElements()) {
            String p = path + (String) e.nextElement();

            FileConnection fc = (FileConnection) Connector.open(
                    "file://localhost/" + p);
            if (fc.isDirectory())
                addDir(p, fc, topDir);
            else {
                addProblems(p, topDir, fc.openInputStream(), false);
            }
            fc.close();
        }
    }

    public int addPath(String path, boolean rescan, InputStream is, boolean resource) throws IOException {
        System.out.println("Adding path to DB " + path);
        int probCnt = problems.size();

        if (path.endsWith(".sgfi"))
            readIndex(path, is, resource);
        else {
            rescan |= paths.indexOf(path) < 0;
            if (rescan) {
                removePath(path);
                path = addPath(path);
                addProblems(path, null, is, resource);
            }
        }
        return problems.size() - probCnt;
    }

    public void removePath(String path) {
        int i = paths.indexOf(path);
        if (i < 0)
            return;

        path = (String)paths.elementAt(i);
        paths.removeElementAt(i);

        for (i = 0; i < problems.size(); i++) {
            Problem r = (Problem)problems.elementAt(i);
            if (r.path == path)
                problems.removeElementAt(i--);
        }

        // TODO: update genres
    }

    public void removePathAll() {
        paths.removeAllElements();
        problems.removeAllElements();
        genres.removeAllElements();
    }

    public ProblemEnumeration enumerateRecords(Filter filter) {
        return new ProblemEnumeration(problems, filter);
    }

    private void addProblems(final String filePath, final String topDir, InputStream is, boolean resource) throws IOException {
        String path, subPath;
        if (topDir == null) {
            path = filePath;
            subPath = null;
        } else {
            path = topDir;
            subPath = filePath.substring(topDir.length());
        }

        InputStreamReader isr = new InputStreamReader(is);
        SGFParser parser = new SGFParser(isr);

        while (true) {
            int offset = parser.getCharsConsumed();

            // parse file to get tree
            SGFNode tree = null;
            try {
                tree = parser.parse();
            } catch (SGFEOFException e) {
                // DO NOTHING
                break;
            } catch (SGFParseError e) {
                System.out.println("Parse error " + filePath + ":" + e.getMessage());
                break;
            }
            if (tree == null) {
                System.out.println("Not SGF file or file read error, skip " + filePath + " at " + offset);
                break;
            }

            Problem entry = new Problem();
            entry.path = path;
            entry.subPath = subPath;
            entry.resource = resource;
            entry.offset = offset;

            try {
                entry.genre = tree.getProperty(SGFPropertyName.GE).getText();
            } catch (SGFException e) {
                entry.genre = "undefined";
            }
            int i = genres.indexOf(entry.genre);
            if (i < 0)
                genres.addElement(entry.genre);
            else
                entry.genre = (String)genres.elementAt(i);

            try {
                entry.difficulty = Filter.rank2int(tree.getProperty(SGFPropertyName.DI).getText());
            } catch (SGFException e) {
                entry.difficulty = 0;
            }
            try {
                entry.difficultyP = tree.getProperty(SGFPropertyName.DP).getInt();
            } catch (SGFException e) {
                entry.difficultyP = -1;
            }
            try {
                entry.popularity = tree.getProperty(SGFPropertyName.CO).getInt();
            } catch (SGFException e) {
                entry.popularity = -1;
            }

            entry.tried = 0;
            entry.solved = 0;

            problems.addElement(entry);

            System.out.println(filePath + " " + offset);
        }
    }
}
