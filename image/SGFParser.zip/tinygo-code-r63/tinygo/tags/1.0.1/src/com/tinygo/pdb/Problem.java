/**
 * TinyGo is a MIDlet to play and review Go board games.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 */
package com.tinygo.pdb;

/**
 * @author Alexey Klimkin
 *
 */
public class Problem {
    String path;     // file or top directory path
    String subPath;  // null or relative to directory path
    public boolean resource;
    public int offset;
    public String genre;
    public int difficulty;  // <0 = kyu, 0 = undefined, >0 = dan
    public int difficultyP; // percentage
    public int popularity;
    public int solved;
    public int tried;

    public final String filePath() {
        return subPath == null ? path : path + subPath;
    }
}
