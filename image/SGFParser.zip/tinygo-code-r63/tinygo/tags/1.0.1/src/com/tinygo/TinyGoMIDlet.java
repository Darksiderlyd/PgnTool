/**
 * TinyGo is a MIDlet to play and review Go board games.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 */
package com.tinygo;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Timer;

/*import javax.microedition.content.ContentHandlerException;
import javax.microedition.content.ContentHandlerServer;
import javax.microedition.content.Registry;
import javax.microedition.content.RequestListener;
import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;*/
import javax.microedition.lcdui.Display;
import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;
import javax.microedition.rms.InvalidRecordIDException;
import javax.microedition.rms.RecordStore;
import javax.microedition.rms.RecordStoreException;

import com.tinygo.gam.SoundPlayer;
import com.tinygo.gam.TileT2DPainter;
import com.tinygo.logic.TimeSystem;
import com.tinygo.pdb.DB;
import com.tinyutil.T;

/**
 * @author Alexey Klimkin
 *
 */
public class TinyGoMIDlet extends MIDlet /*implements RequestListener*/ {

    private static final String rsStateName = "TinyGoState";

    private String version;
    private Display display;
    private DB pdb;
    private TimeSystem timeSystem;
    private GobanCanvas gobanCanvas;
    private MenuScreen menuScreen;
    private StatusScreen statusScreen;
    private Controller controller;

    static String[] problemCollections = {
        "/sgf/example.sgfi"
    };
    /**
     *
     */
    public TinyGoMIDlet() {
        // Register the listener to be notified of new requests
/*        try {
            System.out.println(getClass().getName());
            Registry.getServer(getClass().getName()).setListener(this);
        } catch (ContentHandlerException e) {
            e.printStackTrace();
        }*/

        version = getAppProperty("MIDlet-Version");

        //T.setLocale("ru-RU");
        T.setLocale(System.getProperty("microedition.locale"));
        display = Display.getDisplay(this);

        WaitCanvas wc = WaitCanvas.getInstance();
        wc.setText(T._("Initializing..."));
        wc.setProgress(0);
        display.setCurrent(wc);
    }

    protected void startApp() throws MIDletStateChangeException {
        //System.out.println(System.getProperty("microedition.io.file.FileConnection.version"));

        WaitCanvas wc = WaitCanvas.getInstance();
        wc.setProgress(10);

        pdb = new DB();

        Timer timer = new Timer();
        timeSystem = new TimeSystem(timer);

        gobanCanvas = new GobanCanvas(display, new TileT2DPainter());

        SoundPlayer snd = new SoundPlayer(display);
        menuScreen = new MenuScreen(this, display, pdb);
        statusScreen = new StatusScreen(display, timer, timeSystem);

        controller = new Controller(this, display, snd,
                pdb, timeSystem,
                gobanCanvas, menuScreen, statusScreen);
        gobanCanvas.setController(controller);
        menuScreen.setListener(controller);
        statusScreen.setListener(controller);
        timeSystem.setListener(controller);

        wc.setProgress(20);
        wc.setText(T._("Restoring..."));
        restore();
        wc.setProgress(100);
        wc.serviceRepaints();
        display.callSerially(new Runnable() {
            public void run() {
                controller.activate();
            }
        });
    }

    private void initPDB() {
        for (int i = 0; i < problemCollections.length; i++) {
            String path = problemCollections[i];
            InputStream is = getClass().getResourceAsStream(path);
            try {
                pdb.addPath(path, false, is, true);
            } catch (IOException e) {
                // DO NOTHING
                //#if debug
                e.printStackTrace();
                //#endif
            }
        }
    }

    protected void destroyApp(boolean arg0) {
        WaitCanvas wc = WaitCanvas.getInstance();
        wc.setText(T._("Saving..."));
        wc.setProgress(0);
        display.setCurrent(wc);
        save();
        wc.setProgress(100);
        wc.serviceRepaints();
    }

    protected void pauseApp() {
    }

    public void exit() {
        destroyApp(false);
        notifyDestroyed();
    }

    private void save() {
        //#ifdef debug
        System.out.println("SAVE");
        //#endif

        WaitCanvas wc = WaitCanvas.getInstance();

        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            DataOutputStream dout = new DataOutputStream(baos);
            dout.writeUTF(version);
            gobanCanvas.save(dout);
            wc.setProgress(5);
            controller.save(dout);
            wc.setProgress(10);
            menuScreen.save(dout);
            wc.setProgress(20);
            timeSystem.save(dout);
            wc.setProgress(30);
            byte[] data = baos.toByteArray();
            RecordStore rs = RecordStore.openRecordStore(rsStateName, true);
            try {
                rs.setRecord(1, data, 0, data.length);
            } catch (InvalidRecordIDException e) {
                rs.addRecord(data, 0, data.length);
            }
            rs.closeRecordStore();
        } catch (Exception e) {
            //#if debug
            e.printStackTrace();
            //#endif
        }

        wc.setProgress(60);
        pdb.close();

        //#ifdef debug
        System.out.println("SAVE DONE");
        //#endif
    }

    private void restore() {
        //#ifdef debug
        System.out.println("RESTORE");
        //#endif

        WaitCanvas wc = WaitCanvas.getInstance();

        try {
            DataInputStream din;

            try {
                RecordStore rs = RecordStore.openRecordStore(rsStateName, false);
                byte[] data = rs.getRecord(1);
                rs.closeRecordStore();
                din = new DataInputStream(new ByteArrayInputStream(data));
                if (!din.readUTF().equals(version)) {
                    din = null;
                    //#ifdef debug
                    System.out.println("Clean run: Version mismatch!");
                    //#endif
                }
            } catch (RecordStoreException e) {
                din = null;
                //#ifdef debug
                System.out.println("Clean run: " + e.toString());
                //#endif
            }

            wc.setProgress(5);
            pdb.open(din == null);
            wc.setProgress(40);
            if (pdb.getPaths().length == 0)
                initPDB();
            menuScreen.probUpdateFromPDB();

            if (din != null) {
                wc.setProgress(65);
                gobanCanvas.restore(din);
                wc.setProgress(70);
                controller.restore(din);
                wc.setProgress(75);
                menuScreen.restore(din);
                wc.setProgress(80);
                timeSystem.restore(din);
            }
        } catch (IOException e) {
            //#ifdef debug
            e.printStackTrace();
            //#endif
        }

        //#ifdef debug
        System.out.println("RESTORE DONE");
        //#endif
    }

/*    public void invocationRequestNotify(ContentHandlerServer srv) {
        Alert a = new Alert("TinyGoMIDlet", "invocationRequestNotify() called from: " + srv.toString(),
                null, AlertType.INFO);
        a.setTimeout(Alert.FOREVER);
        display.setCurrent(a);
    }*/
}
