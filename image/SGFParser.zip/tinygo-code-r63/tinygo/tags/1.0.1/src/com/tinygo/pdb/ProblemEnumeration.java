/**
 * TinyGo is a MIDlet to play and review Go board games.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 */
package com.tinygo.pdb;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Random;
import java.util.Vector;

import com.tinyutil.QuickSort;

/**
 * @author Alexey Klimkin
 *
 */
public class ProblemEnumeration {
    Vector problemsFiltered;
    int current = -1;

    public ProblemEnumeration() {
    }

    protected ProblemEnumeration(Vector problems, Filter f) {
        problemsFiltered = new Vector();

        for (int i = 0; i < problems.size(); i++) {
            Problem candidate = (Problem)problems.elementAt(i);
            if (matches(f, candidate))
                problemsFiltered.addElement(new Integer(i));
        }
        //#ifdef debug
        System.out.println("" + problemsFiltered.size() + " problems filtered");
        //#endif

        if (f.sortByDifficulty != 0 || f.sortByGenre != 0 || f.sortByPopularity != 0)
            new QuickSort(new ProblemComparator(problems, f)).sort(problemsFiltered);
        else if (f.randomize) {
            Random rand = new Random();
            Vector shuffled = new Vector(problemsFiltered.size());
            while (problemsFiltered.size() > 0) {
                int i = rand.nextInt(problemsFiltered.size());
                shuffled.addElement(problemsFiltered.elementAt(i));
                problemsFiltered.removeElementAt(i);
            }
            problemsFiltered = shuffled;
        }
    }

    static boolean matches(Filter f, Problem candidate) {
        if (f.tried) {
            if (!f.solved && candidate.solved > 0)
                return false;
        } else if (candidate.tried > 0)
            return false;
        if (f.genre != null && f.genre != candidate.genre)
            return false;
        if (candidate.difficulty == 0) { // undefined
            if (!f.unrated)
                return false;
        } else if (candidate.difficulty < f.difficultyFrom
                || candidate.difficulty > f.difficultyTo)
            return false;
        if (f.excludePaths != null)
            for (int i = 0; i < f.excludePaths.length; i++)
                if (candidate.path == f.excludePaths[i])
                    return false;
        return true;
    }

    public boolean hasMoreElements() {
        return current < problemsFiltered.size() - 1;
    }

    public int nextElement() {
        int probI;
        int sz = problemsFiltered.size();
        if (sz > 0 && current < sz - 1)
            probI = ((Integer)problemsFiltered.elementAt(++current)).intValue();
        else
            probI = -1;
        return probI;
    }

    public int prevElement() {
        int probI;
        int sz = problemsFiltered.size();
        if (sz > 0 && current > 0)
            probI = ((Integer)problemsFiltered.elementAt(--current)).intValue();
        else
            probI = -1;
        return probI;
    }

    public int currentElement() {
        try {
            return ((Integer)problemsFiltered.elementAt(current)).intValue();
        } catch (ArrayIndexOutOfBoundsException e) {
            return -1;
        }
    }

    public int current() {
        return current;
    }

    public int size() {
        return problemsFiltered.size();
    }

    public void save(DataOutputStream dout) throws IOException {
        dout.writeInt(current);
        int sz = problemsFiltered.size();
        dout.writeInt(sz);
        for (int i = 0; i < sz; i++) {
            int ii = ((Integer)problemsFiltered.elementAt(i)).intValue();
            dout.writeInt(ii);
        }
    }

    public void restore(DataInputStream din) throws IOException {
        current = din.readInt();
        int sz = din.readInt();
        problemsFiltered = new Vector(sz);
        for (int i = 0; i < sz; i++) {
            problemsFiltered.addElement(new Integer(din.readInt()));
        }
    }
}
