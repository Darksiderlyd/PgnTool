/**
 * TinyGo is a MIDlet to play Go and review Go board game files.
 * Copyright (C) 2006 and 2007 Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 */
package com.tinygo;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Random;
import java.util.Stack;

import javax.microedition.io.Connector;
import javax.microedition.io.file.FileConnection;
import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Display;

import com.sgfj.SGFException;
import com.sgfj.SGFMove;
import com.sgfj.SGFNode;
import com.sgfj.SGFNodeBoundsVisitor;
import com.sgfj.SGFNodeIterator;
import com.sgfj.SGFParser;
import com.sgfj.SGFPoint;
import com.sgfj.SGFPropertyNotFoundException;
import com.sgfj.SGFWriter;
import com.tinygo.gam.SoundPlayer;
import com.tinygo.logic.Board;
import com.tinygo.logic.BouzyMap;
import com.tinygo.logic.DocumentedGame;
import com.tinygo.logic.GameException;
import com.tinygo.logic.Group;
import com.tinygo.logic.Score;
import com.tinygo.logic.TimeSystem;
import com.tinygo.logic.TimeSystemListener;
import com.tinygo.pdb.DB;
import com.tinygo.pdb.Problem;
import com.tinygo.pdb.ProblemEnumeration;
import com.tinysgf.SGFTree;
import com.tinyutil.T;

abstract class BasicMode {
    int igMenuID = MenuScreen.IG_NONE;
    boolean showCursor = false;
    boolean showVariants = false;
    boolean showMoyo = false;
    boolean markUnknownTerritory = false;
    boolean showNextMove = false;
    int commentLines = 0;
    boolean showMoveStatus = true;
    boolean showColorToPlayIndicator = false;
    boolean showSolvedFailedIndicator = false;
    boolean showFailedImmediately = false;
    boolean showTimer = false;
    void reset() {
    }
    boolean doPlay() {
        return false;
    }
    boolean doPass() {
        return false;
    }
    boolean doNextMode() {
        return false;
    }
    boolean keyPressed(int keyCode) throws SGFException, GameException {
        return false;
    }
    boolean keyReleased(int keyCode) throws SGFException, GameException {
        return false;
    }
    boolean keyHeld(int keyCode) throws SGFException, GameException {
        return false;
    }
}

/**
 * @author Alexey Klimkin
 *
 */
class Controller implements MenuScreenListener, StatusScreenListener, TimeSystemListener {
    static final byte PLAY_MODE  = 1;
    static final byte VIEW_MODE  = 2;
    static final byte SCORE_MODE = 3;
    static final byte PROB_MODE  = 4;

    private static final byte ZOOM_AUTO = 0;
    private static final byte ZOOM_OUT 	= 1;
    private static final byte ZOOM_IN 	= 2;
    private static final byte ZOOM_MAX 	= 3;

    private class PlayMode extends BasicMode {
        PlayMode() {
            igMenuID = MenuScreen.IG_PLAY;
            showCursor = true;
            showVariants = true;
        }
        boolean doPlay() {
            try {
                game.play(cursorX, cursorY);
                snd.playStoneSound(game.colorToPlay == Board.WHITE);
                timeSystem.turn();
            } catch (GameException e) {
                snd.playIllegalMoveSound();
            }
            return true;
        }
        boolean doPass() {
            try {
                game.pass();
                snd.playPassSound();
            } catch (GameException e) {
                // DO NOTHING
            }
            return true;
        }
        boolean doUndo() {
            return game.prev();
        }
        boolean doNextMode() {
            stopRepeating();
            return setMode(viewMode);
        }
        boolean keyPressed(int keyCode) throws SGFException, GameException {
            boolean notify = false;

            switch (keyCode) {
//                case Canvas.KEY_NUM0:
//                    notify = doPass();
//                    break;
                case Canvas.KEY_NUM5:
                    notify = doPlay();
                    break;
                case Canvas.KEY_STAR:
                    notify = doUndo();
                    break;
                default:
                    notify = moveCursor(keyCode);
            }
            return notify;
        }
        boolean keyHeld(final int keyCode) throws SGFException, GameException {
            if (isCursorKey(keyCode))
                startRepeating(50, new Runnable() {
                    public void run() {
                        if (moveCursor(keyCode))
                            notifyGameUpdated();
                    }
                });
            return false;
        }
        boolean keyReleased(int keyCode) throws SGFException, GameException {
            stopRepeating();
            return false;
        }
    }
    private class ProblemMode extends PlayMode {
        boolean hasRespondMove = false;
        boolean freePlay = true;
        private boolean probFinished = false;
        private boolean probStarted = false;
        //SGFNode lastDocumentedNode = null;
        ProblemMode() {
            igMenuID = MenuScreen.IG_PROBLEM;
            showVariants = false;
            commentLines = 1;
            showMoveStatus = false;
            showSolvedFailedIndicator = true;
            showColorToPlayIndicator = true;
        }
        void reset() {
            probFinished = false;
            probStarted = false;
        }
        boolean doPlay() {
            try {
                if (!freePlay) {
                    // This code doesn't allow to play undocumented moves
                    //
                    SGFNodeIterator i = game.kifuLastMove().iterator();
                    if (i.next(true) == null)
                        return false;

                    // search for appropriate variant
                    SGFMove newMove = new SGFMove(cursorX, cursorY, game.colorToPlay);
                    SGFMove variantMove;
                    i.firstVariant(true);
                    do {
                        variantMove = i.current().getMoveProperty();
                    } while (!newMove.equals(variantMove) && i.nextVariant(true) != null);

                    if (!newMove.equals(variantMove))
                        return false;
                }

                game.play(cursorX, cursorY);
                snd.playStoneSound(game.colorToPlay == Board.WHITE);
                // show player's move
                notifyGameUpdated();

                if (!probStarted) {
                    if (probCurrent != null)
                        probCurrent.tried++;
                    probStarted = true;
                    statusScreen.setProblem(probCurrent, probEnum);
                }

                if (gobanCanvas.showMoveHints)
                    setCursorToNextGoodMove();
                else {
                    hasRespondMove = false;

                    SGFNodeIterator i = game.kifuLastMove().iterator();
                    if (i.next(true) != null) {
                        // play randomized response move

                        i.firstVariant(true);
                        int nGoodVariants = 0;
                        int nBadVariants = 0;

                        do {
                            if ((i.current().bits & SGFNode.GOOD_MOVE) != 0)
                                nGoodVariants++;
                            else if ((i.current().bits & SGFNode.BAD_MOVE) != 0)
                                nBadVariants++;
                        } while (i.nextVariant(true) != null);

                        // play response if there is good/bad hint
                        if (nGoodVariants > 0 || nBadVariants > 0) {
                            int k;
                            int mask;
                            Random rand = new Random();

                            if (nGoodVariants > 0) {
                                k = rand.nextInt(nGoodVariants);
                                mask = SGFNode.GOOD_MOVE;
                            } else {
                                k = rand.nextInt(nBadVariants);
                                mask = SGFNode.BAD_MOVE;
                            }
                            // k = 0 is valid good variant number, so in while it's >= 0
                            do {
                                if ((i.current().bits & mask) != 0)
                                    k--;
                            } while (k >= 0 && i.prevVariant(true) != null);

                            SGFMove variantMove = i.current().getMoveProperty();
                            game.play(variantMove.x, variantMove.y, variantMove.color);
                            snd.playStoneSound(game.colorToPlay == Board.WHITE);
                            // show response
                            notifyGameUpdated();

                            hasRespondMove = true;
                        }
                    }
                }

                if (!probFinished) {
                    SGFNodeIterator i = game.kifuLastMove().iterator();
                    boolean haveGoodMove = (i.current().bits & SGFNode.GOOD_MOVE) != 0;
                    probFinished = i.next(false) == null || !haveGoodMove;
                    if (probFinished) {
                        if (haveGoodMove) {
                            if (probCurrent != null)
                                probCurrent.solved++;
                            statusScreen.setProblem(probCurrent, probEnum);
                            snd.playProblemSolved();
                        } else
                            snd.playProblemFailed();
                    }
                }

                return false; // calling notify by ourselves

            } catch (GameException e) {
                snd.playIllegalMoveSound();
            } catch (SGFPropertyNotFoundException e) {
                //#if debug
                e.printStackTrace();
                //#endif
            }
            return false;
        }
        boolean doPass() {
            return false;
        }
        boolean doUndo() {
            SGFNode lastSetupNode = game.kifuFirstMove(true).iterator().prev(false);
            if (game.kifuLastMove() != lastSetupNode && game.prev()) {
                if (gobanCanvas.showMoveHints) {
                    setCursor(game.kifuLastMove().iterator().next(false));
                } else {
                    if (hasRespondMove && game.kifuLastMove() != lastSetupNode)
                        game.prev();
                    else
                        hasRespondMove = true;
                }
                return true;
            } else
                return false;
        }
        boolean doNextMode() {
            boolean showMoveHints = !gobanCanvas.showMoveHints;
            if (showMoveHints)
                setCursorToNextGoodMove();
            gobanCanvas.showMoveHints = showMoveHints;
            if (showMoveHints) {
                if (!probStarted) {
                    probStarted = true;
                    if (probCurrent != null)
                        probCurrent.tried++;
                    statusScreen.setProblem(probCurrent, probEnum);
                }
                if (!probFinished) {
                    probFinished = true;
                    snd.playProblemFailed();
                }
            }
            return true;
        }
        boolean doRestart() {
            boolean notify = false;
            SGFNode lastSetupNode = game.kifuFirstMove(true).iterator().prev(false);
            while (game.kifuLastMove() != lastSetupNode && game.prev())
                notify = true;
            gobanCanvas.showMoveHints = false;
            //if (notify && gobanCanvas.showMoveHints)
            //    setCursorToNextGoodMove();
            return notify;
        }
    }
    private class ScoreMode extends PlayMode {
        ScoreMode() {
            igMenuID = MenuScreen.IG_SCORE;
            showVariants = false;
            showMoyo = true;
            markUnknownTerritory = true;
        }
        boolean doPlay() {
            boolean notify;
            int pos = game.board.pos(cursorX, cursorY);
            if (game.board.get(pos) == Board.NONE) {
                notify = super.doPlay();
            } else {
                Group group = new Group(game.board.maxPos());
                game.board.getGroup(pos, group);
                if (game.board.isBit(pos, Board.M_CAPTURED))
                    game.board.clearBit(group, Board.M_CAPTURED);
                else
                    game.board.setBit(group, Board.M_CAPTURED);
                notify = true;
            }
            return notify;
        }
        boolean doScoreDone() {
            BouzyMap bmap = new BouzyMap(game.board);
            bmap.eval();
            Score score = game.getScore(bmap);

            statusScreen.displayScore(score);
//			Alert a = new Alert(LC._("Result"), score.scoreText, null, AlertType.INFO);
//			a.setTimeout(Alert.FOREVER);
//			display.setCurrent(a, gobanCanvas);
            return false;
        }
        boolean doNextMode() {
            return setMode(playMode);
        }
    }
    private class ViewMode extends BasicMode {
        ViewMode() {
            igMenuID = MenuScreen.IG_VIEW;
            showVariants = true;
            showMoyo = false;
            showNextMove = true;
        }
        boolean doNextMode() {
            return setMode(scoreMode);
        }
        boolean keyPressed(int keyCode) throws SGFException, GameException {
            //stopRepeating();

            boolean notify = false;
            switch (keyCode) {
//                case Canvas.KEY_NUM0:
//                    break;
                case Canvas.KEY_NUM2:
                    notify |= game.prevVariant();
                    break;
                case Canvas.KEY_NUM4:
                    notify |= game.prev();
                    break;
                case Canvas.KEY_NUM5:
                    notify |= setMode(playMode);
                    break;
                case Canvas.KEY_NUM6:
                    notify |= game.next();
                    break;
                case Canvas.KEY_NUM7:
                    {
                        SGFNodeIterator i = game.kifuLastMove().iterator();
                        // skip to node with some variants
                        while (i.prev(true) != null
                                && i.nextVariant(false) == null
                                && i.prevVariant(false) == null)
                            // DO NOTHING
                            ;
                        if (!(i.nextVariant(false) == null && i.prevVariant(false) == null)
                                && i.current() != game.kifuLastMove()) {
                            // play game to found node
                            while (i.current() != game.kifuLastMove())
                                game.prev();
                            notify = true;
                        }
                    }
                    break;
                case Canvas.KEY_NUM8:
                    notify |= game.nextVariant();
                    break;
                case Canvas.KEY_NUM9:
                    {
                        SGFNodeIterator i = game.kifuLastMove().iterator();
                        // skip to node with some variants
                        while (i.next(true) != null
                                && i.nextVariant(false) == null
                                && i.prevVariant(false) == null)
                            // DO NOTHING
                            ;
                        if (!(i.nextVariant(false) == null && i.prevVariant(false) == null)
                                && i.current() != game.kifuLastMove()) {
                            // play game to found node
                            while (i.current() != game.kifuLastMove())
                                game.next();
                            notify = true;
                        }
                    }
                    break;
                case Canvas.KEY_NUM1:
                    for (int i = 0; i < 10 && game.prev(); i++)
                        notify = true;
                    break;
                case Canvas.KEY_NUM3:
                    for (int i = 0; i < 10 && game.next(); i++)
                        notify = true;
                    break;
                case Canvas.KEY_STAR:
                    notify = game.undo();
                    break;
                default:
            }
            notify |= setCursor(game.kifuLastMove());
            return notify;
        }
        boolean keyHeld(int keyCode) throws SGFException, GameException {
            boolean notify = false;
            switch (keyCode) {
                case Canvas.KEY_NUM1:
                    while (game.prev())
                        notify = true;
                    break;
                case Canvas.KEY_NUM3:
                    while (game.next())
                        notify = true;
                    break;
                /*case Canvas.KEY_NUM4:
                    startRepeating(500, new Runnable() {
                        public void run() {
                            if (game.prev())
                                notifyGameUpdated();
                            else
                                stopRepeating();
                        }
                    });
                    break;
                case Canvas.KEY_NUM6:
                    startRepeating(500, new Runnable() {
                        public void run() {
                            try {
                                if (game.next())
                                    notifyGameUpdated();
                                else
                                    stopRepeating();
                            } catch (GameException e) {
                                stopRepeating();
                                //#ifdef debug
                                e.printStackTrace();
                                //#endif
                            }
                        }
                    });
                    break;
                    */
            }
            return notify;
        }
    }

    private static final int KEY_SOFT1 = -6;
    private static final int KEY_SOFT2 = -7;
    private static final int KEY_BB_SOFT1 =  97;
    private static final int KEY_BB_SOFT2 = 111;
    private static final String KEY_SOFT1_STR = "SOFT1";
    private static final String KEY_SOFT2_STR = "SOFT2";
    private static final String KEY_SOFT3_STR = "SOFT3";

    private Thread repeatThread = null;
    //private boolean stopRepeatingFlag = true;

    private PlayMode playMode;
    private ViewMode viewMode;
    private ProblemMode probMode;
    private ScoreMode scoreMode;
    private BasicMode mode = null;

    private DB pdb;
    private ProblemEnumeration probEnum = null;
    private Problem probCurrent = null;

    private TinyGoMIDlet midlet;
    private Display display;
    private GobanCanvas gobanCanvas;
    private MenuScreen menuScreen;
    private StatusScreen statusScreen;
    private DocumentedGame game;
    private TimeSystem timeSystem;
    private SoundPlayer snd;

    private int cursorX, cursorY;
    private int zoomX, zoomY, zoomW, zoomH;
    private byte zoomMode;
    private boolean pointerWasDragged;
    private int pointerPressX, pointerPressY;

    SGFTree tree;

    public Controller(TinyGoMIDlet midlet, Display display,
            SoundPlayer snd, DB pdb, TimeSystem timeSystem,
            GobanCanvas gobanCanvas,
            MenuScreen mainScreen, StatusScreen statusScreen) {
        this.midlet = midlet;
        this.display = display;
        this.snd = snd;
        this.pdb = pdb;
        this.gobanCanvas = gobanCanvas;
        this.menuScreen = mainScreen;
        this.statusScreen = statusScreen;
        this.timeSystem = timeSystem;

        playMode = new PlayMode();
        viewMode = new ViewMode();
        probMode = new ProblemMode();
        scoreMode = new ScoreMode();
    }

    public void activate() {
        if (game == null)
            display.setCurrent(menuScreen);
        else
            display.setCurrent(gobanCanvas);
    }

    private void autoZoom() {
        int bsz = game.board.size();
        SGFNodeBoundsVisitor bounds = new SGFNodeBoundsVisitor(0, 0, bsz - 1, bsz - 1);
        game.kifuHead().eval(bounds);

        //#ifdef debug
        System.out.println("Eval bounds: " + bounds.xmin + "," + bounds.ymin
                + " - " + bounds.xmax + "," + bounds.ymax);
        //#endif
        if (bounds.xmax < 0) {
            // empty board
            zoomX = zoomY = 0;
            zoomW = zoomH = bsz;
        } else {
            // if near border, show it, else widen only by 1 point to
            // allow view near empty points
            /*if (bounds.xmin <= 3)
                bounds.xmin = 0;
            else*/
                bounds.xmin = Math.max(bounds.xmin - 1, 0);
            /*if (bounds.ymin <= 3)
                bounds.ymin = 0;
            else*/
                bounds.ymin = Math.max(bounds.ymin - 1, 0);
            /*if (bounds.xmax >= bsz - 4)
                bounds.xmax = bsz - 1;
            else*/
                bounds.xmax = Math.min(bounds.xmax + 1, bsz - 1);
            /*if (bounds.ymax >= bsz - 4)
                bounds.ymax = bsz - 1;
            else*/
                bounds.ymax = Math.min(bounds.ymax + 1, bsz - 1);
            zoomW = bounds.xmax - bounds.xmin + 1;
            zoomH = bounds.ymax - bounds.ymin + 1;
            /*// set zoom limit, so the buffer don't overgrow
            if (zoomW >= zoomH)
                zoomW = Math.max(zoomW, bsz / 2 + 1);
            else
                zoomH = Math.max(zoomH, bsz / 2 + 1);
            // adjust zoom min coordinates
            zoomX = Math.min(bounds.xmin, bsz - zoomW);
            zoomY = Math.min(bounds.ymin, bsz - zoomH);*/
            zoomX = bounds.xmin;
            zoomY = bounds.ymin;
        }
    }

    private void checkMoveHintsProperties() {
        if (game == null)
            return;
        SGFNode head = game.kifuHead();
        if ((head.bits & (SGFNode.BAD_MOVE | SGFNode.GOOD_MOVE)) == 0)
            SGFParser.parseMoveHintsProperties(head);
    }

    public void setGame(DocumentedGame game, boolean recalcZoomCursor) {
        timeSystem.stop();
        this.game = game;

        if (mode == probMode)
            checkMoveHintsProperties();

        statusScreen.setGame(game);
        statusScreen.setProblem(probCurrent, probEnum);
        mode.reset();

        if (recalcZoomCursor) {
            if (mode == probMode) {
                autoZoom();
            } else {
                zoomX = zoomY = 0;
                zoomW = zoomH = game.board.size();
            }
            gobanCanvas.setZoom(zoomX, zoomY, zoomW, zoomH);
        }

        if (recalcZoomCursor) {
            cursorX = zoomX + zoomW / 2;
            cursorY = zoomY + zoomH / 2;
            gobanCanvas.setCursor(cursorX, cursorY);
        }

        notifyGameUpdated();
    }

    private boolean setCursor(int x, int y) {
        boolean moveZoom = false;
        int bsz = game.board.size();
        x = (x + bsz) % bsz;
        y = (y + bsz) % bsz;
        if (x < zoomX || x >= zoomX + zoomW) {
            zoomX = x - zoomW / 2;
            zoomX = zoomX < 0 ? 0 : Math.min(zoomX, bsz - zoomW);
            moveZoom = true;
        }
        if (y < zoomY || y >= zoomY + zoomH) {
            zoomY = y - zoomH / 2;
            zoomY = zoomY < 0 ? 0 : Math.min(zoomY, bsz - zoomH);
            moveZoom = true;
        }
        cursorX = x;
        cursorY = y;
        gobanCanvas.setCursor(cursorX, cursorY);
        if (moveZoom) {
            gobanCanvas.setZoom(zoomX, zoomY, zoomW, zoomH);
            return true;
        } else
            return false;
    }

    private boolean setCursorToNextGoodMove() {
        SGFNodeIterator i = game.kifuLastMove().iterator();
        if (i.next(true) != null) {
            i.firstVariant(true);
            do {
                SGFNode node = i.current();
                if ((node.bits & SGFNode.GOOD_MOVE) != 0) {
                    return setCursor(node);
                }
            } while (i.nextVariant(true) != null);
            // no good moves found, set cursor to any move
            return setCursor(i.current());
        }
        return false;
    }

    private boolean setCursor(SGFNode node) {
        try {
            SGFMove m = node.getMoveProperty();
            return setCursor(m.x, m.y);
        } catch (SGFPropertyNotFoundException e) {
            // DO NOTHING
        }
        return false;
    }

    private static boolean isCursorKey(int keyCode) {
        switch (keyCode) {
            case Canvas.KEY_NUM1:
            case Canvas.KEY_NUM2:
            case Canvas.KEY_NUM3:
            case Canvas.KEY_NUM4:
            case Canvas.KEY_NUM6:
            case Canvas.KEY_NUM7:
            case Canvas.KEY_NUM8:
            case Canvas.KEY_NUM9:
                return true;
            default:
                return false;
        }
    }

    private boolean moveCursor(int keyCode) {
        switch (keyCode) {
            case Canvas.KEY_NUM1:
                cursorX--;
                cursorY--;
                break;
            case Canvas.KEY_NUM2:
                cursorY--;
                break;
            case Canvas.KEY_NUM3:
                cursorX++;
                cursorY--;
                break;
            case Canvas.KEY_NUM4:
                cursorX--;
                break;
            case Canvas.KEY_NUM6:
                cursorX++;
                break;
            case Canvas.KEY_NUM7:
                cursorX--;
                cursorY++;
                break;
            case Canvas.KEY_NUM8:
                cursorY++;
                break;
            case Canvas.KEY_NUM9:
                cursorX++;
                cursorY++;
                break;
            default:
                return false;
        }
        return setCursor(cursorX, cursorY);
    }

    public boolean setMode(BasicMode m) {
        if (mode == m)
            return false;

        if (m.showCursor)
            gobanCanvas.setCursor(cursorX, cursorY);
        gobanCanvas.showCursor(m.showCursor);
        gobanCanvas.showVariants = m.showVariants;
        gobanCanvas.showMoyo = m.showMoyo;
        gobanCanvas.markUnknownTerritory = m.markUnknownTerritory;
        gobanCanvas.showNextMove = m.showNextMove;
        gobanCanvas.showBottomComment(m.showMoveStatus, m.commentLines,
                m.showColorToPlayIndicator, m.showSolvedFailedIndicator,
                m.showFailedImmediately, m.showTimer);

        if (mode == probMode)
            gobanCanvas.showMoveHints = false;
        if (m == probMode)
            checkMoveHintsProperties();

        menuScreen.setIG(m.igMenuID);

        //prevMode = mode;
        mode = m;
        return true;
    }

    public final void resetModeHistory() {
        //prevMode = null;
    }

    private void readFile(final String path, final int offset, final boolean resource, final boolean problem) {
        final WaitCanvas wc = WaitCanvas.getInstance();
        wc.setText(T._("Loading") + " " + path);
        wc.setProgress(0);
        display.setCurrent(wc);

        new Thread(new Runnable() {
            public void run() {
                try {
                    //#ifdef debug
                    System.out.println("Reading " + path + " at " + offset);
                    //#endif
                    final InputStream is;
                    if (resource) {
                        is = TinyGoMIDlet.class.getResourceAsStream(path);
                        if (is == null)
                            throw new IOException(T._("Unable to open resource ") + path);
                    } else {
                        FileConnection fc = (FileConnection) Connector.open("file://localhost/" + path);
                        if (!fc.exists())
                            throw new IOException(T._("File ") + path + T._(" doesn't exists!"));
                        is = fc.openDataInputStream();
                    }

                    // Read and parse file in main thread. It's running too slow in parallel!
                    //display.callSerially(new Runnable() {
                        //public void run() {
                            //try {
                                DocumentedGame game = loadGame(is, offset);
                                //#ifdef debug
                                System.out.println("DONE");
                                //#endif

                                if (game != null) {
                                    if (mode == probMode) {
                                        // skip first "Pass" moves, since we don't have "Pass" in problem mode
                                        SGFNode lastSetupNode = game.kifuFirstMove(true).iterator().prev(false);
                                        if (lastSetupNode != null) {
                                            try {
                                                while (game.kifuLastMove() != lastSetupNode && game.next())
                                                    // DO NOTHING
                                                    ;
                                            } catch (GameException e) {
                                                // DO NOTHING
                                            }
                                        }
                                        gobanCanvas.showMoveHints = false;
                                    }
                                    if (problem)
                                        setMode(probMode);
                                    else
                                        setMode(viewMode);
                                    setGame(game, true);
                                }

                                display.setCurrent(gobanCanvas);
                            //} catch (Exception e) {
                            //    onError(T._("Load"), e);
                            //}
                      //  }
                  //  });
                } catch (Exception e) {
                    onError(T._("Load"), e);
                }
            }
        }).start();
    }

    private void writeFile(final String path) {
        final WaitCanvas wc = WaitCanvas.getInstance();
        wc.setText(T._("Saving") + " " + path);
        wc.setProgress(0);
        display.setCurrent(wc);

        new Thread(new Runnable() {
            public void run() {
                try {
                    //#ifdef debug
                    System.out.println("Writing " + path);
                    System.out.println(SGFWriter.toString(game.kifuHead()));
                    //#endif
                    FileConnection fc = (FileConnection) Connector.open("file://localhost/" + path);
                    OutputStream os = fc.openDataOutputStream();
                    OutputStreamWriter writer = new OutputStreamWriter(os);
                    SGFWriter.write(writer, game.kifuHead());
                    writer.close();
                    os.close();
                    //#ifdef debug
                    System.out.println("DONE");
                    //#endif

                    Alert a = new Alert(T._("Save"), T._("Done"), null, AlertType.INFO);
                    display.setCurrent(a, gobanCanvas);
                } catch (Exception e) {
                    onError(T._("Save"), e);
                }
            }
        }).start();
    }

    /*private void onError(String title, String text, Displayable canvas) {
        Alert a = new Alert(title, text, null, AlertType.ERROR);
        a.setTimeout(Alert.FOREVER);
        display.setCurrent(a, canvas);
        //game.board.print();
    }*/

    private void onError(Exception e) {
        //#ifdef debug
        e.printStackTrace();
        //#endif
        onError(T._("Exception"), e.toString());
    }

    private void onError(String title, Exception e) {
        //#ifdef debug
        e.printStackTrace();
        //#endif
        onError(title, e.toString());
    }

    private void onError(String title, String text) {
        Alert a = new Alert(title, text, null, AlertType.ERROR);
        a.setTimeout(Alert.FOREVER);
        display.setCurrent(a, gobanCanvas);
        //game.board.print();
    }

    private void startRepeating(final int delay, final Runnable r) {
        //#ifndef debug
        System.out.println("REPEATING");
        //#endif
        if (repeatThread != null) {
            repeatThread.interrupt();
            /*stopRepeatingFlag = true;
            try {
                repeatThread.join();
            } catch (InterruptedException e) {
                // DO NOTHING
            }*/
        }
        //stopRepeatingFlag = false;
        repeatThread = new Thread(new Runnable() {
            public void run() {
                try {
                    while (true/*!stopRepeatingFlag*/) {
                        long spent = System.currentTimeMillis();
                        r.run();
                        spent = delay - (System.currentTimeMillis() - spent);
                        Thread.sleep(spent < 0 ? 0 : spent);
                    }
                } catch (InterruptedException e) {
                    // DO NOTHING
                }
            }
        });
        repeatThread.start();
    }

    /*private void startRepeating(final int delay, final int keyCode) {
        repeatThread = new Thread(new Runnable() {
            public void run() {
                try {
                    while (true) {
                        long spent = System.currentTimeMillis();
                        keyPressed(keyCode);
                        spent = delay - (System.currentTimeMillis() - spent);
                        Thread.sleep(spent < 0 ? 0 : spent);
                    }
                } catch (InterruptedException e) {
                    // DO NOTHING
                }
            }
        });
        repeatThread.start();
    }*/

    private boolean stopRepeating() {
        if (repeatThread != null) {
            repeatThread.interrupt();
            //stopRepeatingFlag = true;
            /*try {
                repeatThread.join();
            } catch (InterruptedException e) {
            }*/
            repeatThread = null;
            //#ifndef debug
            System.out.println("REPEATING DONE");
            //#endif
            return true;
        } else
            return false;
    }

    protected boolean isStatusKey(int keyCode) {
        if (keyCode == KEY_SOFT2 || keyCode == KEY_BB_SOFT2)
            return true;
        try {
            String keyName = gobanCanvas.getKeyName(keyCode);
            return keyName.equals(KEY_SOFT2_STR)
                || keyName.equals(KEY_SOFT3_STR);
        }
        catch (IllegalArgumentException e) {
            return false;
        }
    }

    protected boolean isMenuKey(int keyCode) {
        if (keyCode == KEY_SOFT1 || keyCode == KEY_BB_SOFT1)
            return true;
        try {
            String keyName = gobanCanvas.getKeyName(keyCode);
            return keyName.equals(KEY_SOFT1_STR);
        }
        catch (IllegalArgumentException e) {
            return false;
        }
    }

    protected void keyPressed(int keyCode) {
        try {
            /*String kk = "keyPressed: " + gobanCanvas.getKeyName(keyCode) + " " + keyCode + "," + gobanCanvas.getGameAction(keyCode);
            Alert aaa = new Alert("aaa", kk, null, AlertType.ERROR);
            display.setCurrent(aaa);*/
            //String keyName = gobanCanvas.getKeyName(keyCode);
            //#ifdef debug
            //System.out.println("keyPressed: " + keyCode + " " + keyName);
            //#endif

            // Special key case handling
            if (isStatusKey(keyCode)) {
                statusScreen.displayStatus();
                return;
            } else if (isMenuKey(keyCode)) {
                menuScreen.activate();
                return;
            } else if (keyCode == Canvas.KEY_NUM0) {
                int bsz = game.board.size();
                switch (zoomMode++) {
                    case ZOOM_AUTO:
                        // zoom out
                        zoomX = zoomY = 0;
                        zoomW = zoomH = bsz;
                        break;
                    case ZOOM_OUT:
                        // zoom in
                        zoomW = zoomH = Math.max(bsz / 2 + 2, Math.min(bsz, 9));
                        if (mode.showCursor || game.lastMove < 0) {
                            zoomX = cursorX;
                            zoomY = cursorY;
                        } else {
                            SGFPoint p = game.board.xy(game.lastMove);
                            zoomX = p.x;
                            zoomY = p.y;
                        }
                        zoomX -= zoomW / 2;
                        zoomY -= zoomH / 2;
                        zoomX = zoomX < 0 ? 0 : Math.min(zoomX, bsz - zoomW);
                        zoomY = zoomY < 0 ? 0 : Math.min(zoomY, bsz - zoomH);
                        break;
                    case ZOOM_IN:
                        // autozoom
                        autoZoom();
                }
                zoomMode %= ZOOM_MAX;
                gobanCanvas.setZoom(zoomX, zoomY, zoomW, zoomH);
                notifyGameUpdated();
                return;
            } else if (keyCode == Canvas.KEY_POUND) {
                if (mode.doNextMode())
                    notifyGameUpdated();
                return;
            }

            if (mode.keyPressed(keyCode))
                notifyGameUpdated();
        } catch (Exception e) {
            onError(e);
        }
    }

    /*protected void keyRepeated(int keyCode) {
    }*/

    protected void keyReleased(int keyCode) {
        try {
            //#ifdef debug
            System.out.println("keyReleased: " + keyCode);
            //#endif

            if (mode.keyReleased(keyCode))
                notifyGameUpdated();
        } catch (Exception e) {
            onError(e);
        }
    }

    protected void keyHeld(int keyCode) {
        try {
            //#ifdef debug
            System.out.println("keyHeld: " + keyCode);
            //#endif

            if (mode.keyHeld(keyCode))
                notifyGameUpdated();
        } catch (Exception e) {
            onError(e);
        }
    }

    protected void pointerPressed(int x, int y) {
        try {
            //#ifdef debug
            System.out.println("pointerPressed: " + x + ',' + y);
            //#endif

            pointerWasDragged = x < 0 || y < 0 || x >= zoomW || y >= zoomH;
            pointerPressX = x;
            pointerPressY = y;
        } catch (Exception e) {
            onError(e);
        }
    }

    protected void pointerDragged(int x, int y) {
        try {
            //#ifdef debug
            System.out.println("pointerDragged: " + x + ',' + y);
            //#endif

            if (x != pointerPressX || y != pointerPressY) {
                pointerWasDragged = true;

                int bsz = game.board.size();
                zoomX += pointerPressX - x;
                zoomY += pointerPressY - y;
                zoomX = zoomX < 0 ? 0 : Math.min(zoomX, bsz - zoomW);
                zoomY = zoomY < 0 ? 0 : Math.min(zoomY, bsz - zoomH);
                pointerPressX = x;
                pointerPressY = y;

                gobanCanvas.setZoom(zoomX, zoomY, zoomW, zoomH);
                notifyGameUpdated();
            }
        } catch (Exception e) {
            onError(e);
        }
    }

    protected void pointerReleased(int x, int y) {
        try {
            //#ifdef debug
            System.out.println("pointerReleased: " + x + ',' + y);
            //#endif

            if (!pointerWasDragged) {
                if (setCursor(zoomX + x, zoomY + y) || mode.keyPressed(Canvas.KEY_NUM5))
                    notifyGameUpdated();
            }
        } catch (Exception e) {
            onError(e);
        }
    }

    public void notifyGameUpdated() {
        try {
            //#ifdef debug
            System.out.println("NOTIFY game updated");
            //#endif
            gobanCanvas.notifyGameUpdated(game);
            //#ifdef debug
            System.out.println("NOTIFY game updated DONE");
            //#endif
        } catch (Exception e) {
            onError(e);
        }
    }

    public DocumentedGame loadGame(InputStream is, int offset) throws Exception {
        /* FIXME: Emulator is giving strange exception, if UTF8 used:
       [wtkrun] java.lang.ArrayIndexOutOfBoundsException:
       [wtkrun]     at com.sun.kvem.cldc.i18n.j2me.GenericReader.read(+139)
       [wtkrun]     at java.io.Reader.skip(+83)
       [wtkrun]     at java.io.InputStreamReader.skip(+12)
         */
        is.skip(offset);
        InputStreamReader isr = new InputStreamReader(is/*, "UTF8"*/);
        //isr.skip(offset); // FIXME: Why this doesn't work?
        SGFParser parser = new SGFParser(isr);
        SGFNode newTree = parser.parse();
        is.close();

/*		SGFCup parser = new SGFCup(new SGFLex(isr));
        parser.tree = new SGFTree(2048);
        try {
            parser.parse();
        } catch (OutOfMemoryError e) {
            e.printStackTrace();
        }
        System.out.println("Nodes: " + parser.nNodes + " Properties: " + parser.nProperties);
        tree = parser.tree;*/
        if (newTree == null)
            return null;

        //System.out.println(SGFWriter.toString(tree));
        return new DocumentedGame(newTree);
    }

    private void resetProblemEnum() {
        probEnum = null;
        probCurrent = null;
    }

    private void setProblem(int probId) {
        probCurrent = pdb.getProblem(probId);
        String filePath = probCurrent.filePath();
        //#ifdef debug
        System.out.println("Next problem: " + filePath + " O:" + probCurrent.offset
                + " R:" + probCurrent.resource
                + " G:" + probCurrent.genre
                + " DI:" + probCurrent.difficulty + " DP:" + probCurrent.difficultyP
                + " P:" + probCurrent.popularity
                + " T:" + probCurrent.tried + " S:" + probCurrent.solved);
        //#endif

        readFile(filePath, probCurrent.offset, probCurrent.resource, true);
    }

    public void mainMenuDone() {
        display.setCurrent(gobanCanvas);
    }

    public void mainMenuExit() {
        midlet.exit();
    }

    public void mainMenuNewGame(String white, String black,
            String ruleSet, int size, int handicap, float komi,
            int ts, long mainTime, long byoYomiTime, int byoYomiAttr) {
        display.setCurrent(gobanCanvas);
        resetProblemEnum();
        game = new DocumentedGame(size, komi, ruleSet, white, black);
        game.setHandicap(handicap);
        setMode(playMode);
        setGame(game, true);
        timeSystem.init(ts, mainTime, byoYomiTime, byoYomiAttr);
        timeSystem.start(game.colorToPlay == Board.BLACK);
    }

    public void mainMenuLoad(String path) {
        display.setCurrent(gobanCanvas);
        resetProblemEnum();
        readFile(path, 0, false, false);
    }

    public void mainMenuLoadProblem(String path) {
        display.setCurrent(gobanCanvas);
        resetProblemEnum();
        readFile(path, 0, false, true);
    }

    public void mainMenuSave(String path) {
        display.setCurrent(gobanCanvas);
        writeFile(path);
    }

    public void mainMenuSolveProblems(ProblemEnumeration en) {
        try {
            setMode(probMode);
            probEnum = en;
            //Alert a = new Alert(LC._("Solve problems"), "" + en.size() + LC._(" problems filtered"), null, AlertType.INFO);
            setProblem(probEnum.nextElement());
        } catch (Exception e) {
            onError(e);
        }
    }

    public void mainMenuInvalidateProblems() {
        probEnum = null;
    }

    public void igMenuFreePlay() {
        probMode.freePlay = !probMode.freePlay;
        display.setCurrent(gobanCanvas);
    }

    public void igMenuPass() {
        display.setCurrent(gobanCanvas);
        if (mode.doPass())
            notifyGameUpdated();
    }

    public void igMenuScore() {
        scoreMode.doScoreDone();
    }

    public void igMenuRestartProblem() {
        display.setCurrent(gobanCanvas);
        if (probMode.doRestart())
            notifyGameUpdated();
    }

    public void igMenuNextProblem() {
        if (probEnum != null) {
            if (probEnum.hasMoreElements())
                setProblem(probEnum.nextElement());
            else {
                Alert alert = new Alert(T._("Problem solving"),
                        T._("End of enumeration, start with new filter."),
                        null, AlertType.INFO);
                display.setCurrent(alert, menuScreen.getProblemFilterForm());
            }
        }
    }

    public void igMenuPrevProblem() {
        if (probEnum != null) {
            if (probEnum.current() > 0)
                setProblem(probEnum.prevElement());
            else {
                Alert alert = new Alert(T._("Problem solving"),
                        T._("Start of enumeration reached."),
                        null, AlertType.INFO);
                display.setCurrent(alert);
            }
        }
    }

    public void statusScreenCancelled() {
        display.setCurrent(gobanCanvas);
    }

    public void editNodeCancelled() {
        display.setCurrent(gobanCanvas);
    }

    public void optPlayModeSettings(boolean showMoveStatus, boolean showColorToPlayIndicator,
            boolean showTimer,
            int commentLines) {
        BasicMode[] modes = { playMode, viewMode, scoreMode };
        for (int i = 0; i < modes.length; i++) {
            BasicMode m = modes[i];
            m.showMoveStatus = showMoveStatus;
            m.showColorToPlayIndicator = showColorToPlayIndicator;
            m.showTimer = showTimer;
            m.commentLines = commentLines;
        }
        if (mode != null) {
            gobanCanvas.showBottomComment(mode.showMoveStatus, mode.commentLines,
                    mode.showColorToPlayIndicator, mode.showSolvedFailedIndicator,
                    mode.showFailedImmediately, mode.showTimer);
            notifyGameUpdated();
        }
    }

    public void optProbModeSettings(boolean showMoveStatus, boolean showColorToPlayIndicator,
            boolean showSolvedFailedIndicator, boolean showFailedImmediately,
            int commentLines) {
        probMode.showMoveStatus = showMoveStatus;
        probMode.showColorToPlayIndicator = showColorToPlayIndicator;
        probMode.showSolvedFailedIndicator = showSolvedFailedIndicator;
        probMode.showFailedImmediately = showFailedImmediately;
        probMode.commentLines = commentLines;
        if (mode != null) {
            gobanCanvas.showBottomComment(mode.showMoveStatus, mode.commentLines,
                    mode.showColorToPlayIndicator, mode.showSolvedFailedIndicator,
                    mode.showFailedImmediately, mode.showTimer);
            notifyGameUpdated();
        }
    }

    public void optGeneralSettings(boolean sound, int commentFontSize) {
        snd.on = sound;
        gobanCanvas.setCommentFontSize(commentFontSize);
        if (mode != null)
            notifyGameUpdated();
    }


    public void timeSystemShortOnTime(boolean isBlack, int millisLeft) {
        snd.playShortOnTime();
    }

    public void timeSystemTimeout(boolean isBlack) {
        Alert a = new Alert(T._("Game timer"), (isBlack ? T._("Black") : T._("White")) + T._(" timeout!"), null, AlertType.INFO);
        a.setTimeout(Alert.FOREVER);
        display.setCurrent(a, gobanCanvas);
    }

    public void save(DataOutputStream dout) throws IOException {
        if (game == null)
            dout.writeUTF("");
        else {
            String sgfText = SGFWriter.toString(game.kifuHead());
            dout.writeUTF(sgfText);

            if (sgfText.length() > 0) {
                Stack variants = new Stack();
                int depth = 0;
                SGFNodeIterator i = game.kifuLastMove().iterator();
                do {
                    SGFNodeIterator ii = i.current().iterator();
                    int varNumber = 0;
                    while (ii.prevVariant(true) != null)
                        varNumber++;
                    variants.push(new Integer(varNumber));
                    depth++;
                } while (i.prev(true) != null);
                dout.writeShort(depth);
                while (!variants.empty())
                    dout.writeShort(((Integer)variants.pop()).shortValue());
            }
        }

        byte modeCode = 0;
        if (mode == playMode)
            modeCode = PLAY_MODE;
        else if (mode == viewMode)
            modeCode = VIEW_MODE;
        else if (mode == scoreMode)
            modeCode = SCORE_MODE;
        else if (mode == probMode)
            modeCode = PROB_MODE;
        dout.writeByte(modeCode);
        dout.writeByte(cursorX);
        dout.writeByte(cursorY);
        dout.writeByte(zoomX);
        dout.writeByte(zoomY);
        dout.writeByte(zoomW);
        dout.writeByte(zoomH);
        dout.writeBoolean(gobanCanvas.showMoveHints);

        final BasicMode[] modeAr = { playMode, viewMode, scoreMode, probMode };
        for (int i = 0; i < modeAr.length; i++) {
            BasicMode m = modeAr[i];
            dout.writeByte(m.commentLines);
            dout.writeBoolean(m.showMoveStatus);
            dout.writeBoolean(m.showColorToPlayIndicator);
            dout.writeBoolean(m.showSolvedFailedIndicator);
            dout.writeBoolean(m.showFailedImmediately);
            dout.writeBoolean(m.showTimer);
        }

        // save problem state
        //dout.writeBoolean(probMode.freePlay);
        dout.writeBoolean(probMode.probFinished);
        dout.writeBoolean(probMode.hasRespondMove);
        // save problem enumeration
        boolean srProb = probEnum != null;
        dout.writeBoolean(srProb);
        if (srProb)
            probEnum.save(dout);
    }

    public void restore(DataInputStream din) throws IOException {
        DocumentedGame newGame = null;
        try {
            String sgf = din.readUTF();

            if (sgf.length() > 0) {
                SGFParser parser = new SGFParser(sgf);
                SGFNode newTree = parser.parse();
                newGame = new DocumentedGame(newTree);

                int depth = din.readShort();
                while (depth-- > 0) {
                    int varNumber = din.readShort();
                    while (newGame.prevVariant())
                        // DO NOTHING
                        ;
                    while (varNumber-- > 0)
                        newGame.nextVariant();
                    if (depth > 0)
                        newGame.next();
                }
            }
        } catch (SGFException e) {
            //#ifdef debug
            e.printStackTrace();
            //#endif
        } catch (GameException e) {
            //#ifdef debug
            e.printStackTrace();
            //#endif
        }

        byte modeCode = din.readByte();
        cursorX = din.readByte();
        cursorY = din.readByte();
        zoomX = din.readByte();
        zoomY = din.readByte();
        zoomW = din.readByte();
        zoomH = din.readByte();
        gobanCanvas.showMoveHints = din.readBoolean();

        final BasicMode[] modeAr = { playMode, viewMode, scoreMode, probMode };
        for (int i = 0; i < modeAr.length; i++) {
            BasicMode m = modeAr[i];
            m.commentLines = din.readByte();
            m.showMoveStatus = din.readBoolean();
            m.showColorToPlayIndicator = din.readBoolean();
            m.showSolvedFailedIndicator = din.readBoolean();
            m.showFailedImmediately = din.readBoolean();
            m.showTimer = din.readBoolean();
        }

        // restore problem state
        //probMode.freePlay = din.readBoolean();
        probMode.probFinished = din.readBoolean();
        probMode.hasRespondMove = din.readBoolean();
        // restore problem enumeration
        if (din.readBoolean()) {
            probEnum = new ProblemEnumeration();
            probEnum.restore(din);
            probCurrent = pdb.getProblem(probEnum.currentElement());
        }

        // setup mode and game
        if (newGame != null) {
            if (modeCode == PLAY_MODE)
                setMode(playMode);
            else if (modeCode == VIEW_MODE)
                setMode(viewMode);
            else if (modeCode == SCORE_MODE)
                setMode(scoreMode);
            else if (modeCode == PROB_MODE)
                setMode(probMode);
            if (mode != null) {
                gobanCanvas.setZoom(zoomX, zoomY, zoomW, zoomH);
                gobanCanvas.setCursor(cursorX, cursorY);
                setGame(newGame, false);
            }
            //#ifdef debug
            if (mode == null)
                System.out.println("null mode");
            //#endif
        }
        //#ifdef debug
        if (newGame == null)
            System.out.println("null game");
        //#endif
    }

}
