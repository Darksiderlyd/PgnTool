/**
 * TinyGo is a MIDlet to play and review Go board games.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 */
package com.tinygo;


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Vector;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

import com.sgfj.SGFException;
import com.sgfj.SGFInvalidDataRequestException;
import com.sgfj.SGFMove;
import com.sgfj.SGFNode;
import com.sgfj.SGFNodeIterator;
import com.sgfj.SGFPoint;
import com.sgfj.SGFProperty;
import com.sgfj.SGFPropertyName;
import com.sgfj.SGFPropertyNotFoundException;
import com.tinygo.gam.Tile;
import com.tinygo.gam.TilePainter;
import com.tinygo.gam.WIT;
import com.tinygo.logic.Board;
import com.tinygo.logic.BouzyMap;
import com.tinygo.logic.DocumentedGame;

/**
 * @author Alexey Klimkin
 *
 */
class GobanCanvas extends Canvas  {

    private Display display;

    private TilePainter tilePainter;
    private WIT[][] wits = null, oldWits = null;

    private Controller controller;

    protected boolean showVariants = false;
    protected boolean showMoveHints = false;
    protected boolean cursorVisible = false;
    protected boolean showMoyo = false;
    protected boolean showNextMove = false;
    protected boolean markUnknownTerritory = false;
    protected boolean showCoordinates = false;

    private Thread keyHeldCheckThread = null;
    private static final int keyHeldDelay = 500;

    private int canvasDevW, canvasDevH;
    private int gobanViewDevX, gobanViewDevY, gobanViewDevW, gobanViewDevH;     // drawing clip in device pixels

    private BouzyMap bmap = new BouzyMap();
    private int cursorX, cursorY;
    private int zoomX, zoomY, zoomW, zoomH;

    private boolean setupGobanTile = true;
    private boolean setupCells = true;
    private boolean setupCommentTile = true;
    private SGFNode lastNode = null;
    private boolean blackColorToPlay;

    private int boardSize = -1;
    private int gridStep;

    private int commentViewDevY, commentViewDevH;
    private int commentLines = 0;
    private int commentFontDevSize;
    private boolean showMoveStatus = false;
    private boolean showColorToPlayIndicator = false;
    private boolean showSolvedFailedIndicator = false;
    private boolean showFailedImmediately = false;
    private boolean showTimer = false;

    private Image gobanTile = null;
    private Tile commentTile = null;
    private Tile cursorTile = null;

    /**
     *
     */
    public GobanCanvas(Display display, TilePainter tilePainter) {
        this.display = display;
        this.tilePainter = tilePainter;

        setFullScreenMode(true);

        canvasDevW = getWidth();
        canvasDevH = getHeight();

        //#ifdef debug
        System.out.println("Device pixels: " + canvasDevW + "x" + canvasDevH);
        //#endif

        setCommentFontSize(14);
    }

    public final void setController(Controller controller) {
        this.controller = controller;
    }

    protected void sizeChanged(int w, int h) {
        //#ifdef debug
        System.out.println("New device pixels: " + w + "x" + h);
        //#endif
    }

    public void setZoom(int zX, int zY, int zW, int zH) {
        boolean zAnchorChanged = zoomX != zX || zoomY != zY;
        boolean zMagnChanged = zoomW != zW || zoomH != zH;

        if (!zAnchorChanged && !zMagnChanged)
            return;

        //#ifdef debug
        System.out.println("New zoom points: " + zX + "," + zY + " " + zW + "x" + zH);
        //#endif

        if (zMagnChanged) {
            setupGobanTile = true;

            oldWits = wits = null;
            oldWits = new WIT[zW][zH];
            wits = new WIT[zW][zH];
            for (int i = 0; i < zW; i++)
                for (int j = 0; j < zH; j++) {
                    oldWits[i][j] = new WIT();
                    wits[i][j] = new WIT();
                }

            zoomW = zW;
            zoomH = zH;
        }
        if (zAnchorChanged) {
            if (cursorVisible)
                repaintCursor();
            zoomX = zX;
            zoomY = zY;
            if (cursorVisible)
                repaintCursor();
        }
        setupCells = true;
    }

    public void showBottomComment(boolean showMoveStatus, int commentLines,
            boolean showColorToPlayIndicator,
            boolean showSolvedFailedIndicator, boolean showFailedImmediately,
            boolean showTimer) {

        if (showMoveStatus)
            commentLines++;
        if (showTimer)
            commentLines++;

        setupCommentTile = setupGobanTile =
               this.showMoveStatus != showMoveStatus
            || this.commentLines != commentLines
            || this.showColorToPlayIndicator != showColorToPlayIndicator
            || this.showSolvedFailedIndicator != showSolvedFailedIndicator
            || this.showFailedImmediately != showFailedImmediately
            || this.showTimer != showTimer;

        this.showMoveStatus = showMoveStatus;
        this.commentLines = commentLines;
        this.showColorToPlayIndicator = showColorToPlayIndicator;
        this.showSolvedFailedIndicator = showSolvedFailedIndicator;
        this.showFailedImmediately = showFailedImmediately;
        this.showTimer = showTimer;

        if (showTimer) {

        } else {

        }
    }

    public void setCommentFontSize(int fontSize) {
        if (fontSize == commentFontDevSize)
            return;

        //#ifdef debug
        System.out.println("Comment size: " + fontSize);
        //#endif

        commentFontDevSize = fontSize;
        setupCommentTile = setupGobanTile = true;
    }

    private void setupCommentTile() {
        //#ifdef debug
        System.out.println("Setup comment tile for lines " + commentLines);
        //#endif

        commentViewDevH = commentFontDevSize * commentLines;
        commentViewDevY = canvasDevH - commentViewDevH;

        //#ifdef debug
        System.out.println("Comment view pixels: "
                + "0," + commentViewDevY + ' '
                + canvasDevW + "x" + commentViewDevH);
        //#endif

        commentTile = tilePainter.createTile(canvasDevW, commentViewDevH);

        repaint(0, commentViewDevY, canvasDevW, commentViewDevH);
    }

    private void setupGobanTile() {
        //#ifdef debug
        System.out.println("Setup goban tile for zoom " + zoomW + "x" + zoomH);
        //#endif

        gobanViewDevH = canvasDevH - commentViewDevH;
        gobanViewDevW = canvasDevW;

        if (gobanViewDevW * zoomH > zoomW * gobanViewDevH) {
            // fit by Y coordinate
            //#ifdef debug
            System.out.println("Fitting Y");
            //#endif
            gridStep = (gobanViewDevH - 1) / zoomH;
        } else {
            // fit by X coordinate
            //#ifdef debug
            System.out.println("Fitting X");
            //#endif
            gridStep = (gobanViewDevW - 1) / zoomW;
        }

        // don't draw super big stones
        gridStep = Math.min(Math.min(gridStep, canvasDevW / 9), canvasDevH / 9);
        // make grid step to be even integer number
        gridStep &= ~0x1;
        //#ifdef debug
        System.out.println("Grid step: " + gridStep);
        //#endif

        gobanViewDevW = gridStep * zoomW + 1;
        gobanViewDevH = gridStep * zoomH + 1;
        // center goban horizontally and vertically
        gobanViewDevX = (canvasDevW - gobanViewDevW) / 2;
        gobanViewDevY = (canvasDevH - commentViewDevH - gobanViewDevH) / 2;

        //#ifdef debug
        System.out.println("Goban view pixels: "
                + gobanViewDevX + "," + gobanViewDevY + ' '
                + gobanViewDevW + "x" + gobanViewDevH);
        //#endif

        for (int x = 0; x < zoomW; x++)
            for (int y = 0; y < zoomH; y++)
                oldWits[x][y].clear(0);

        gobanTile = Image.createImage(gobanViewDevW, gobanViewDevH);
        Tile board = tilePainter.createTile(gobanViewDevW, gobanViewDevH);
        tilePainter.drawPlainBoard(board);
        gobanTile.getGraphics().drawRGB(board.pixels32, 0, board.width, 0, 0, board.width, board.height, false);

        cursorTile = tilePainter.createTile(gridStep + 1, gridStep + 1);

        repaint(0, 0, canvasDevW, canvasDevH - commentViewDevH);
    }

    private final WIT getWit(int x, int y) {
        return wits[x - zoomX][y - zoomY];
    }
    private final WIT getWit(SGFPoint p) {
        return wits[p.x - zoomX][p.y - zoomY];
    }
    /*private final WIT oldWit(SGFPoint p) {
        return oldWit[p.x - zoom.xmin][p.y - zoom.ymin];
    }*/
    private final WIT getOldWit(int x, int y) {
        return oldWits[x - zoomX][y - zoomY];
    }
    private boolean isInView(int x, int y) {
        return x >= zoomX && x < zoomX + zoomW
            && y >= zoomY && y < zoomY + zoomH;
    }
    private boolean isInView(SGFPoint p) {
        return isInView(p.x, p.y);
    }

    public void notifyGameUpdated(DocumentedGame game) {
        boardSize = game.board.size();
        blackColorToPlay = game.colorToPlay == Board.BLACK;

        if (setupCommentTile)
            setupCommentTile();
        if (setupGobanTile) {
            setupGobanTile();
            setupGobanTile = false;
        }

        // new stone configuration
        for (int x = zoomX; x < zoomX + zoomW; x++)
            for (int y = zoomY; y < zoomY + zoomH; y++) {
                WIT wit = getWit(x, y);
                wit.clear(WIT.CELL);
                if (setupCells)
                    wit.setCell(x, y, boardSize);
                byte color = game.board.get(x, y);
                if (color != Board.NONE)
                    wit.setStone(color == Board.BLACK);
            }

        if (setupCells) {
            final int[] hoshis = Board.getHoshis(boardSize);
            if (hoshis != null)
                for (int k = 0; k < hoshis.length; k++) {
                    SGFPoint sgfp = Board.xy(hoshis[k], boardSize);
                    if (isInView(sgfp))
                        getWit(sgfp).addMark(WIT.HOSHI);
                }
            setupCells = false;
        }

        SGFNode lastMoveNode = game.kifuLastMove();

        // draw marks from properties
        for (Enumeration e = lastMoveNode.getProperties(); e.hasMoreElements(); ) {
            SGFProperty prop = (SGFProperty) e.nextElement();
            try {
                SGFPoint sgfp = prop.getPoint();
                if (isInView(sgfp)) {
                    WIT wit = getWit(sgfp);
                    if (prop.name() == SGFPropertyName.TR)
                        wit.addMark(WIT.TRIANGLE);
                    else if (prop.name() == SGFPropertyName.SQ)
                        wit.addMark(WIT.SQUARE);
                    else if (prop.name() == SGFPropertyName.CR)
                        wit.addMark(WIT.CIRCLE);
                    else if (prop.name() == SGFPropertyName.MA)
                        wit.addMark(WIT.CROSS);
                    else if (prop.name() == SGFPropertyName.SL)
                        wit.addMark(WIT.SELECTED);
                    else if (prop.name() == SGFPropertyName.DD)
                        wit.addMark(WIT.DIMMED);
                    else if (prop.name() == SGFPropertyName.TW)
                        wit.addMark(WIT.WHITE_TER);
                    else if (prop.name() == SGFPropertyName.TB)
                        wit.addMark(WIT.BLACK_TER);
                    else if (prop.name() == SGFPropertyName.LB)
                        wit.setLabel(prop.getText());
                    else if (prop.name() == SGFPropertyName.VW)
                        wit.addMark(WIT.VIEW);
                }
            } catch (SGFInvalidDataRequestException e1) {
            }
        }

        // mark last move (if not marked in props)
        if (game.lastMove >= 0) {
            SGFPoint sgfp = game.board.xy(game.lastMove);
            if (isInView(sgfp) && (getWit(sgfp).bits & WIT.PURE_MARK) == 0)
                getWit(sgfp).addMark(WIT.CIRCLE);
        }

        // mark next move (if not marked in props)
        if (showNextMove) {
            SGFNodeIterator i = lastMoveNode.iterator();
            if (i.next(true) != null) {
                try {
                    SGFMove m = i.current().getMoveProperty();
                    if (isInView(m) && (getWit(m).bits & WIT.PURE_MARK) == 0)
                        getWit(m).addMark(WIT.CIRCLE);
                } catch (SGFPropertyNotFoundException e) {
                    // DO NOTHING
                }
            }
        }

        // mark ko move (if not marked in props)
        if (game.koMove >= 0) {
            SGFPoint sgfp = game.board.xy(game.koMove);
            if (isInView(sgfp) && (getWit(sgfp).bits & WIT.PURE_MARK) == 0)
                getWit(sgfp).addMark(WIT.SQUARE);
        }

        // mark variations
        if (showVariants) {
            SGFNodeIterator i = lastMoveNode.iterator();
            i.firstVariant(true);
            do {
                SGFNode node = i.current();
                if (node != lastMoveNode)
                    try {
                        SGFMove m = node.getMoveProperty();
                        if (isInView(m))
                            getWit(m).addMark(WIT.VARIANT);
                    } catch (SGFPropertyNotFoundException e) {
                        // DO NOTHING
                    }
            } while (i.nextVariant(true) != null);
        }

        // mark hints
        if (showMoveHints) {
            SGFNodeIterator i = lastMoveNode.iterator();
            if (i.next(true) != null) {
                i.firstVariant(true);
                do {
                    SGFNode node = i.current();
                    try {
                        SGFMove m = node.getMoveProperty();
                        if (isInView(m)) {
                            if ((node.bits & SGFNode.GOOD_MOVE) != 0)
                                getWit(m).addMark(WIT.GOOD_MOVE);
                            else if ((node.bits & SGFNode.BAD_MOVE) != 0)
                                getWit(m).addMark(WIT.BAD_MOVE);
                            else
                                getWit(m).addMark(WIT.VARIANT);
                        }
                    } catch (SGFPropertyNotFoundException e) {
                        // DO NOTHING
                    }
                } while (i.nextVariant(true) != null);
            }
        }

        if (showMoyo) {
            bmap.setup(game.board);
            bmap.eval();
            for (int x = zoomX; x < zoomX + zoomW; x++)
                for (int y = zoomY; y < zoomY + zoomH; y++) {
                    int pos = game.board.pos(x, y);
                    if (!(game.board.get(pos) == Board.NONE || game.board.isBit(pos, Board.M_CAPTURED)))
                            continue;
                    int val = bmap.get(x, y);
                    if (val == 0) {
                        if (markUnknownTerritory)
                            getWit(x, y).addMark(WIT.TRIANGLE);
                    } else
                        getWit(x, y).addMark(val > 0 ? WIT.BLACK_TER : WIT.WHITE_TER);
                }
        }

        int minX = boardSize, minY = boardSize, maxX = -1, maxY = -1;
        for (int x = zoomX; x < zoomX + zoomW; x++)
            for (int y = zoomY; y < zoomY + zoomH; y++)
                if (drawWIT(x, y)) {
                    minX = Math.min(minX, x);
                    minY = Math.min(minY, y);
                    maxX = Math.max(maxX, x);
                    maxY = Math.max(maxY, y);
                }
        if (maxX >= 0) {
            repaint(gobanViewDevX + (minX - zoomX) * gridStep, gobanViewDevY + (minY - zoomY) * gridStep,
                    (maxX - minX + 1) * gridStep, (maxY - minY + 1) * gridStep);
        }

        if (commentLines > 0 && (lastMoveNode != lastNode || setupCommentTile)) {
            drawComment(game);
            lastNode = lastMoveNode;
            setupCommentTile = false;
        }

        serviceRepaints();
    }

    private boolean drawWIT(int x, int y) {
        final WIT wit = getWit(x, y);
        final WIT oldWit = getOldWit(x, y);

        if (wit.equals(oldWit))
            return false;

        int origBits, bits;
        origBits = bits = wit.bits;
        boolean incremental =
               (oldWit.bits & WIT.CELL) == (wit.bits & WIT.CELL)	// same cell type
            && ((oldWit.bits & WIT.PURE_MARK) == 0 || (wit.bits & WIT.SOLID) == 0)
            && (oldWit.bits & ~wit.bits) == 0   					// no marks removed
            && (oldWit.bits & WIT.OVER_CELL) == 0					// no over-cell markup on screen (like dimmed)
            && oldWit.sameLabel(wit);           					// same label
        if (incremental)
            bits &= ~oldWit.bits;
        oldWit.set(wit);

        //#ifdef debug
        /*System.out.print("Draw " + x + "," + y + ": " + (incremental ? '+' : ' '));
        if ((bits & WIT.CELL) != 0)
            System.out.print(" CELL");
        if ((bits & WIT.STONE) != 0)
            System.out.print(" STONE");
        if ((bits & WIT.HINT) != 0)
            System.out.print(" HINT");
        if ((bits & WIT.VARIANT) != 0)
            System.out.print(" VAR");
        if ((bits & WIT.PURE_MARK) != 0)
            System.out.print(" MARKS");
        if ((bits & WIT.TER) != 0)
            System.out.print(" TER");
        if ((bits & WIT.SELECTED) != 0)
            System.out.print(" SEL");
        if ((bits & WIT.DIMMED) != 0)
            System.out.print(" DIM");
        System.out.println();*/
        //#endif

        Vector tiles = new Vector(16);
        int tileW = gridStep;

        if ((bits & WIT.CELL) != 0) {
            // draw empty goban
            tiles.addElement(tilePainter.getTile(tileW, tileW, bits & WIT.CELL, false, null));
        }
        if ((bits & WIT.STONE) != 0) {
            tiles.addElement(tilePainter.getTile(tileW, tileW, bits & WIT.STONE, (bits & WIT.BLACK_STONE) != 0, null));
        } else {
            if ((bits & WIT.HINT) != 0) {
                tiles.addElement(tilePainter.getTile(tileW, tileW, bits & WIT.HINT, false, null));
                // redraw some markup if good/bad mark draws over
                bits |= origBits & WIT.PURE_MARK;
            } else {
                if ((bits & WIT.LABEL) != 0)
                    tiles.addElement(tilePainter.getTile(tileW, tileW, WIT.LABEL_BG, false, null));
                if ((bits & WIT.VARIANT) != 0)
                    tiles.addElement(tilePainter.getTile(tileW, tileW, WIT.VARIANT, false, null));
            }
        }
        if ((bits & WIT.SELECTED) != 0)
            tiles.addElement(tilePainter.getTile(tileW, tileW, bits & WIT.SELECTED, false, null));
        if ((bits & WIT.TER) != 0)
            tiles.addElement(tilePainter.getTile(tileW, tileW, bits & WIT.TER, (bits & WIT.BLACK_TER) != 0, null));
        if ((bits & WIT.PURE_MARK) != 0) {
            boolean isBlackMark = (origBits & WIT.BLACK_STONE) == 0;
            if ((bits & WIT.LABEL) != 0) {
                String label = wit.label;//.substring(0, Math.min(wit.label.length(), 3));
                tiles.addElement(tilePainter.getTile(tileW, tileW, bits & WIT.LABEL, isBlackMark, label));
            }
            if ((bits & WIT.CIRCLE) != 0)
                tiles.addElement(tilePainter.getTile(tileW, tileW, bits & WIT.CIRCLE, isBlackMark, null));
            if ((bits & WIT.SQUARE) != 0)
                tiles.addElement(tilePainter.getTile(tileW, tileW, bits & WIT.SQUARE, isBlackMark, null));
            if ((bits & WIT.TRIANGLE) != 0)
                tiles.addElement(tilePainter.getTile(tileW, tileW, bits & WIT.TRIANGLE, isBlackMark, null));
            if ((bits & WIT.CROSS) != 0)
                tiles.addElement(tilePainter.getTile(tileW, tileW, bits & WIT.CROSS, isBlackMark, null));
        }
        if ((bits & WIT.DIMMED) != 0)
            tiles.addElement(tilePainter.getTile(tileW, tileW, bits & WIT.DIMMED, false, null));

        int anchorX = (x - zoomX) * gridStep;
        int anchorY = (y - zoomY) * gridStep;
        Graphics g = gobanTile.getGraphics();
        for (int i = 0; i < tiles.size(); i++) {
            Tile tile = (Tile)tiles.elementAt(i);
            g.drawRGB(tile.pixels32, 0, tileW, anchorX, anchorY, tileW, tileW, true);
        }

        //repaint(gobanViewDevX + anchorX, gobanViewDevY + anchorY, tileW, tileW);
        //repaint();
        return true;
    }

    private void repaintCursor() {
        if (isInView(cursorX, cursorY)) {
            int tileW = gridStep + 1;
            int anchorX = (cursorX - zoomX) * gridStep;
            int anchorY = (cursorY - zoomY) * gridStep;
            repaint(gobanViewDevX + anchorX, gobanViewDevY + anchorY, tileW, tileW);
        }
    }

    public void showCursor(boolean visible) {
        if (cursorVisible != visible) {
            cursorVisible = visible;
            repaintCursor();
        }
    }

    public void setCursor(int x, int y) {
        if (cursorX != x || cursorY != y) {
            //#ifdef debug
            System.out.println("New cursor position: " + x + "," + y);
            //#endif

            if (cursorVisible)
                repaintCursor();
            cursorX = x;
            cursorY = y;
            if (cursorVisible)
                repaintCursor();
        }
    }

    private void drawComment(DocumentedGame game) {
        //#ifdef debug
        System.out.println("drawComment:");
        //#endif

        String moveStatus = null;
        boolean drawSolvedFailedIndicator = false;
        boolean goodMove = false;
        boolean drawColorToPlayIndicator = false;
        String comment = null;

        if (showMoveStatus)
            moveStatus = game.getFullMoveStatusText();

        if (showMoveStatus && commentLines > 1 || commentLines > 0) {
            SGFNode node = game.kifuLastMove();

            drawSolvedFailedIndicator = showSolvedFailedIndicator;
            goodMove = (node.bits & SGFNode.GOOD_MOVE) != 0;
            drawColorToPlayIndicator = showColorToPlayIndicator;

            // show solve/fail indicator if
            // 1) it's visible
            // 2) it's last node
            //    or no hints for next node
            //    or first fail node we want to see immediately
            // else show color to play indicator

            if (drawSolvedFailedIndicator) {
                SGFNodeIterator nextMoves = node.iterator();
                int bits = 0;
                if (nextMoves.next(true) != null) {
                    nextMoves.firstVariant(true);
                    do {
                        bits |= nextMoves.current().bits;
                    } while (nextMoves.nextVariant(true) != null);
                }

                //#ifdef debug
                System.out.println("Next move bits: " + bits);
                //#endif
                drawSolvedFailedIndicator =
                       ((bits & (SGFNode.GOOD_MOVE | SGFNode.BAD_MOVE)) == 0)
                    || (showFailedImmediately && (bits & SGFNode.BAD_MOVE) != 0);
            }

            try {
                comment = node.getCommentProperty();
            } catch (SGFException e) {
                // DO NOTHING
            }
        }

        tilePainter.drawComment(commentTile, commentLines, moveStatus, drawSolvedFailedIndicator, goodMove, drawColorToPlayIndicator, blackColorToPlay, comment);

        repaint(0, canvasDevH - commentViewDevH, canvasDevW, commentViewDevH);
    }

    private int remapActionKey(int keyCode) {
        // Remap game actions to simplify code
        switch (getGameAction(keyCode)) {
            case Canvas.LEFT:
                keyCode = Canvas.KEY_NUM4;
                break;
            case Canvas.RIGHT:
                keyCode = Canvas.KEY_NUM6;
                break;
            case Canvas.UP:
                keyCode = Canvas.KEY_NUM2;
                break;
            case Canvas.DOWN:
                keyCode = Canvas.KEY_NUM8;
                break;
            case Canvas.FIRE:
                keyCode = Canvas.KEY_NUM5;
                break;
        }
        return keyCode;
    }

    protected final void keyPressed(int _keyCode) {
        final int keyCode = remapActionKey(_keyCode);

        if (keyHeldCheckThread != null)
            keyHeldCheckThread.interrupt();
        keyHeldCheckThread = new Thread(new Runnable() {
            public void run() {
                try {
                    Thread.sleep(keyHeldDelay);
                    display.callSerially(new Runnable() {
                        public void run() {
                            controller.keyHeld(keyCode);
                        }
                    });
                } catch (InterruptedException e) {
                    // DO NOTHING
                }
            }
        });
        keyHeldCheckThread.start();

        controller.keyPressed(keyCode);
    }

    /*protected final void keyRepeated(int keyCode) {
        controller.keyRepeated(keyCode);
    }*/

    protected final void keyReleased(int keyCode) {
        keyCode = remapActionKey(keyCode);

        if (keyHeldCheckThread != null) {
            keyHeldCheckThread.interrupt();
            keyHeldCheckThread = null;
        }

        controller.keyReleased(keyCode);
    }

    protected void pointerPressed(int x, int y) {
    	if (y >= canvasDevH - 10) {
    		if (x < 10)
    			controller.keyPressed(Controller.KEY_SOFT1);
    		else if (x >= canvasDevW - 10)
    			controller.keyPressed(Controller.KEY_SOFT2);
    	}
    	else {
	        x -= gobanViewDevX;
	        if (x >= 0 && x < gobanViewDevW) {
		        x /= gridStep;
		        y -= gobanViewDevY;
		        if (y >= 0 && y < gobanViewDevH) {
			        y /= gridStep;
			        controller.pointerPressed(x, y);
		        }
	        }
    	}
    }

    protected void pointerDragged(int x, int y) {
        x -= gobanViewDevX;
        if (x >= 0 && x < gobanViewDevW) {
	        x /= gridStep;
	        y -= gobanViewDevY;
	        if (y >= 0 && y < gobanViewDevH) {
		        y /= gridStep;
		        controller.pointerDragged(x, y);
	        }
        }
    }

    protected void pointerReleased(int x, int y) {
        x -= gobanViewDevX;
        if (x >= 0 && x < gobanViewDevW) {
	        x /= gridStep;
	        y -= gobanViewDevY;
	        if (y >= 0 && y < gobanViewDevH) {
		        y /= gridStep;
		        controller.pointerReleased(x, y);
	        }
        }
    }

    protected void paint(Graphics g) {
        int cx = g.getClipX();
        int cy = g.getClipY();
        int cw = g.getClipWidth();
        int ch = g.getClipHeight();

        g.setColor(TilePainter.bgColor);
        g.fillRect(cx, cy, cw, ch);

        g.drawImage(gobanTile, gobanViewDevX, gobanViewDevY, Graphics.TOP | Graphics.LEFT);
        g.drawRGB(commentTile.pixels32, 0, commentTile.width,
                0, commentViewDevY, commentTile.width, commentTile.height, false);

        if (cursorVisible && isInView(cursorX, cursorY)) {
            int tileW = gridStep + 1;
            int anchorX = (cursorX - zoomX) * gridStep;
            int anchorY = (cursorY - zoomY) * gridStep;

            //gobanTile.getRGB(cursorTile.pixels32, 0, tileW, anchorX, anchorY, tileW, tileW);
            tilePainter.drawCursor(cursorTile, blackColorToPlay);
            g.drawRGB(cursorTile.pixels32, 0, tileW, gobanViewDevX + anchorX, gobanViewDevY + anchorY, tileW, tileW, true);
        }

        //g.setColor(0xff00ffff);
        //g.drawRect(cx, cy, cw - 1, ch - 1);
        /*int x = g.getClipX();
        int y = g.getClipY();
        int w = g.getClipWidth();
        int h = g.getClipHeight();
        /*int x = 0;
        int y = getHeight() - 12;
        int w = getWidth();
        int h = 12;*/
        /*g.setColor(0xff00ffff);
        g.drawRect(x, y, w - 1, h - 1);
        /*g.setColor(0xffffffff);
        g.fillArc(130, 130, 12, 12, 0, 360);
        g.setColor(0xff000000);
        g.drawArc(130, 130, 12, 12, 0, 360);
        Font f = Font.getFont(Font.FACE_PROPORTIONAL, Font.STYLE_PLAIN, Font.SIZE_SMALL);
        g.setFont(f);
        g.drawString("A", 136, 136 + f.getHeight() / 2, Graphics.HCENTER | Graphics.BOTTOM);*/
    }

    public void save(DataOutputStream dout) throws IOException {
        dout.writeByte(commentFontDevSize);
    }

    public void restore(DataInputStream din) throws IOException {
        int v = din.readByte();
        setCommentFontSize(v);
    }
}
