/**
 * TinyGo is a MIDlet to play and review Go board games.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 */
package com.tinygo;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;

import javax.microedition.io.Connector;
import javax.microedition.io.file.FileConnection;
import javax.microedition.io.file.FileSystemRegistry;
import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Choice;
import javax.microedition.lcdui.ChoiceGroup;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.List;
import javax.microedition.lcdui.StringItem;
import javax.microedition.lcdui.TextField;

import com.sgfj.SGFNode;
import com.sgfj.SGFParser;
import com.tinyutil.FilePath;
import com.tinyutil.T;

/**
 * @author Alexey Klimkin
 *
 */
class FileSelectScreen implements CommandListener {

    public final static String UP_DIRECTORY = "..";
    public final static String MEGA_ROOT = FilePath.separator;

    private String currDirName = MEGA_ROOT;

    private Display display;
    private FileSelectScreenListener listener;

    private Command newOkCommand    = new Command(T._("Ok"), Command.OK, 1);
    private Command selectCommand   = new Command(T._("Select"), Command.ITEM, 1);
    private Command backCommand     = new Command(T._("Back"), Command.BACK, 3);
    private Command backToBCommand  = new Command(T._("Back"), Command.BACK, 3);
    private Command newCommand      = new Command(T._("New"), Command.SCREEN, 4);
    private Command propCommand     = new Command(T._("Properties"), Command.ITEM, 5);
    private Command deleteCommand   = new Command(T._("Delete"), Command.ITEM, 6);
    private Command upCommand       = new Command(T._("Upper Dir"), Command.SCREEN, 7);
    private Command customCommand   = null;
    private TextField nameInput; // Input field for new file name
    private ChoiceGroup typeInput; // Input field for file type (regular/dir)

    private final static String[] attrList = { T._("Read"), T._("Write"), T._("Hidden") };
    private final static String[] typeList = { T._("Regular File"), T._("Directory") };
    private final static String[] monthList = { T._("Jan"), T._("Feb"), T._("Mar"), T._("Apr"),
            T._("May"), T._("Jun"), T._("Jul"), T._("Aug"), T._("Sep"), T._("Oct"), T._("Nov"), T._("Dec") };

    private boolean allowNew = true;
    private boolean allowDel = true;

    private Image dirIcon, fileIcon, sgfFileIcon, sgfiFileIcon;
    private Image[] iconList;

    public FileSelectScreen(Display display) {
        this.display = display;
        try {
            dirIcon = Image.createImage("/img/dir.png");
        } catch (IOException e) {
            dirIcon = null;
        }
        try {
            fileIcon = Image.createImage("/img/file.png");
        } catch (IOException e) {
            fileIcon = null;
        }
        try {
            sgfFileIcon = Image.createImage("/img/sgffile.png");
        } catch (IOException e) {
            sgfFileIcon = null;
        }
        try {
            sgfiFileIcon = Image.createImage("/img/sgfifile.png");
        } catch (IOException e) {
            sgfiFileIcon = null;
        }
        iconList = new Image[] { fileIcon, dirIcon };
    }

    public void setListener(FileSelectScreenListener listener) {
        this.listener = listener;
    }

    public boolean isSupported() {
        return System.getProperty("microedition.io.file.FileConnection.version") != null;
    }

    public void activate(boolean allowNew, boolean allowDel) {
        activate(allowNew, allowDel, null);
    }

    public void activate(boolean allowNew, boolean allowDel, Command customCommand) {
        this.allowNew = allowNew;
        this.allowDel = allowDel;
        this.customCommand = customCommand;
        new Thread(new Runnable() {
            public void run() {
                showCurrDir();
            }
        }).start();
    }

    public void commandAction(Command c, Displayable d) {
        if (c == selectCommand || c == upCommand) {
            List curr = (List) d;
            final String currFile;
            if (c == upCommand)
                currFile = UP_DIRECTORY;
            else
                currFile = curr.getString(curr.getSelectedIndex());
            if (currFile.endsWith(FilePath.separator) || currFile.equals(UP_DIRECTORY))
                new Thread(new Runnable() {
                    public void run() {
                        traverseDirectory(currFile);
                    }
                }).start();
            else
                selectFile(currFile, selectCommand);
        } else if (c == customCommand) {
            List curr = (List) d;
            String currFile = curr.getString(curr.getSelectedIndex());
            selectFile(currFile, customCommand);
        } else if (c == propCommand) {
            List curr = (List) d;
            final String currFile = curr.getString(curr.getSelectedIndex());
            new Thread(new Runnable() {
                public void run() {
                    showProperties(currFile);
                }
            }).start();
        } else if (c == backCommand) {
            listener.fileSelectDone();
        } else if (c == backToBCommand) {
            new Thread(new Runnable() {
                public void run() {
                    showCurrDir();
                }
            }).start();
        } else if (c == newCommand) {
            createFile();
        } else if (c == newOkCommand) {
            String newName = nameInput.getString();
            if (newName == null || newName.length() == 0) {
                Alert alert = new Alert(T._("Error!"),
                        T._("File Name is empty. Please provide file name."), null,
                        AlertType.ERROR);
                alert.setTimeout(Alert.FOREVER);
                display.setCurrent(alert);
            } else {
                // Create file in a separate thread and disable all commands
                // except for "cancel"
                display.getCurrent().removeCommand(newOkCommand);
                display.getCurrent().removeCommand(upCommand);
                executeCreateFile(newName, typeInput.getSelectedIndex() != 0);
            }
        } else if (c == deleteCommand) {
            List curr = (List) d;
            String currFile = curr.getString(curr.getSelectedIndex());
            executeDelete(currFile);
        }
    }

    List createBrowser() {
        List browser = new List(currDirName, Choice.IMPLICIT);
        browser.setSelectCommand(selectCommand);

        if (customCommand != null)
            browser.addCommand(customCommand);
        // Do not allow creating files/directories beside root
        if (!MEGA_ROOT.equals(currDirName)) {
            if (allowNew)
                browser.addCommand(newCommand);
            browser.addCommand(propCommand);
            if (allowDel)
                browser.addCommand(deleteCommand);
            browser.addCommand(upCommand);
        }
        browser.addCommand(backCommand);
        browser.setCommandListener(this);

        return browser;
    }

    void showCurrDir() {
        Displayable oldDisplayable = display.getCurrent();

        final WaitCanvas wc = WaitCanvas.getInstance();
        wc.setText(T._("Reading directory..."));
        wc.setProgress(0);
        display.setCurrent(wc);

        try {
            Enumeration e;
            FileConnection currDir = null;
            List browser = createBrowser();

            if (MEGA_ROOT.equals(currDirName)) {
                e = FileSystemRegistry.listRoots();
            } else {
                currDir = (FileConnection) Connector.open("file://localhost/"
                        + currDirName);
                e = currDir.list();
                // not root - draw UP_DIRECTORY
                browser.append(UP_DIRECTORY, dirIcon);
            }

            while (e.hasMoreElements()) {
                String fileName = (String) e.nextElement();
                if (fileName.charAt(fileName.length() - 1) == FilePath.separatorChar)
                    browser.append(fileName, dirIcon);
                else if (fileName.toLowerCase().endsWith(".sgf"))
                    browser.append(fileName, sgfFileIcon);
                else if (fileName.toLowerCase().endsWith(".sgfi"))
                    browser.append(fileName, sgfiFileIcon);
                else
                    browser.append(fileName, fileIcon);
            }

            if (currDir != null)
                currDir.close();

            display.setCurrent(browser);
        } catch (IOException e) {
            //#if debug
            e.printStackTrace();
            //#endif
            Alert alert = new Alert(
                    T._("Error!"),
                    T._("Can't access directory ") + currDirName
                    + "\n" + T._("Exception: ")
                    + e.getMessage(),
                    null, AlertType.ERROR);
            alert.setTimeout(Alert.FOREVER);
            display.setCurrent(alert, oldDisplayable);
        }
    }

    void traverseDirectory(String fileName) {
        if (currDirName.equals(MEGA_ROOT)) {
            if (fileName.equals(UP_DIRECTORY))
                // can not go up from MEGA_ROOT
                return;
            currDirName = fileName;
        } else if (fileName.equals(UP_DIRECTORY)) {
            // Go up one directory
            // TODO use setFileConnection when implemented
            int i = currDirName.lastIndexOf(FilePath.separatorChar, currDirName.length() - 2);
            if (i != -1)
                currDirName = currDirName.substring(0, i + 1);
            else
                currDirName = MEGA_ROOT;
        } else
            currDirName = currDirName + fileName;
        showCurrDir();
    }

    void selectFile(String fileName, Command cmd) {
/*        try {
            FileConnection fc;
            fc = (FileConnection) Connector.open("file://localhost/"
                    + currDirName + fileName);
            if (fc != null) {
                if (fc.exists())*/
                    listener.fileSelected(currDirName, fileName, cmd);
/*                fc.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }*/
    }

    void showProperties(String fileName) {
        try {
            if (fileName.equals(UP_DIRECTORY))
                return;

            FileConnection fc = (FileConnection) Connector.open("file://localhost/" + currDirName + fileName);
            if (!fc.exists())
                throw new IOException(T._("File does not exists."));

            Form props = new Form(T._("Properties") + ": " + fileName);
            props.addCommand(backToBCommand);
            props.setCommandListener(this);

            props.append(new StringItem(T._("Location"), currDirName));
            props.append(new StringItem(T._("Type"), fc.isDirectory() ? T._("Directory") : T._("Regular File")));
            props.append(new StringItem(T._("Size"), Long.toString((fc.isDirectory() ? fc.directorySize(true) : fc.fileSize()))));
            props.append(new StringItem(T._("Modified"), myDate(fc.lastModified())));

            ChoiceGroup attrs = new ChoiceGroup(T._("Attributes"), Choice.MULTIPLE, attrList, null);
            attrs.setSelectedFlags(new boolean[] { fc.canRead(), fc.canWrite(), fc.isHidden() });
            props.append(attrs);

            if (fileName.toLowerCase().endsWith(".sgf"))
                try {
                    StringBuffer sb = new StringBuffer();
                    InputStream is = fc.openInputStream();
                    InputStreamReader isr = new InputStreamReader(is);
                    SGFParser parser = new SGFParser(isr);
                    SGFNode head = parser.parseHead();
                    is.close();
                    for (Enumeration e = head.getProperties(); e.hasMoreElements(); ) {
                        sb.append(e.nextElement().toString());
                        sb.append("\n");
                    }
                    props.append(new StringItem(T._("SGF Header"), sb.toString()));
                } catch (Exception e) {
                }

            fc.close();
            display.setCurrent(props);
        } catch (Exception e) {
            Alert alert = new Alert(T._("Error!"), T._("Can't access file ") + fileName
                    + T._(" in directory ") + currDirName + "\n" + T._("Exception: ")
                    + e.getMessage(), null, AlertType.ERROR);
            alert.setTimeout(Alert.FOREVER);
            display.setCurrent(alert);
        }
    }

    private String myDate(long time) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date(time));

        StringBuffer sb = new StringBuffer();
        sb.append(cal.get(Calendar.HOUR_OF_DAY));
        sb.append(':');
        sb.append(cal.get(Calendar.MINUTE));
        sb.append(':');
        sb.append(cal.get(Calendar.SECOND));
        sb.append(',');
        sb.append(' ');
        sb.append(cal.get(Calendar.DAY_OF_MONTH));
        sb.append(' ');
        sb.append(monthList[cal.get(Calendar.MONTH)]);
        sb.append(' ');
        sb.append(cal.get(Calendar.YEAR));
        return sb.toString();
    }

    void delete(String currFile) {
        if (!currFile.equals(UP_DIRECTORY)) {
            if (currFile.endsWith(FilePath.separator)) {
                checkDeleteFolder(currFile);
            } else {
                deleteFile(currFile);
                showCurrDir();
            }
        } else {
            Alert cantDeleteFolder = new Alert(
                    T._("Error!"),
                    T._("Can not delete The up-directory (..) symbol! Not a real folder."),
                    null, AlertType.ERROR);
            cantDeleteFolder.setTimeout(Alert.FOREVER);
            display.setCurrent(cantDeleteFolder);
        }
    }

    void deleteFile(String fileName) {
        try {
            FileConnection fc = (FileConnection) Connector.open("file:///"
                    + currDirName + fileName);
            fc.delete();
        } catch (Exception e) {
            Alert alert = new Alert(T._("Error!"), T._("Can not access/delete file ")
                    + fileName + T._(" in directory ") + currDirName + "\n"
                    + T._("Exception: ") + e.getMessage(), null, AlertType.ERROR);
            alert.setTimeout(Alert.FOREVER);
            display.setCurrent(alert);
        }
    }

    private void executeDelete(String currFile) {
        final String file = currFile;
        new Thread(new Runnable() {
            public void run() {
                delete(file);
            }
        }).start();
    }

    private void checkDeleteFolder(String folderName) {
        try {
            FileConnection fcdir = (FileConnection) Connector
                    .open("file://localhost/" + currDirName + folderName);
            Enumeration content = fcdir.list("*", true);
            // only empty directory can be deleted
            if (!content.hasMoreElements()) {
                fcdir.delete();
                showCurrDir();
            } else {
                Alert cantDeleteFolder = new Alert(T._("Error!"),
                        T._("Can not delete The non-empty folder: ") + folderName,
                        null, AlertType.ERROR);
                cantDeleteFolder.setTimeout(Alert.FOREVER);
                display.setCurrent(cantDeleteFolder);
            }
        } catch (IOException ioe) {
            //#ifdef debug
            //System.out.println(currDirName + folderName);
            ioe.printStackTrace();
            //#endif
        }
    }

    void createFile() {
        Form creator = new Form(T._("New File"));
        nameInput = new TextField(T._("Enter Name"), null, 256, TextField.ANY);
        typeInput = new ChoiceGroup(T._("Enter File Type"), Choice.EXCLUSIVE,
                typeList, iconList);
        creator.append(nameInput);
        creator.append(typeInput);
        creator.addCommand(newOkCommand);
        creator.addCommand(backToBCommand);
        creator.setCommandListener(this);
        display.setCurrent(creator);
    }

    void createFile(String newName, boolean isDirectory) {
        try {
            FileConnection fc = (FileConnection) Connector.open("file://localhost/"
                    + currDirName + newName);
            if (isDirectory) {
                fc.mkdir();
            } else {
                fc.create();
            }
            fc.close();
            showCurrDir();
        } catch (Exception e) {
            String s = T._("Can not create file ") + newName;
            if (e.getMessage() != null && e.getMessage().length() > 0) {
                s += "\n" + e;
            }
            Alert alert = new Alert(T._("Error!"), s, null, AlertType.ERROR);
            alert.setTimeout(Alert.FOREVER);
            display.setCurrent(alert);
            // Restore the commands that were removed in commandAction()
            display.getCurrent().addCommand(newOkCommand);
            display.getCurrent().addCommand(upCommand);
        }
    }

    // Starts creatFile with another Thread
    private void executeCreateFile(final String name, final boolean val) {
        new Thread(new Runnable() {
            public void run() {
                createFile(name, val);
            }
        }).start();
    }
}
