/**
 * TinyGoTests is the collection of tests for TinyGo project.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, 
 * MA 02110-1301, USA.
 */
package com.tinygo.t;

import com.tinygo.logic.*;

import junit.framework.TestCase;


public class GameTest extends TestCase {

    public void testPlay() {
        try {
            Game game = new Game(2);
            Board board = game.board;
            game.play(0, 0, Board.BLACK);
            assertEquals(Board.WHITE, game.colorToPlay);
            assertEquals(1, game.moveNumber);

            // over stone
            try {
                game.play(0, 0);
                fail("Should be GameOverStoneException!");
            } catch (GameOverStoneException e) {
            }

            // suicide move
            board.set(1, 1, Board.BLACK);
            try {
                game.play(0, 1);
                fail("Should be GameSuicideMoveException!");
            } catch (GameSuicideMoveException e) {
            }

            // killing move
            board.set(1, 0, Board.BLACK);
            game.play(0, 1);
            assertEquals(board.get(0, 0), Board.NONE);
            assertEquals(board.get(1, 0), Board.NONE);
            assertEquals(board.get(1, 1), Board.NONE);
            assertEquals(3, game.whiteCaptures);

            // ko
            /*  *
             * * *
             * o*o
             *  o
             */
            game = new Game(4);
            board = game.board;
            int[][] moves = {
                    {0, 1, Board.BLACK},
                    {0, 2, Board.WHITE},
                    {1, 0, Board.BLACK},
                    {1, 3, Board.WHITE},
                    {1, 2, Board.BLACK},
                    {2, 2, Board.WHITE},
                    {2, 1, Board.BLACK},
                    {1, 1, Board.WHITE},	// eats black at 1,2
            };
            for (int m = 0; m < moves.length; m++) {
                int i = moves[m][0];
                int j = moves[m][1];
                game.play(i, j);
            }
            assertEquals(1, game.whiteCaptures);
            assertEquals(0, game.blackCaptures);
            try {
                game.play(1, 2);
                fail("Expected KO!");
            } catch (GameKoMoveException e) {
            }

            // non ko
            byte[] stones = {
                    Board.NONE, Board.NONE, Board.NONE, Board.NONE,
                    Board.NONE, Board.NONE, Board.BLACK, Board.WHITE,
                    Board.NONE, Board.BLACK, Board.WHITE, Board.BLACK,
                    Board.NONE, Board.BLACK, Board.WHITE, Board.NONE
            };
            game.init(4);
            for (int i = 0; i < stones.length; i++)
                board.set(i, stones[i]);
            game.pass(); // white to play
            game.play(3, 3);
            game.play(3, 2); // killing move

        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected!");
        }
    }

    public void testUndo() {
        Game game = new Game(4);
        Board board = game.board;
        try {
            // can't undo, if no moves
            assertFalse(game.undo());
            // test undo after kill
            int[][] moves = {
                    {0, 1, Board.BLACK},
                    {0, 2, Board.WHITE},
                    {1, 0, Board.BLACK},
                    {1, 3, Board.WHITE},
                    {1, 2, Board.BLACK},
                    {2, 2, Board.WHITE},
                    {2, 1, Board.BLACK},
                    {1, 1, Board.WHITE},	// eats black at 1,2
                    {3, 3, Board.BLACK}
            };
            for (int m = 0; m < moves.length; m++) {
                int i = moves[m][0];
                int j = moves[m][1];
                game.play(i, j);
            }
            assertEquals(1, game.whiteCaptures);
            assertEquals(0, game.blackCaptures);
            assertEquals(9, game.moveNumber);
            assertEquals(game.lastMove, board.pos(3, 3));
            assertEquals(-1, game.koMove);
            assertEquals(Board.WHITE, game.colorToPlay);
            assertEquals(board.get(1, 2), Board.NONE);
            assertTrue(game.undo());
            assertEquals(game.koMove, board.pos(1, 2));
            assertEquals(game.lastMove, board.pos(1, 1));
            assertEquals(Board.BLACK, game.colorToPlay);
            assertTrue(game.undo());
            assertEquals(0, game.whiteCaptures);
            assertEquals(0, game.blackCaptures);
            assertEquals(board.get(1, 2), Board.BLACK);
            assertEquals(7, game.moveNumber);
            assertEquals(game.lastMove, board.pos(2, 1));
            assertEquals(-1, game.koMove);
            assertEquals(Board.WHITE, game.colorToPlay);
            assertEquals(board.get(1, 1), Board.NONE);

            while (game.undo())
                // DO NOTHING
                ;
            assertEquals(0, game.moveNumber);
            assertEquals(-1, game.koMove);
            assertEquals(-1, game.lastMove);
            for (int i = 0; i < board.pos(3, 3); i++)
                assertEquals(Board.NONE, board.get(i));
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected!");
        }
    }

    public void testPass() {
        Game game = new Game(2);
        try {
            game.play(0, 0);
            assertEquals(Board.WHITE, game.colorToPlay);
            assertEquals(1, game.moveNumber);
            game.koMove = 1;
            game.pass();
            assertEquals(Board.BLACK, game.colorToPlay);
            assertEquals(2, game.moveNumber);
            assertEquals(-1, game.lastMove);
            assertEquals(-1, game.koMove);
            game.undo();
            assertEquals(Board.WHITE, game.colorToPlay);
            assertEquals(1, game.moveNumber);
            assertEquals(0, game.lastMove);
            assertEquals(1, game.koMove);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected!");
        }
    }

    public void testHandicap() {
        Game game = new Game(19);
        game.setHandicap(4);
        Board board = game.board;
        int pos;
        pos = board.hoshi(Board.HOSHI_NW);
        assertEquals(Board.BLACK, board.get(pos));
        pos = board.hoshi(Board.HOSHI_NE);
        assertEquals(Board.BLACK, board.get(pos));
        pos = board.hoshi(Board.HOSHI_SW);
        assertEquals(Board.BLACK, board.get(pos));
        pos = board.hoshi(Board.HOSHI_SE);
        assertEquals(Board.BLACK, board.get(pos));
    }

    public void testBlackOnlyPlay() {
        try {
            Game game = new Game(9);
            for (int pos = 0; pos < 80; pos++) {
                game.play(pos);
                game.pass();
            }
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected!");
        }
    }

    public void testAddUndo() {
        try {
            Game game = new Game(3);
            Board board = game.board;
            game.play(0, 0, Board.BLACK);
            game.set(1, 1, Board.BLACK);
            game.set(2, 2, Board.WHITE);
            assertEquals(board.get(0, 0), Board.BLACK);
            assertEquals(board.get(1, 1), Board.BLACK);
            assertEquals(board.get(2, 2), Board.WHITE);
            assertTrue(game.undo());
            for (int x = 0; x < 3; x++)
                for (int y = 0; y < 3; y++)
                    assertEquals(board.get(x, y), Board.NONE);
            assertFalse(game.undo());
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected!");
        }
    }

    public void testAddUndo2() {
        try {
            Game game = new Game(3);
            Board board = game.board;
            game.set(1, 1, Board.BLACK); // setup
            game.set(2, 2, Board.WHITE); // setup
            game.play(0, 0, Board.BLACK);
            assertEquals(board.get(0, 0), Board.BLACK);
            assertEquals(board.get(1, 1), Board.BLACK);
            assertEquals(board.get(2, 2), Board.WHITE);
            assertTrue(game.undo()); // undo the move, leave setup
            assertEquals(board.get(0, 0), Board.NONE);
            assertEquals(board.get(1, 1), Board.BLACK);
            assertEquals(board.get(2, 2), Board.WHITE);
            assertFalse(game.undo());
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected!");
        }
    }

    public void testRemoveUndo() {
        try {
            Game game = new Game(3);
            Board board = game.board;
            game.play(0, 0, Board.BLACK);
            game.play(2, 2, Board.WHITE);
            game.play(1, 1, Board.BLACK);
            assertEquals(board.get(0, 0), Board.BLACK);
            assertEquals(board.get(2, 2), Board.WHITE);
            assertEquals(board.get(1, 1), Board.BLACK);
            game.set(0, 0, Board.NONE);
            game.set(2, 2, Board.NONE);
            assertEquals(board.get(0, 0), Board.NONE);
            assertEquals(board.get(2, 2), Board.NONE);
            assertEquals(board.get(1, 1), Board.BLACK);
            assertTrue(game.undo());
            assertEquals(board.get(0, 0), Board.BLACK);
            assertEquals(board.get(2, 2), Board.WHITE);
            assertEquals(board.get(1, 1), Board.NONE);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected!");
        }
    }
}
