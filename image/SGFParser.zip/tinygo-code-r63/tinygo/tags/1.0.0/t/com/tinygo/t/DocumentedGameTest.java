/**
 * TinyGoTests is the collection of tests for TinyGo project.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 */
package com.tinygo.t;

import com.sgfj.SGFInvalidDataRequestException;
import com.sgfj.SGFMove;
import com.sgfj.SGFNode;
import com.sgfj.SGFNodeIterator;
import com.sgfj.SGFParser;
import com.sgfj.SGFPoint;
import com.sgfj.SGFPropertyNotFoundException;
import com.tinygo.logic.Board;
import com.tinygo.logic.DocumentedGame;
import com.tinygo.logic.GameException;
import com.tinygo.logic.GameOverStoneException;

import junit.framework.TestCase;

/**
 * @author Alexey Klimkin
 *
 */
public class DocumentedGameTest extends TestCase {
    static final byte N = Board.NONE, B = Board.BLACK, W = Board.WHITE;

    public void testGameFromSGF() {
        String sgfData = new String("(;" +
                "EV[Castle game]" +
                "PB[Honinbo Shusaku]" +
                "BR[6d]" +
                "PW[Ito Showa]" +
                "WR[7d]" +
                "KM[0]" +
                "RE[B+3]" +
                "DT[1850-11-17,18]" +
                "PC[Edo Castle, Japan]" +
                "US[jansteen@cwi.nl (Jan van der Steen)]" +
                "" +
                ";B[qd];W[op];B[dc];W[cp];B[ce];W[oc];B[kc];W[ke];B[pe];W[lc]" +
                ";B[nd];W[lb];B[eq];W[iq];B[dn];W[ep];B[dp];W[do];B[dq];W[co]" +
                ";B[eo];W[fp];B[cq];W[cn];B[en];W[cl];B[gr];W[hp];B[el];W[qp]" +
                ";B[qi];W[dj];B[hm];W[jo];B[ic];W[me];B[ne];W[qk];B[mf];W[jl]" +
                ";B[ej];W[ei];B[fj];W[cf];B[df];W[cg];B[ol];W[pi];B[qh];W[pj]" +
                ";B[ll];W[im];B[pm];W[mj];B[rm];W[ph];B[qg];W[on];B[rk];W[ql]" +
                ";B[qm];W[be];B[cd];W[ie];B[gd];W[hl];B[hk];W[ik];B[gl];W[ge]" +
                ";B[hd];W[hj];B[il];W[bq];B[br];W[hl];B[dk];W[ck];B[il];W[rl]" +
                ";B[qj];W[hl];B[di];W[cj];B[il];W[pk];B[po];W[hl];B[pp];W[pq]" +
                ";B[qq];W[oq];B[qr];W[gk];B[fh];W[eg];B[eh];W[dg];B[fk];W[gm]" +
                ";B[hi];W[he];B[ii];W[fd];B[fc];W[jh];B[fm];W[fl];B[gg];W[dh]" +
                ";B[gl];W[ed];B[ec];W[fl];B[ji];W[ki];B[gl];W[pn];B[qo];W[fl]" +
                ";B[kh];W[ig];B[gl];W[qn];B[ro];W[fl];B[ci];W[bi];B[gl];W[rn]" +
                ";B[oo];W[fl];B[ff];W[fg];B[gl];W[no];B[sn];W[fl];B[nn];W[gh]" +
                ";B[gl];W[hn];B[fi];W[hg];B[kj];W[li];B[gj];W[fl];B[lj];W[mi]" +
                ";B[gl];W[mn];B[nm];W[fl];B[jg];W[mk];B[gl];W[hk];B[dm];W[bo]" +
                ";B[fo];W[gp];B[gn];W[fl];B[ih];W[lg];B[gl];W[ar];B[bs];W[fl]" +
                ";B[lh];W[mh];B[gl];W[hr];B[fq];W[fl];B[mg];W[lf];B[gl];W[gq]" +
                ";B[gs];W[fl];B[bj];W[ch];B[gl];W[hs];B[er];W[fl];B[cm];W[bm]" +
                ";B[gl];W[ds];B[dr];W[fl];B[bn];W[ei];B[gl];W[es];B[cs];W[fl]" +
                ";B[jf];W[kd];B[gl];W[mo];B[md];W[rj];B[nb];W[jc];B[jb];W[kb]" +
                ";B[ri];W[of];B[lk];W[qc];B[og];W[pg];B[pf];W[ng];B[nf];W[oh]" +
                ";B[pb];W[pc];B[ob];W[jj];B[hm];W[gf];B[gi];W[gm];B[ib];W[id]" +
                ";B[hm];W[bd];B[bc];W[gm];B[le];W[kf];B[hm];W[gc];B[hc];W[gm]" +
                ";B[je];W[jd];B[hm];W[rd];B[qb];W[gm];B[go];W[fl];B[dl];W[ml]" +
                ";B[np];W[mp];B[or];W[nq];B[pr];W[re];B[qf];W[nc];B[mc];W[mb]" +
                ";B[rb];W[rc];B[sb];W[sk];B[sg];W[nr];B[ho];W[io];B[gl];W[gb]" +
                ";B[fb];W[fl];B[bf];W[bg];B[gl];W[ja];B[ga];W[fl];B[de];W[ef]" +
                ";B[gl];W[ia];B[hb];W[fl];B[ns];W[ms];B[os];W[mr];B[gl];W[na]" +
                ";B[oa];W[fl];B[ap];W[aq];B[gl];W[rf];B[rg];W[fl];B[ij];W[jk]" +
                ";B[gl];W[qa];B[ma];W[fl];B[mm];W[lm];B[gl];W[ra];B[pd];W[fl]" +
                ";B[ok];W[oj];B[gl];W[la];B[od];W[fl];B[ad];W[af];B[gl];W[sa]" +
                ";B[sf];W[fl];B[di];W[gl];B[ee];W[fe];B[ld];W[dd];B[cc];W[nk]" +
                ";B[si];W[if];B[sj];W[na];B[se];W[hh];B[rk];W[sl];B[rj];W[kc]" +
        ";B[ek];W[ma])");
        final int W = Board.WHITE;
        final int B = Board.BLACK;
        final int N = Board.NONE;
        int[] result = {
                N, N, N, N, N, N, B, N, W, W, N, W, W, W, B, N, W, W, W,
                N, N, N, N, N, B, N, B, B, B, W, W, W, B, B, B, B, B, B,
                N, B, B, B, B, B, N, B, B, W, W, W, B, W, W, W, W, W, N,
                B, W, B, W, W, W, B, B, W, W, W, B, B, B, B, B, B, W, N,
                N, W, B, B, B, W, W, W, W, B, W, B, N, B, N, B, N, W, B,
                W, N, W, B, W, N, W, N, W, B, W, W, B, B, W, B, B, W, B,
                N, W, W, W, W, W, N, W, W, B, N, W, B, W, N, W, B, B, B,
                N, N, W, W, B, B, W, W, B, N, B, B, W, N, W, W, B, N, N,
                N, W, N, B, N, B, B, B, B, B, W, W, W, N, N, W, B, B, B,
                N, B, W, W, B, B, B, W, B, W, B, B, W, N, W, W, B, B, B,
                N, N, W, B, B, B, W, W, W, W, N, B, W, W, B, W, W, B, W,
                N, N, W, B, B, W, W, W, N, W, N, B, W, N, B, N, W, W, W,
                N, W, B, B, N, B, W, N, W, N, N, W, B, B, N, B, B, B, N,
                N, B, W, B, B, N, B, W, N, N, N, N, W, B, W, W, W, W, B,
                N, W, W, W, B, B, B, B, W, W, N, N, W, W, B, B, B, B, N,
                B, N, W, B, W, W, W, W, N, N, N, N, W, N, W, B, W, N, N,
                W, W, B, B, B, B, W, N, W, N, N, N, N, W, W, W, B, N, N,
                W, B, N, B, B, N, B, W, N, N, N, N, W, W, B, B, B, N, N,
                N, B, B, W, W, N, B, W, N, N, N, N, W, B, B, N, N, N, N
        };
        int wCaptures = 44;
        int bCaptures = 39;

        SGFParser reader = new SGFParser(sgfData);
        SGFNode tree = null;
        try {
            tree = reader.parse();
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected!");
        }
        assertNotNull("Emty tree received.", tree);

        try {
            SGFNodeIterator ni = tree.iterator();
            while (ni.next(true) != null)
                // DO NOTHING
                ;

            DocumentedGame game = new DocumentedGame(ni.current());
            //System.out.print(game.board.toString());
            assertEquals(wCaptures, game.whiteCaptures);
            assertEquals(bCaptures, game.blackCaptures);
            for (int pos = 0; pos < result.length; pos++) {
                SGFPoint p = game.board.xy(pos);
                assertEquals("" + p.x + "," + p.y + ":", result[pos], game.board.get(pos));
            }
        } catch (SGFInvalidDataRequestException e) {
            e.printStackTrace();
            fail("Unexpected!");
        } catch (SGFPropertyNotFoundException e) {
            e.printStackTrace();
            fail("Unexpected!");
        } catch (GameException e) {
            e.printStackTrace();
            fail("Unexpected!");
        }
    }

    public void testNavigation() {
        DocumentedGame game = new DocumentedGame(4);
        Board board = game.board;
        try {
            assertFalse(game.prev());
            assertFalse(game.next());

            SGFNode n2w, n3b_1, n3b_2;
            // test forward/backward navigation
            game.play(3, 3, Board.BLACK);
            game.play(0, 1, Board.WHITE);
            n2w = game.kifuLastMove();
            game.play(0, 2, Board.BLACK);
            n3b_1 = game.kifuLastMove();

            assertTrue(game.prev());
            assertSame(n2w, game.kifuLastMove());
            assertEquals(board.pos(0, 1), game.lastMove);
            assertEquals(Board.BLACK, game.colorToPlay);
            assertTrue(game.next());
            assertSame(n3b_1, game.kifuLastMove());
            assertEquals(board.pos(0, 2), game.lastMove);
            assertEquals(Board.WHITE, game.colorToPlay);
            assertFalse(game.next());

            // test variant navigation
            assertTrue(game.prev());
            game.play(0, 0, Board.BLACK); // variant to 0,2
            n3b_2 = game.kifuLastMove();
            assertEquals(board.pos(0, 0), game.lastMove);
            assertFalse(game.nextVariant());
            assertTrue(game.prevVariant());
            assertSame(n3b_1, game.kifuLastMove());
            assertEquals(board.pos(0, 2), game.lastMove);
            assertFalse(game.prevVariant());
            assertTrue(game.nextVariant());
            assertSame(n3b_2, game.kifuLastMove());
            assertEquals(board.pos(0, 0), game.lastMove);

            assertEquals(Board.WHITE, game.colorToPlay);

            // check if variant option is remembered
            assertFalse(game.nextVariant());
            assertTrue(game.prev());
            assertSame(n2w, game.kifuLastMove());
            assertTrue(game.next());
            assertSame(n3b_2, game.kifuLastMove());
            assertFalse(game.nextVariant());
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected!");
        }
    }

    public void testNavigation2() {
        DocumentedGame game = new DocumentedGame(4);
        try {
            game.play(0, 0);
            try {
                game.play(0, 0);
            } catch (GameOverStoneException e) {
            }
            assertEquals(game.board.pos(0, 0), game.lastMove);
            assertEquals(Board.WHITE, game.colorToPlay);
            while (game.prev())
                // DO NOTHING
                ;
            game.next();
            game.next();
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected!");
        }
    }

    public void testVariants() {
        DocumentedGame game = new DocumentedGame(3);
        try {
            game.play(0, 0);
            assertTrue(game.prev());
            game.play(1, 1);
            assertTrue(game.prevVariant());
            game.play(2, 2);
            assertTrue(game.prev());
            assertTrue(game.nextVariant());
            assertTrue(game.prevVariant());
            assertTrue(game.next());

            byte[] data = {
                    Board.BLACK, Board.NONE, Board.NONE,
                    Board.NONE, Board.NONE, Board.NONE,
                    Board.NONE, Board.NONE, Board.WHITE
            };
            for (int i = 0; i < data.length; i++)
                assertEquals(data[i], game.board.get(i));
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected!");
        }
    }

    public void testVariants2() {
        DocumentedGame game = new DocumentedGame(3);
        try {
            game.play(1, 1);
            game.play(0, 1);
            assertTrue(game.prev());
            game.play(1, 0);
            game.play(0, 1);
            assertTrue(game.prev());
            assertTrue(game.prev());
            assertTrue(game.next());
            assertTrue(game.next());

            byte[] data = {
                    Board.NONE, Board.WHITE, Board.NONE,
                    Board.BLACK, Board.BLACK, Board.NONE,
                    Board.NONE, Board.NONE, Board.NONE
            };
            for (int i = 0; i < data.length; i++)
                assertEquals(data[i], game.board.get(i));
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected!");
        }
    }

    public void testInit() {
        DocumentedGame game = new DocumentedGame(4);
        try {
            game.play(0, 0);
            assertTrue(game.prev());
            game.play(1, 1);
            game.init(4);
            assertFalse(game.prev());
            assertFalse(game.next());
            assertFalse(game.prevVariant());
            assertFalse(game.nextVariant());
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected!");
        }
    }

    public void testPass() {
        DocumentedGame game = new DocumentedGame(4);
        try {
            game.play(0, 0);
            game.pass();
            assertEquals(Board.BLACK, game.colorToPlay);
            game.prev();
            assertEquals(Board.WHITE, game.colorToPlay);
            game.next();
            assertEquals(Board.BLACK, game.colorToPlay);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected!");
        }
    }

    public void testHandicap() {
        DocumentedGame game = new DocumentedGame(9);
        game.setHandicap(4);
        try {
            DocumentedGame newGame = new DocumentedGame(game.kifuHead());
            Board board = newGame.board;
            int pos;
            pos = board.hoshi(Board.HOSHI_NW);
            assertEquals(Board.BLACK, board.get(pos));
            pos = board.hoshi(Board.HOSHI_NE);
            assertEquals(Board.BLACK, board.get(pos));
            pos = board.hoshi(Board.HOSHI_SW);
            assertEquals(Board.BLACK, board.get(pos));
            pos = board.hoshi(Board.HOSHI_SE);
            assertEquals(Board.BLACK, board.get(pos));
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected!");
        }
    }

    public void testCgobanSGF() {
        try {
            String data = "(;GM[1]FF[3]SZ[4]HA[0](;AW[bb]PL[2](;W[cc])(;W[aa])))";
            SGFParser parser = new SGFParser(data);
            SGFNode tree = parser.parse();
            DocumentedGame game = new DocumentedGame(tree);
            game.next();
            assertEquals(game.board.get(1, 1), Board.WHITE);
            assertEquals(Board.WHITE, game.colorToPlay);
            game.next();
            assertEquals(game.board.get(2, 2), Board.WHITE);
            game.nextVariant();
            assertEquals(game.board.get(2, 2), Board.NONE);
            assertEquals(game.board.get(0, 0), Board.WHITE);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected!");
        }
    }

    public void testUndoAdd() {
        try {
            String data = "(;GM[1]FF[3]SZ[4]HA[0];AW[bb]AB[aa]PL[2];W[cc]))";
            SGFParser parser = new SGFParser(data);
            SGFNode tree = parser.parse();
            DocumentedGame game = new DocumentedGame(tree);
            game.next();
            assertEquals(Board.BLACK, game.board.get(0, 0));
            assertEquals(Board.WHITE, game.board.get(1, 1));
            assertEquals(Board.NONE, game.board.get(2, 2));
            game.next();
            assertEquals(Board.BLACK, game.board.get(0, 0));
            assertEquals(Board.WHITE, game.board.get(1, 1));
            assertEquals(Board.WHITE, game.board.get(2, 2));
            game.prev();
            assertEquals(Board.BLACK, game.board.get(0, 0));
            assertEquals(Board.WHITE, game.board.get(1, 1));
            assertEquals(Board.NONE, game.board.get(2, 2));
            game.prev();
            assertEquals(Board.NONE, game.board.get(0, 0));
            assertEquals(Board.NONE, game.board.get(1, 1));
            assertEquals(Board.NONE, game.board.get(2, 2));
            game.next();
            game.next();
            game.undo();
            assertEquals(Board.BLACK, game.board.get(0, 0));
            assertEquals(Board.WHITE, game.board.get(1, 1));
            assertEquals(Board.NONE, game.board.get(2, 2));
            game.undo();
            assertEquals(Board.NONE, game.board.get(0, 0));
            assertEquals(Board.NONE, game.board.get(1, 1));
            assertEquals(Board.NONE, game.board.get(2, 2));
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected!");
        }
    }

    public void testUndoAddEmpty() {
        try {
            String data = "(;GM[1]FF[3]SZ[4]HA[0];AW[bb]AB[aa]PL[2];W[cc]AE[aa]))";
            SGFParser parser = new SGFParser(data);
            SGFNode tree = parser.parse();
            DocumentedGame game = new DocumentedGame(tree);
            game.next();
            assertEquals(Board.BLACK, game.board.get(0, 0));
            assertEquals(Board.WHITE, game.board.get(1, 1));
            assertEquals(Board.NONE, game.board.get(2, 2));
            game.next();
            assertEquals(Board.NONE, game.board.get(0, 0));
            assertEquals(Board.WHITE, game.board.get(1, 1));
            assertEquals(Board.WHITE, game.board.get(2, 2));
            game.prev();
            assertEquals(Board.BLACK, game.board.get(0, 0));
            assertEquals(Board.WHITE, game.board.get(1, 1));
            assertEquals(Board.NONE, game.board.get(2, 2));
            game.prev();
            assertEquals(Board.NONE, game.board.get(0, 0));
            assertEquals(Board.NONE, game.board.get(1, 1));
            assertEquals(Board.NONE, game.board.get(2, 2));
            game.next();
            game.next();
            game.undo();
            assertEquals(Board.BLACK, game.board.get(0, 0));
            assertEquals(Board.WHITE, game.board.get(1, 1));
            assertEquals(Board.NONE, game.board.get(2, 2));
            game.undo();
            assertEquals(Board.NONE, game.board.get(0, 0));
            assertEquals(Board.NONE, game.board.get(1, 1));
            assertEquals(Board.NONE, game.board.get(2, 2));
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected!");
        }
    }

    public void testWhiteToPlay() {
        try {
            String data = "(;GM[1]FF[3]SZ[4]HA[0];W[cc])";
            SGFParser parser = new SGFParser(data);
            SGFNode tree = parser.parse();
            DocumentedGame game = new DocumentedGame(tree);
            assertEquals(Board.WHITE, game.colorToPlay);
            game.next();
            assertEquals(game.board.get(2, 2), Board.WHITE);

            data = "(;PW[White]PB[Black];AB[pn](;B[rr];W[rs](;B[sr])(;B[ss];W[sr])(;B[qr];W[sr])(;B[rq];W[sr]))(;B[rs];W[rr])(;B[sr];W[rr])(;B[ss];W[rr]))";
            parser = new SGFParser(data);
            tree = parser.parse();
            game = new DocumentedGame(tree);
            assertEquals(SGFMove.BLACK, game.colorToPlay);
            game.next();
            assertEquals(SGFMove.BLACK, game.colorToPlay);
            game.next();
            assertEquals(SGFMove.WHITE, game.colorToPlay);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected!");
        }
    }

    public void testKifuFirstMove() {
        try {
            String data = "(;PW[White]PB[Me]AW[cb]AW[db]AW[eb]AW[bc]AW[cc]AW[cd]AW[dd]AW[ed]AW[fd]AW[gd]AW[de]AW[fe]AW[df]AW[ef]AB[bb]AB[fb]AB[hb]AB[ac]AB[dc]AB[ec]AB[fc]AB[gc]AB[bd]AB[hd]AB[be]AB[ce]AB[ge]AB[he]AB[cf]AB[ff]AB[hf]AB[cg]AB[dg]AB[eg]AB[fg];B[](;W[ca]CR[ca](;B[ea]CR[ea];W[ab]CR[ab](;B[aa]CR[aa];W[ba]CR[ba]C[RIGHT])(;B[ad]CR[ad];W[ba]CR[ba]C[RIGHT]))(;B[ad]CR[ad];W[ea]CR[ea]C[RIGHT])(;B[ab]CR[ab];W[ea]CR[ea]C[RIGHT]))(;W[ea]CR[ea];B[ca]CR[ca](;W[ab]CR[ab];B[aa]CR[aa])(;W[da]CR[da];B[ab]CR[ab])(;W[ba]CR[ba];B[ab]CR[ab]))(;W[ab]CR[ab];B[aa]CR[aa](;W[ca]CR[ca](;B[ea]CR[ea];W[ba]CR[ba]C[RIGHT])(;B[ad]CR[ad];W[ea]CR[ea]C[RIGHT]))(;W[ea]CR[ea];B[ca]CR[ca]))(;W[ba]CR[ba];B[ab]CR[ab](;W[ca]CR[ca];B[ea]CR[ea])(;W[ea]CR[ea];B[ca]CR[ca]))(;W[da]CR[da];B[ab]CR[ab]))";
            SGFParser parser = new SGFParser(data);
            SGFNode tree = parser.parse();
            DocumentedGame game = new DocumentedGame(tree);
            SGFNode node = game.kifuFirstMove(true);
            SGFMove move = node.getMoveProperty();
            assertEquals(SGFMove.WHITE, move.color);
            assertEquals(2, move.x);
            assertEquals(0, move.y);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected!");
        }
    }

    public void testCompressed() {
        try {
            String data = "(;SZ[3]AW[aa:cb]AB[bc][cc])";
            SGFParser parser = new SGFParser(data);
            SGFNode tree = parser.parse();
            DocumentedGame game = new DocumentedGame(tree);
            byte[] gold = {
                W, W, W,
                W, W, W,
                N, B, B
            };
            for (int pos = 0; pos < game.board.maxPos(); pos++)
                assertEquals(gold[pos], game.board.get(pos));
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected!");
        }
    }

    void checkData(String data, byte[][] gold, int[] wCapts, int[] bCapts) throws Exception {
        SGFParser parser = new SGFParser(data);
        SGFNode tree = parser.parse();
        DocumentedGame game = new DocumentedGame(tree);
        int node = 0;
        do {
            for (int pos = 0; pos < game.board.maxPos(); pos++) {
                //SGFPoint p = game.board.xy(pos);
                //System.out.println("Node " + node + " pos " + p.x + "," + p.y);
                assertEquals(gold[node][pos], game.board.get(pos));
            }
            assertEquals(wCapts[node], game.whiteCaptures);
            assertEquals(bCapts[node], game.blackCaptures);

            node++;
        } while (game.next());
        assertEquals(gold.length, node);
    }
    /**
     * Check SGF FF[5] examples work correctly
     * http://www.red-bean.com/sgf/ff5/m_vs_ax.htm
     */
    public void testFF5() {
        try {
            String data = "(;FF[5]GM[1]SZ[6] AB[bb:ee] ;AW[bb][ee][dc][cd] ;AW[cb][bc][be][eb][ed][de] ;AE[dc][cd])";
            byte[][] gold = {{
                N, N, N, N, N, N,
                N, B, B, B, B, N,
                N, B, B, B, B, N,
                N, B, B, B, B, N,
                N, B, B, B, B, N,
                N, N, N, N, N, N
            }, {
                N, N, N, N, N, N,
                N, W, B, B, B, N,
                N, B, B, W, B, N,
                N, B, W, B, B, N,
                N, B, B, B, W, N,
                N, N, N, N, N, N
            }, {
                N, N, N, N, N, N,
                N, W, W, B, W, N,
                N, W, B, W, B, N,
                N, B, W, B, W, N,
                N, W, B, W, W, N,
                N, N, N, N, N, N
            }, {
                N, N, N, N, N, N,
                N, W, W, B, W, N,
                N, W, B, N, B, N,
                N, B, N, B, W, N,
                N, W, B, W, W, N,
                N, N, N, N, N, N }
            };
            int[] wCapts = { 0, 0, 0, 0 };
            int[] bCapts = { 0, 0, 0, 0 };
            checkData(data, gold, wCapts, bCapts);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected!");
        }

        try {
            String data = "(;FF[5]GM[1]SZ[6] AB[bb:ee]AW[bb][ee][dc][cd][cb][bc][be][eb][ed][de] ;B[dd])";
            byte[][] gold = {{
                N, N, N, N, N, N,
                N, W, W, B, W, N,
                N, W, B, W, B, N,
                N, B, W, B, W, N,
                N, W, B, W, W, N,
                N, N, N, N, N, N
            }, {
                N, N, N, N, N, N,
                N, W, W, B, W, N,
                N, W, B, N, B, N,
                N, B, N, B, W, N,
                N, W, B, W, W, N,
                N, N, N, N, N, N }
            };
            int[] wCapts = { 0, 0 };
            int[] bCapts = { 0, 2 };
            checkData(data, gold, wCapts, bCapts);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected!");
        }

        try {
            String data = "(;FF[5]GM[1]SZ[6] AB[cb][bc][cc][dc][cd] ;W[cc])";
            byte[][] gold = {{
                N, N, N, N, N, N,
                N, N, B, N, N, N,
                N, B, B, B, N, N,
                N, N, B, N, N, N,
                N, N, N, N, N, N,
                N, N, N, N, N, N,
            }, {
                N, N, N, N, N, N,
                N, N, B, N, N, N,
                N, B, N, B, N, N,
                N, N, B, N, N, N,
                N, N, N, N, N, N,
                N, N, N, N, N, N, }
            };
            int[] wCapts = { 0, 0 };
            int[] bCapts = { 0, 1 };
            checkData(data, gold, wCapts, bCapts);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unexpected!");
        }
    }
}
