/**
 * TinyGoTests is the collection of tests for TinyGo project.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, 
 * MA 02110-1301, USA.
 */
package com.tinygo.t;

import com.tinygo.logic.Group;

import junit.framework.TestCase;

public class GroupTest extends TestCase {

    public void testAdd() {
        Group g = new Group(3);
        g.add(1);
        assertEquals(1, g.size);
        assertEquals(1, g.stones[0]);
    }

    public void testRemove() {
        Group g = new Group(3);
        g.add(1);
        g.add(2);
        g.add(3);
        g.remove(1);
        assertEquals(2, g.size);
        assertEquals(3, g.stones[0]);
        assertEquals(2, g.stones[1]);
        g.remove(2);
        assertEquals(1, g.size);
        g.remove(3);
        assertEquals(0, g.size);
        g.remove(5);
        assertEquals(0, g.size);
    }

    public void testClear() {
        Group g = new Group(3);
        g.add(1);
        g.add(2);
        g.add(3);
        g.liberties = 10;
        g.clear();
        assertEquals(0, g.size);
        assertEquals(0, g.liberties);
    }

}
