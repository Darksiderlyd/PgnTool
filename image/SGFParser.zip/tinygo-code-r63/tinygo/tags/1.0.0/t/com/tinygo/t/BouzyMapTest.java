/**
 * TinyGoTests is the collection of tests for TinyGo project.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, 
 * MA 02110-1301, USA.
 */
package com.tinygo.t;

import com.tinygo.logic.Board;
import com.tinygo.logic.BouzyMap;

import junit.framework.TestCase;

public class BouzyMapTest extends TestCase {

    public void testAll() {
        Board board1 = new Board(9);
        board1.set(3, 4, Board.BLACK);
        board1.set(5, 4, Board.BLACK);
        BouzyMap bmap1 = new BouzyMap(board1);

        Board board2 = new Board(9);
        board2.set(3, 4, Board.WHITE);
        board2.set(5, 4, Board.WHITE);
        BouzyMap bmap2 = new BouzyMap(board2);

        bmap1.eval(1, 0);
        bmap2.eval(1, 0);
        int[] d1 = {
                0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 1, 0, 1, 0, 0, 0,
                0, 0, 1, 128, 2, 128, 1, 0, 0,
                0, 0, 0, 1, 0, 1, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0
        };
        for (int pos = 0; pos < d1.length; pos++) {
            assertEquals(d1[pos], bmap1.get(pos));
            assertEquals(-d1[pos], bmap2.get(pos));
        }

        bmap1.eval(1, 0);
        bmap2.eval(1, 0);
        int[] d2 = {
                0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 1, 0, 1, 0, 0, 0,
                0, 0, 2, 2, 3, 2, 2, 0, 0,
                0, 1, 2, 132, 4, 132, 2, 1, 0,
                0, 0, 2, 2, 3, 2, 2, 0, 0,
                0, 0, 0, 1, 0, 1, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0
        };
        for (int pos = 0; pos < d2.length; pos++) {
            assertEquals(d2[pos], bmap1.get(pos));
            assertEquals(-d2[pos], bmap2.get(pos));
        }

        bmap1.eval(1, 0);
        bmap2.eval(1, 0);
        int[] d3 = {
                0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 1, 0, 1, 0, 0, 0,
                0, 0, 2, 2, 3, 2, 2, 0, 0,
                0, 2, 4, 6, 6, 6, 4, 2, 0,
                1, 2, 6, 136, 8, 136, 6, 2, 1,
                0, 2, 4, 6, 6, 6, 4, 2, 0,
                0, 0, 2, 2, 3, 2, 2, 0, 0,
                0, 0, 0, 1, 0, 1, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0
        };
        for (int pos = 0; pos < d3.length; pos++) {
            assertEquals(d3[pos], bmap1.get(pos));
            assertEquals(-d3[pos], bmap2.get(pos));
        }

        bmap1.eval(0, 1);
        bmap2.eval(0, 1);
        int[] d4 = {
                0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 2, 2, 2, 0, 0, 0,
                0, 0, 4, 6, 6, 6, 4, 0, 0,
                0, 2, 6, 136, 8, 136, 6, 2, 0,
                0, 0, 4, 6, 6, 6, 4, 0, 0,
                0, 0, 0, 2, 2, 2, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0
        };
        for (int pos = 0; pos < d4.length; pos++) {
            assertEquals(d4[pos], bmap1.get(pos));
            assertEquals(-d4[pos], bmap2.get(pos));
        }

        bmap1.eval(0, 4);
        bmap2.eval(0, 4);
        int[] d5 = {
                0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 1, 4, 1, 0, 0, 0,
                0, 0, 0, 136, 8, 136, 0, 0, 0,
                0, 0, 0, 1, 4, 1, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0
        };
        for (int pos = 0; pos < d5.length; pos++) {
            assertEquals(d5[pos], bmap1.get(pos));
            assertEquals(-d5[pos], bmap2.get(pos));
        }
    }
}
