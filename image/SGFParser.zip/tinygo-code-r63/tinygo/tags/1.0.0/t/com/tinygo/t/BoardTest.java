/**
 * TinyGoTests is the collection of tests for TinyGo project.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, 
 * MA 02110-1301, USA.
 */
package com.tinygo.t;

import java.util.Vector;

import com.tinygo.logic.*;

import junit.framework.TestCase;

public class BoardTest extends TestCase {

    public void testSNWE() {
        Board board = new Board(2);
        assertEquals(2, board.s(0));
        assertEquals(0, board.n(2));
        assertEquals(1, board.e(0));
        assertEquals(0, board.w(1));
        assertEquals(-1, board.s(2));
        assertEquals(-1, board.n(1));
        assertEquals(-1, board.e(1));
        assertEquals(-1, board.w(2));
    }

    protected static Vector g2v(Group group) {
        Vector v = new Vector(group.size);
        for (int i = 0; i < group.size; i++)
            v.addElement(new Integer(group.stones[i]));
        return v;
    }
    protected static Integer I(int i) {
        return new Integer(i);
    }

    public void testGetGroup() {
        Board board = new Board(2);
        board.set(0, Board.WHITE);
        board.set(1, Board.WHITE);
        board.set(2, Board.BLACK);

        Group group = new Group(4);
        Vector v;

        board.getGroup(0, group);
        v = g2v(group);
        assertEquals(2, group.size);
        assertEquals(1, group.liberties);
        assertEquals(Board.WHITE, group.color);
        assertTrue(v.contains(I(0)));
        assertTrue(v.contains(I(1)));

        group.clear();
        board.getGroup(1, group);
        v = g2v(group);
        assertEquals(2, group.size);
        assertEquals(1, group.liberties);
        assertEquals(Board.WHITE, group.color);
        assertTrue(v.contains(I(0)));
        assertTrue(v.contains(I(1)));

        group.clear();
        board.getGroup(2, group);
        v = g2v(group);
        assertEquals(1, group.size);
        assertEquals(1, group.liberties);
        assertEquals(Board.BLACK, group.color);
        assertTrue(v.contains(I(2)));

        group.clear();
        board.getGroup(3, group);
        v = g2v(group);
        assertEquals(1, group.size);
        assertEquals(0, group.liberties);
        assertEquals(Board.NONE, group.color);
        assertTrue(v.contains(I(3)));
    }


}
