/**
 * TinyGo is a MIDlet to play and review Go board games.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, 
 * MA 02110-1301, USA.
 */
package com.tinygo.logic;

import java.util.Enumeration;
import java.util.Stack;

import com.sgfj.SGFFloatProperty;
import com.sgfj.SGFIntProperty;
import com.sgfj.SGFInvalidDataRequestException;
import com.sgfj.SGFMove;
import com.sgfj.SGFNode;
import com.sgfj.SGFNodeIterator;
import com.sgfj.SGFPoint;
import com.sgfj.SGFPointProperty;
import com.sgfj.SGFProperty;
import com.sgfj.SGFPropertyName;
import com.sgfj.SGFPropertyNotFoundException;
import com.sgfj.SGFTextProperty;

/**
 * @author Alexey Klimkin
 *
 */
public class DocumentedGame extends Game {

    public static String application = "Tiny Go:1.0";
    public static String charset = "UTF-8";

    SGFNodeIterator kifu;

    /**
     * @param size
     */
    public DocumentedGame(int size) {
        super();
        init(size);
    }

    public DocumentedGame(int size, float komi, String ruleSet, String white, String black) {
        super();
        init(size, komi, ruleSet, white, black);
    }

    /**
     * @param current
     * @throws SGFInvalidDataRequestException
     * @throws SGFPropertyNotFoundException
     * @throws GameException
     */
    public DocumentedGame(SGFNode current) throws SGFInvalidDataRequestException, SGFPropertyNotFoundException, GameException {
        Stack moves = new Stack();
        SGFNodeIterator ni = current.iterator();
        while (ni.prev(false) != null) {
            moves.push(ni.current());
            ni.prev(true);
        }

        SGFNode head = ni.current();
        kifu = current.iterator();

        // Read size and init board
        int size;
        try {
            size = head.getProperty(SGFPropertyName.SZ).getInt();
        } catch (SGFPropertyNotFoundException e) {
            size = 19;
        }
        super.init(size);

        // Read handicap property, stones added with AW/AB
        try {
            handicap  = head.getProperty(SGFPropertyName.HA).getInt();
        } catch (SGFPropertyNotFoundException e) {
            handicap = 0;
        }

        playNodeProperties();

        // Find color to play for first nodes without move
        do {
            try {
                byte color = ni.current().getMoveProperty().color;
                if (color != Board.NONE) {
                    colorToPlay = color;
                    break;
                }
            } catch (SGFPropertyNotFoundException e) {
            }
        } while (ni.next(true) != null);

        // Play moves from head to provided node
        while (!moves.empty()) {
            SGFNode node = (SGFNode) moves.pop();
            try {
                SGFMove move = node.getMoveProperty();
                boardPlay(move, true);
            } catch (SGFPropertyNotFoundException e) {
                advance();
            }
            playNodeProperties();
        }
    }

    public void init(int size) {
        super.init(size);
        SGFNode head = new SGFNode();
        head.addProperty(new SGFIntProperty(SGFPropertyName.GM, 1));
        head.addProperty(new SGFIntProperty(SGFPropertyName.FF, 4));
        head.addProperty(new SGFTextProperty(SGFPropertyName.CA, charset.toCharArray()));
        head.addProperty(new SGFTextProperty(SGFPropertyName.AP, application.toCharArray()));
        head.addProperty(new SGFIntProperty(SGFPropertyName.SZ, size));
        kifu = head.iterator();
    }

    public void init(int size, float komi, String ruleSet, String white, String black) {
        init(size);
        SGFNode head = kifuHead();
        head.addProperty(new SGFFloatProperty(SGFPropertyName.KM, komi));
        head.addProperty(new SGFTextProperty(SGFPropertyName.RU, ruleSet.toCharArray()));
        head.addProperty(new SGFTextProperty(SGFPropertyName.PW, white.toCharArray()));
        head.addProperty(new SGFTextProperty(SGFPropertyName.PB, black.toCharArray()));
    }

    public void setHandicap(int handicap) {
        super.setHandicap(handicap);

        SGFNode head = kifu.first(false);
        head.addProperty(new SGFIntProperty(SGFPropertyName.HA, handicap));

        for (int pos = 0; pos < board.maxPos(); pos ++) {
            byte color = board.get(pos);
            if (color != Board.NONE) {
                SGFPropertyName name;
                if (color == Board.WHITE)
                    name = SGFPropertyName.AW;
                else
                    name = SGFPropertyName.AB;
                head.addProperty(new SGFPointProperty(name, board.xy(pos)));
            }
        }
    }



    public Score getScore(TerritoryEvaluator tE) {
        // TODO: add test
        int bTerr = 0, bDead = 0, bCaptured = whiteCaptures;
    int wTerr = 0, wDead = 0, wCaptured = blackCaptures;

    for (int pos = 0; pos < board.maxPos(); pos++) {
        int color = board.get(pos);
        int val = tE.get(pos);
        if (color == Board.NONE) {
            if (val > 0)
                bTerr++;
            else if (val < 0)
                wTerr++;
        } else if (board.isBit(pos, Board.M_CAPTURED)) {
            if (val > 0) {
                bTerr++;
                wDead++;
            } else if (val < 0) {
                wTerr++;
                bDead++;
            }
        }
    }

    SGFNode head = kifuHead();
    float komi;
    try {
        komi = head.getProperty(SGFPropertyName.KM).getFloat();
    } catch (Exception e) {
        komi = 0;
    }
    float bScore = bTerr - bCaptured - bDead;
    float wScore = wTerr - wCaptured - wDead + komi;
    float score = bScore - wScore;

    String scoreText;
    if (score == 0)
        scoreText = "Tie";
    else if (score > 0)
        scoreText = "B+" + score;
    else
        scoreText = "W+" + (0.0 - score);
    try {
        String docScore = head.getProperty(SGFPropertyName.RE).getText();
        scoreText += " (" + docScore + ")";
    } catch (Exception e) {
    }

    Score sc = new Score();
    sc.bCaptured = bCaptured;
    sc.wCaptured = wCaptured;
    sc.bDead = bDead;
    sc.wDead = wDead;
    sc.bTerr = bTerr;
    sc.wTerr = wTerr;
    sc.komi = komi;
    sc.bScore = bScore;
    sc.wScore = wScore;
    sc.score = score;
    sc.scoreText = scoreText;
    return sc;
    }

    public final SGFNode kifuHead() {
        return kifu.first(false);
    }

    public final SGFNode kifuLastMove() {
        return kifu.current();
    }

    /**
     * @return First node with move property.
     */
    public SGFNode kifuFirstMove(boolean skipPass) {
        SGFNodeIterator i = kifu.first(false).iterator();
        do {
            try {
                SGFMove move = i.current().getMoveProperty();
                if (!skipPass || move.x >= 0)
                    break;
            } catch (SGFPropertyNotFoundException e) {
            }
        } while (i.next(true) != null);
        return i.current();
    }

    private final void boardPlay(int pos, byte color, boolean allowIllegal) throws GameException {
        super.play(pos, color, allowIllegal);
    }

    private final void boardPlay(SGFMove move, boolean allowIllegal) throws GameException {
        if (move.x < 0 || move.x >= board.size() || move.y < 0 || move.y >= board.size())
            super.pass();
        else
            super.play(board.pos(move.x, move.y), move.color, allowIllegal);
    }

    protected void playNodeProperties() throws GameOverStoneException {
        SGFNode node = kifu.current();

        for (Enumeration e = node.getProperties(); e.hasMoreElements(); ) {
            SGFProperty prop = (SGFProperty) e.nextElement();
            try {
                if (prop.name() == SGFPropertyName.PL) {
                    char[] t = prop.getText().toCharArray();
                    switch (t[0]) {
                    case 'B':
                    case '1':
                        colorToPlay = Board.BLACK;
                        break;
                    case 'W':
                    case '2':
                        colorToPlay = Board.WHITE;
                        break;
                    }
                } else if (prop.name() == SGFPropertyName.AW) {
                    SGFPoint p = prop.getPoint();
                    int pos = board.pos(p);
                    set(pos, Board.WHITE);
                } else if (prop.name() == SGFPropertyName.AB) {
                    SGFPoint p = prop.getPoint();
                    int pos = board.pos(p);
                    set(pos, Board.BLACK);
                } else if (prop.name() == SGFPropertyName.AE) {
                    SGFPoint p = prop.getPoint();
                    int pos = board.pos(p);
                    set(pos, Board.NONE);
                }
            } catch (SGFInvalidDataRequestException e1) {
                // DO NOTHING
            }
        }
    }

    public void play(int pos, byte color, boolean allowIllegal) throws GameException {
        // play on board to check exceptions first
        boardPlay(pos, color, allowIllegal);
        kifu.current().play(new SGFMove(board.xy(pos), color));
        kifu.next(true);
        playNodeProperties();
    }

    public void pass() throws GameOverStoneException {
        super.pass();
        kifu.current().play(new SGFMove(-1, -1, colorToPlay));
        kifu.next(true);
        playNodeProperties();
    }

    public boolean undo() {
        if (!super.undo())
            return false;
        SGFNode node = kifu.current();
        kifu.prev(true);
        node.remove();
        return true;
    }

    public boolean next() throws GameException {
        SGFNode node = kifu.next(false);
        if (node == null)
            return false;
        try {
            SGFMove move = node.getMoveProperty();
            boardPlay(move, true);
        } catch (SGFPropertyNotFoundException e) {
            advance();
        }
        kifu.next(true);
        playNodeProperties();
        return true;
    }

    public boolean prev() {
        if (kifu.prev(false) == null)
            return false;
        super.undo();
        kifu.prev(true);
        return true;
    }

    public boolean nextVariant() throws SGFPropertyNotFoundException, GameException {
        SGFNode node = kifu.nextVariant(false);
        if (node == null)
            return false;
        super.undo();
        try {
            try {
                SGFMove move = node.getMoveProperty();
                boardPlay(move, true);
            } catch (SGFPropertyNotFoundException e) {
                advance();
            }
            kifu.nextVariant(true);
            playNodeProperties();
        } catch (GameException e) {
            kifu.prev(true);
            throw e;
        }
        return true;
    }

    public boolean prevVariant() throws SGFPropertyNotFoundException, GameException {
        SGFNode node = kifu.prevVariant(false);
        if (node == null)
            return false;
        super.undo();
        try {
            try {
                SGFMove move = node.getMoveProperty();
                boardPlay(move, true);
            } catch (SGFPropertyNotFoundException e) {
                advance();
            }
            kifu.prevVariant(true);
            playNodeProperties();
        } catch (GameException e) {
            kifu.prev(true);
            throw e;
        }
        return true;
    }

    public String getFullMoveStatusText() {
        return getFullMoveStatusText(false);
    }

    public String getFullMoveStatusText(boolean viewMode) {
        String nodeName = null;
        try {
            nodeName = kifu.current().getProperty(SGFPropertyName.N).getText();
        } catch (SGFPropertyNotFoundException e) {
            // DO NOTHING
        } catch (SGFInvalidDataRequestException e) {
            // DO NOTHING
        }

        if (!(viewMode && kifu.next(false) == null))
            return super.getFullMoveStatusText(nodeName);

        String docScore;
        SGFNode head = kifu.first(false);
        try {
            docScore = head.getProperty(SGFPropertyName.RE).getText();
        } catch (Exception e) {
            docScore = "end";
        }

        return getMoveStatusText(nodeName) + ": " + docScore;
    }
}
