/**
 * TinyGo is a MIDlet to play Go and review Go board game files.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 */
package com.tinygo.gam;

import java.util.Hashtable;

class TileCacheKey {
    int width;
    int height;
    int what;
    boolean black;
    String label;

    TileCacheKey(int width, int height, int what, boolean black, String label) {
        this.width = width;
        this.height = height;
        this.what = what;
        this.black = black;
        this.label = label;
    }

    public boolean equals(Object obj) {
        TileCacheKey o = (TileCacheKey)obj;
        return o.width == width && o.height == height
            && o.what == what && o.black == black
            && (o.label == label || (label != null && o.label.equals(label)));
    }

    public int hashCode() {
        int v = what;
        v ^= (black ? 1 : 0) << 20;
        v ^= width << 24;
        v ^= height << 28;
        if (label != null)
            v ^= label.hashCode();
        return v;
    }
}

/**
 * @author Alexey Klimkin
 *
 */
public abstract class TilePainter {
    public static int gobanColor  		= 0xffe79e10;
    public static int gobanMarkColor 	= 0xff000000;// black
    public static int whiteStoneColor 	= 0xffffffff;// white
    public static int blackStoneColor 	= 0xff000000;// black
    public static int whiteMarkColor 	= 0xffffffff;// white
    public static int blackMarkColor 	= 0xff000000;// black
    public static int selectedColor 	= 0xffff0000;// red
    public static int variantColor 		= 0x60000000;
    public static int moyoWhiteColor 	= 0xffffffff;// white
    public static int moyoBlackColor 	= 0xff000000;// black
    public static int goodMoveColor 	= 0xff00ff00;// green
    public static int badMoveColor  	= 0xffff0000;// red
    public static int dimmedColor 		= 0x60000000;
    public static int bgColor 			= 0xffe7b95f;//0xffe7ce9d;
    public static int commentBgColor 	= 0xffe7b95f;
    public static int commentFgColor 	= 0xff000000;// black
    public static int progressColor		= 0xff10cee7;

    private Hashtable ht = new Hashtable(64);

    public Tile getTile(int width, int height, int what, boolean black, String label) {
        TileCacheKey key = new TileCacheKey(width, height, what, black, label);
        Tile  tile = (Tile)ht.get(key);
        if (tile == null) {
            tile = getTileNC(width, height, what, black, label);
            ht.put(key, tile);
        }
        return tile;
    }

    public Tile getTileNC(int width, int height, int what, boolean black, String label) {
        Tile tile = createTile(width, height);
        drawTile(tile, what, black, label);
        return tile;
    }

    public Tile createTile(int width, int height) {
        final Tile tile = new Tile();
        tile.width = (short)width;
        tile.height = (short)height;
        tile.pixels32 = new int[width * height];
        return tile;
    }

    public void drawTile(final Tile tile, int what, boolean black, String label) {
        //System.out.println("Draw tile " + what + " black=" + black);
        if ((what & WIT.CELL) != 0)
            drawCell(tile, what);
        else if ((what & WIT.STONE) != 0)
            drawStone(tile, black);
        else if ((what & WIT.VARIANT) != 0)
            drawVariant(tile);
        else if ((what & WIT.HINT) != 0)
            drawVariant(tile, (what & WIT.GOOD_MOVE) != 0);
        else if ((what & WIT.CIRCLE) != 0)
            drawCircle(tile, black);
        else if ((what & WIT.SELECTED) != 0)
            drawSelected(tile, black);
        else if ((what & WIT.SQUARE) != 0)
            drawSquare(tile, black);
        else if ((what & WIT.TRIANGLE) != 0)
            drawTriangle(tile, black);
        else if ((what & WIT.CROSS) != 0)
            drawCross(tile, black);
        else if ((what & WIT.LABEL_BG) != 0)
            drawLabelBackground(tile);
        else if ((what & WIT.LABEL) != 0)
            drawLabel(tile, black, label);
        else if ((what & WIT.TER) != 0)
            drawTerritory(tile, black);
        else if ((what & WIT.DIMMED) != 0)
            drawDimmed(tile, black);
    }

    abstract void drawCell(final Tile tile, int what);
    abstract void drawStone(final Tile tile, boolean black);
    abstract void drawVariant(final Tile tile);
    abstract void drawVariant(final Tile tile, boolean good);
    abstract void drawCircle(final Tile tile, boolean black);
    abstract void drawSelected(final Tile tile, boolean black);
    abstract void drawSquare(final Tile tile, boolean black);
    abstract void drawTriangle(final Tile tile, boolean black);
    abstract void drawCross(final Tile tile, boolean black);
    abstract void drawLabel(final Tile tile, boolean black, String label);
    abstract void drawLabelBackground(final Tile tile);
    abstract void drawTerritory(final Tile tile, boolean black);
    abstract void drawDimmed(final Tile tile, boolean black);

    public abstract void drawCursor(final Tile tile, boolean black);
    public abstract void drawPlainBoard(final Tile tile);
    public abstract void drawBackground(final Tile tile);
    public abstract void drawComment(final Tile tile,
            int commentLines,
            String moveStatus,
            boolean drawSolvedFailedIndicator, boolean goodMove,
            boolean drawColorToPlayIndicator, boolean black,
            String comment);
}
