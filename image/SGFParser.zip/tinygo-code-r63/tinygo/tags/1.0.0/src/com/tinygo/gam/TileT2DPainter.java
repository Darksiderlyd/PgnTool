/**
 * TinyGo is a MIDlet to play Go and review Go board game files.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 */
package com.tinygo.gam;

import com.tinyline.tiny2d.Tiny2D;
import com.tinyline.tiny2d.TinyBuffer;
import com.tinyline.tiny2d.TinyColor;
import com.tinyline.tiny2d.TinyFont;
import com.tinyline.tiny2d.TinyPoint;
import com.tinyline.tiny2d.TinyRect;
import com.tinyline.tiny2d.TinyVector;

/**
 * @author Alexey Klimkin
 *
 */
public class TileT2DPainter extends TilePainter {

    private static final int ONE    = 1 << Tiny2D.FIX_BITS;
    private static final int HALF   = 1 << (Tiny2D.FIX_BITS - 1);

    private static final int daAnchorX = 3 << (Tiny2D.FIX_BITS - 1); // 1.5
    private static final int daAnchorY = 3 << (Tiny2D.FIX_BITS - 1); // 1.5

    private final int daWidth(final Tile tile) {
        return (tile.width - 2) << Tiny2D.FIX_BITS;
    }

    private final int daHeight(final Tile tile) {
        return (tile.height - 2) << Tiny2D.FIX_BITS;
    }

    private Tiny2D getT2D(final Tile tile) {
        TinyBuffer pixbuf = new TinyBuffer();
        pixbuf.width = tile.width;
        pixbuf.height = tile.height;
        pixbuf.pixels32 = tile.pixels32;

        Tiny2D t2d = new Tiny2D(pixbuf);
        t2d.antialias = true;
        TinyRect clip = t2d.getClip();
        t2d.devClip = clip;
        t2d.clearRect(clip);
        t2d.invalidate();
        return t2d;
    }

    private void setT2DPureMark(Tiny2D t2d, final Tile tile, boolean black) {
        t2d.strokeWidth = Math.max(ONE, (ONE * tile.width) >> 4);
        t2d.strokeColor = new TinyColor(black ? blackMarkColor : whiteMarkColor);
        t2d.fillColor = TinyColor.NONE;
    }

    void drawCell(final Tile tile, int what) {
        int w = tile.width;
        int h = tile.height;

        for (int i = 0; i < w * h; i++)
            tile.pixels32[i] = gobanColor;

        int cx = w >> 1, cy = h >> 1;
        int x0 = 0, x1 = 0, y0 = 0, y1 = 0;
        int cellType = what & WIT.CELL & ~WIT.HOSHI;
        switch (cellType) {
            case WIT.C_CELL:
            case WIT.N_CELL:
            case WIT.S_CELL:
                x1 = w - 1;
                break;
            case WIT.E_CELL:
            case WIT.NE_CELL:
            case WIT.SE_CELL:
                x1 = cx;
                break;
            case WIT.W_CELL:
            case WIT.NW_CELL:
            case WIT.SW_CELL:
                x0 = cx;
                x1 = w - 1;
                break;
        }
        switch (cellType) {
            case WIT.C_CELL:
            case WIT.E_CELL:
            case WIT.W_CELL:
                y1 = h - 1;
                break;
            case WIT.N_CELL:
            case WIT.NE_CELL:
            case WIT.NW_CELL:
                y0 = cy;
                y1 = h - 1;
                break;
            case WIT.S_CELL:
            case WIT.SE_CELL:
            case WIT.SW_CELL:
                y1 = cy;
                break;
        }
        for (int i = y0 * tile.width + cx; i <= y1 * tile.width + cx; i += tile.width)
            tile.pixels32[i] = gobanMarkColor;
        for (int i = cy * tile.width + x0; i <= cy * tile.width + x1; i++)
            tile.pixels32[i] = gobanMarkColor;

        if ((what & WIT.HOSHI) != 0) {
            tile.pixels32[(cy - 1) * tile.width + cx - 1] = gobanMarkColor;
            tile.pixels32[(cy - 1) * tile.width + cx + 1] = gobanMarkColor;
            tile.pixels32[(cy + 1) * tile.width + cx - 1] = gobanMarkColor;
            tile.pixels32[(cy + 1) * tile.width + cx + 1] = gobanMarkColor;
        }
    }

    void drawStone(final Tile tile, boolean black) {
        Tiny2D t2d = getT2D(tile);

        t2d.strokeColor = new TinyColor(blackStoneColor);
        t2d.strokeWidth = ONE;
        if (black)
            t2d.fillColor = t2d.strokeColor;
        else
            t2d.fillColor = new TinyColor(whiteStoneColor);

        t2d.drawOval(daAnchorX, daAnchorY, daWidth(tile), daHeight(tile));
        //t2d.drawLine(arg0, arg1, arg2, arg3)
    }

    void drawCircle(final Tile tile, boolean black) {
        Tiny2D t2d = getT2D(tile);
        setT2DPureMark(t2d, tile, black);

        int wH = daWidth(tile) >> 1;
        int hH = daHeight(tile) >> 1;
        int wQ = wH >> 1;
        int hQ = hH >> 1;
        t2d.drawOval(daAnchorX + wQ, daAnchorY + hQ, wH, hH);
    }

    void drawSelected(final Tile tile, boolean black) {
        Tiny2D t2d = getT2D(tile);
        //t2d.strokeWidth = ONE;
        //t2d.strokeColor = new TinyColor(selectedColor);
        t2d.fillColor = new TinyColor(selectedColor);

        int wH = daWidth(tile) >> 1;
        int hH = daHeight(tile) >> 1;
        int wQ = wH >> 1;
        int hQ = hH >> 1;
        t2d.drawRect(daAnchorX + wQ, daAnchorY + hQ, wH, hH);
    }

    void drawCross(final Tile tile, boolean black) {
        Tiny2D t2d = getT2D(tile);
        setT2DPureMark(t2d, tile, black);

        int wH = daWidth(tile) >> 1;
        int hH = daHeight(tile) >> 1;
        int wQ = wH >> 1;
        int hQ = hH >> 1;
        t2d.drawLine(daAnchorX + wQ, daAnchorY + hQ, daAnchorX + wH + wQ, daAnchorY + hH + hQ);
        t2d.drawLine(daAnchorX + wQ, daAnchorY + hH + hQ, daAnchorX + wH + wQ, daAnchorY + hQ);
    }

    void drawSquare(final Tile tile, boolean black) {
        Tiny2D t2d = getT2D(tile);
        setT2DPureMark(t2d, tile, black);

        int wH = daWidth(tile) >> 1;
        int hH = daHeight(tile) >> 1;
        int wQ = wH >> 1;
        int hQ = hH >> 1;
        t2d.drawRect(daAnchorX + wQ, daAnchorY + hQ, wH, hH);
    }

    void drawTriangle(final Tile tile, boolean black) {
        Tiny2D t2d = getT2D(tile);
        setT2DPureMark(t2d, tile, black);

        int wH = daWidth(tile) >> 1;
        int hH = daHeight(tile) >> 1;
        int triangleYTop = wH - ONE;
        int triangleXBottom = triangleYTop * 866 / 1000; // * sqrt(3)/2
        int triangleYBottom = triangleYTop / 2;
        TinyVector poly = new TinyVector(3);
        poly.addElement(new TinyPoint(daAnchorX + wH, daAnchorY + hH - triangleYTop));
        poly.addElement(new TinyPoint(daAnchorX + wH + triangleXBottom, daAnchorY + hH + triangleYBottom));
        poly.addElement(new TinyPoint(daAnchorX + wH - triangleXBottom, daAnchorY + hH + triangleYBottom));
        t2d.drawPolygon(poly);
    }

    void drawLabel(final Tile tile, boolean black, String label) {
        Tiny2D t2d = getT2D(tile);
        setT2DPureMark(t2d, tile, black);
        t2d.fillColor = t2d.strokeColor;
        t2d.strokeColor = TinyColor.NONE;

        int wH = daWidth(tile) >> 1;
        int hH = daHeight(tile) >> 1;
        int stoneSize = daWidth(tile);
        int fontSize = stoneSize;
        TinyFont font = MyArial.getFont();

        char[] text = label.toCharArray();
        TinyRect cbox;
        // calculate fontSize, so the number fits into stone
        while (true) {
            cbox = Tiny2D.charsBounds(font, fontSize, text, 0, text.length, Tiny2D.TEXT_DIR_LR);
            // add one pixel from each side, so the number won't blent with stone border
            if (cbox.xmax - cbox.xmin + ONE * 2 >= stoneSize)
                fontSize -= HALF;
            else
                break;
        }
        t2d.drawChars(font, fontSize, text, 0, text.length,
                daAnchorX + wH - (cbox.xmax - cbox.xmin) / 2,
                // same baseline for any text
                daAnchorY + hH + fontSize * (font.ascent + font.descent) / font.unitsPerEm / 2,
                Tiny2D.TEXT_ANCHOR_START);
    }

    void drawLabelBackground(final Tile tile) {
        Tiny2D t2d = getT2D(tile);
        t2d.fillColor = new TinyColor(gobanColor);
        t2d.drawOval(daAnchorX, daAnchorY, daWidth(tile), daHeight(tile));
    }

    void drawTerritory(final Tile tile, boolean black) {
        Tiny2D t2d = getT2D(tile);
        int color = black ? moyoBlackColor : moyoWhiteColor;
        t2d.fillColor = new TinyColor(color);

        int wH = daWidth(tile) >> 1;
        int hH = daHeight(tile) >> 1;
        int wQ = wH >> 1;
        int hQ = hH >> 1;
//        t2d.drawOval(daAnchorX + wQ, daAnchorY + hQ, wH, hH);
        t2d.drawRect(daAnchorX + wQ, daAnchorY + hQ, wH, hH);
    }

    void drawDimmed(final Tile tile, boolean black) {
        for (int i = 0; i < tile.width * tile.height; i++)
            tile.pixels32[i] = dimmedColor;
    }

    void drawVariant(final Tile tile) {
        Tiny2D t2d = getT2D(tile);
        //t2d.strokeColor = TinyColor.NONE;
        t2d.fillColor = new TinyColor(variantColor);
        t2d.drawOval(daAnchorX, daAnchorY, daWidth(tile), daHeight(tile));
    }

    void drawVariant(final Tile tile, boolean good) {
        Tiny2D t2d = getT2D(tile);
        //t2d.strokeColor = new TinyColor(good ? goodMoveColor : badMoveColor);
        t2d.fillColor = new TinyColor(good ? goodMoveColor : badMoveColor);
        t2d.drawOval(daAnchorX, daAnchorY, daWidth(tile), daHeight(tile));
    }

    public void drawCursor(final Tile tile, boolean black) {
        /* Old - draw inverted rect.
        for (int i = 0; i < tile.width; i++)
            tile.pixels32[i] = ~tile.pixels32[i];
        for (int i = tile.width * (tile.height - 1); i < tile.width * tile.height; i++)
            tile.pixels32[i] = ~tile.pixels32[i];
        for (int i = tile.width; i < tile.width * (tile.height - 1); i += tile.width)
            tile.pixels32[i] = ~tile.pixels32[i];
        for (int i = tile.width * 2 - 1; i < tile.width * tile.height - 1; i += tile.width)
            tile.pixels32[i] = ~tile.pixels32[i];*/

        int color = black ? blackStoneColor : whiteStoneColor;
        int dx = tile.width >> 2;
        int ddx = dx >> 1;
        int dy = tile.height >> 2;
        int ddy = dy >> 1;
        if (ddx > 0 && ddy > 0) {
            for (int y = 0; y < ddy; y++)
                for (int x = 0; x < dx; x++) {
                    tile.pixels32[x + y * tile.width] = color;
                    tile.pixels32[tile.width - x - 1 + y * tile.width] = color;
                    tile.pixels32[x + (tile.height - y - 1) * tile.width] = color;
                    tile.pixels32[tile.width - x - 1 + (tile.height - y - 1) * tile.width] = color;
                }
            for (int y = ddy; y < dy; y++)
                for (int x = 0; x < ddx; x++) {
                    tile.pixels32[x + y * tile.width] = color;
                    tile.pixels32[tile.width - x - 1 + y * tile.width] = color;
                    tile.pixels32[x + (tile.height - y - 1) * tile.width] = color;
                    tile.pixels32[tile.width - x - 1 + (tile.height - y - 1) * tile.width] = color;
                }
        } else {
            for (int i = 0; i < tile.width; i++)
                tile.pixels32[i] = color;
            for (int i = tile.width * (tile.height - 1); i < tile.width * tile.height; i++)
                tile.pixels32[i] = color;
            for (int i = tile.width; i < tile.width * (tile.height - 1); i += tile.width)
                tile.pixels32[i] = color;
            for (int i = tile.width * 2 - 1; i < tile.width * tile.height - 1; i += tile.width)
                tile.pixels32[i] = color;
        }
    }

    public void drawPlainBoard(final Tile tile) {
        for (int i = 0; i < tile.pixels32.length; i++)
            tile.pixels32[i] = gobanColor;
    }

    public void drawBackground(final Tile tile) {
        for (int i = 0; i < tile.pixels32.length; i++)
            tile.pixels32[i] = bgColor;
    }

    public void drawComment(final Tile tile,
            int commentLines,
            String moveStatus,
            boolean drawSolvedFailedIndicator, boolean goodMove,
            boolean drawColorToPlayIndicator, boolean black,
            String comment) {

        if (commentLines <= 0)
            return;

        Tiny2D t2d = getT2D(tile);
        TinyFont font = MyArial.getFont();
        int commentFontSize = daHeight(tile) / commentLines;
        //int commentFontDescent = commentFontSize * font.descent / font.unitsPerEm;
        int commentFontAscent = commentFontSize * font.ascent / font.unitsPerEm;
        TinyColor fgColor = new TinyColor(commentFgColor);

        for (int i = 0; i < tile.pixels32.length; i++)
            tile.pixels32[i] = commentBgColor;

        int Y = 0; // y position to draw

        if (moveStatus != null) {
            char[] text = moveStatus.toCharArray();
            //#ifdef debug
            System.out.println("\t" + moveStatus);
            //#endif
            int X = daWidth(tile) / 2;
            t2d.strokeColor = TinyColor.NONE;
            t2d.fillColor = fgColor;
            t2d.drawChars(font, commentFontSize, text, 0, text.length, X, Y + commentFontAscent, Tiny2D.TEXT_ANCHOR_MIDDLE);
            Y += commentFontSize;
            commentLines--;
        }

        if (commentLines > 0) {
            int X = ONE * 2;

            // draw move indicator
            if (drawSolvedFailedIndicator || drawColorToPlayIndicator) {
                t2d.strokeWidth = ONE;
                t2d.strokeColor = fgColor;
                if (drawSolvedFailedIndicator)
                    t2d.fillColor = new TinyColor(goodMove ? goodMoveColor : badMoveColor);
                else if (drawColorToPlayIndicator)
                    t2d.fillColor = new TinyColor(black ? blackStoneColor : whiteStoneColor);
                t2d.drawOval(X, Y + ONE, commentFontSize - ONE * 2, commentFontSize - ONE * 2);
                X = commentFontSize + commentFontSize / 4;
            }

            if (comment != null) {
                char[] text = comment.toCharArray();
                //#ifdef debug
                System.out.println("\t" + comment);
                //#endif

                t2d.strokeColor = TinyColor.NONE;
                t2d.fillColor = fgColor;

                int off = 0; // The current char pointer
                int len = 0; // The current length of the line
                //int breakOff = -1; // break line at space points

                do {
                    boolean drawChars = len == text.length;

                    if (!drawChars) {
                        TinyRect cbox = Tiny2D.charsBounds(font, commentFontSize,
                                text, off, len, Tiny2D.TEXT_DIR_LR);
                        if (X + cbox.xmax - cbox.xmin + ONE > daWidth(tile)) {
                            len--;
                            drawChars = true;
                        }
                    }

                    if (drawChars){
                        // Draw the current line
                        //t2d.matrix = new TinyMatrix();
                        //if (breakOff <= off || len == text.length)
                        //breakOff = len;
                        t2d.drawChars(font, commentFontSize, text, off,
                                /*breakOff*/len, X, Y + commentFontAscent, Tiny2D.TEXT_ANCHOR_START);
                        // Advance one line
                        if (off == 0)
                            X = ONE;
                        //off = breakOff + 1;
                        off = len;
                        Y += commentFontSize;
                        if (--commentLines == 0)
                            break;
                    } /*else if (text[len] == ' ' || text[len] == '\t')
                    breakOff = len;*/
                    len++;
                } while (len <= text.length && Y < daHeight(tile));
            }
        }
    }

}
