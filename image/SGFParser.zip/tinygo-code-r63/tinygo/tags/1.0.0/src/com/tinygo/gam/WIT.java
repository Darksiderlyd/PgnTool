/**
 * TinyGo is a MIDlet to play Go and review Go board game files.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 */
package com.tinygo.gam;

/**
 * What Is There (WIT) - cache item used to draw only if absolutely necessary.
 * @author Alexey Klimkin
 *
 */
public final class WIT {
    public static final int BLACK_STONE   = 0x000001;
    public static final int WHITE_STONE   = 0x000002;
    public static final int STONE         = BLACK_STONE|WHITE_STONE;
    public static final int HOSHI         = 0x000004;
    public static final int VARIANT       = 0x000008;
    public static final int GOOD_MOVE     = 0x000010;
    public static final int BAD_MOVE      = 0x000020;
    public static final int HINT          = GOOD_MOVE|BAD_MOVE;
    public static final int BLACK_TER     = 0x000040;
    public static final int WHITE_TER     = 0x000080;
    public static final int TER           = BLACK_TER|WHITE_TER;
    public static final int LABEL         = 0x000100;
    public static final int LABEL_BG      = 0x000200;
    public static final int CIRCLE        = 0x000400;
    public static final int SQUARE        = 0x000800;
    public static final int TRIANGLE      = 0x001000;
    public static final int CROSS         = 0x002000;
    public static final int PURE_MARK     = CIRCLE|SQUARE|TRIANGLE|LABEL|CROSS;
    public static final int SELECTED      = 0x010000;	// SL
    public static final int DIMMED        = 0x020000;	// DD
    public static final int VIEW          = 0x040000;	// VW
    public static final int C_CELL        = 0x100000;
    public static final int N_CELL        = 0x200000;
    public static final int NE_CELL       = 0x300000;
    public static final int E_CELL        = 0x400000;
    public static final int SE_CELL       = 0x500000;
    public static final int S_CELL        = 0x600000;
    public static final int SW_CELL       = 0x700000;
    public static final int W_CELL        = 0x800000;
    public static final int NW_CELL       = 0x900000;
    public static final int CELL          = HOSHI|C_CELL|N_CELL|NE_CELL|E_CELL|SE_CELL|S_CELL|SW_CELL|W_CELL|NW_CELL;
    public static final int OVER_CELL	  = DIMMED;		// tiles drawn over whole cell
    public static final int SOLID		  = CELL|STONE|HINT|TER|SELECTED|VARIANT;

    public int bits;
    public String label;

    public final void set(WIT wit) {
        bits = wit.bits;
        label = wit.label;
    }
    public final boolean sameStone(WIT wit) {
        return (bits & STONE) == (wit.bits & STONE);
    }
    public final boolean sameLabel(WIT wit) {
        return (bits & LABEL) == (wit.bits & LABEL)
            && (label == wit.label || (label != null && wit.label != null && label.equals(wit.label)));
    }
    public final void setStone(boolean black) {
        bits |= black ? BLACK_STONE : WHITE_STONE;
    }
    public final void setLabel(String label) {
        this.bits |= LABEL;
        this.label = label;
    }
    public void setCell(int x, int y, int boardSize) {
        int cellType = 0;
        if (x == 0) {
            if (y == 0)
                cellType = WIT.NW_CELL;
            else if (y == boardSize - 1)
                cellType = WIT.SW_CELL;
            else
                cellType = WIT.W_CELL;
        } else if (x == boardSize - 1) {
            if (y == 0)
                cellType = WIT.NE_CELL;
            else if (y == boardSize - 1)
                cellType = WIT.SE_CELL;
            else
                cellType = WIT.E_CELL;
        } else {
            if (y == 0)
                cellType = WIT.N_CELL;
            else if (y == boardSize - 1)
                cellType = WIT.S_CELL;
            else
                cellType = WIT.C_CELL;
        }
        bits &= ~CELL;
        bits |= cellType;
    }
    public final void addMark(int mark) {
        bits |= mark;
    }
    public final void clear(int mask) {
        bits &= mask;
        label = null;
    }
    public final boolean equals(Object obj) {
        WIT wit = (WIT) obj;
        return bits == wit.bits && (label == wit.label || label != null && wit.label != null && label.equals(wit.label));
    }
}

