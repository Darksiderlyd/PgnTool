/**
 * TinyGo is a MIDlet to play and review Go board games.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, 
 * MA 02110-1301, USA.
 */
package com.tinygo;

import com.tinygo.pdb.ProblemEnumeration;

/**
 * @author Alexey Klimkin
 *
 */
interface MenuScreenListener {

    void mainMenuDone();

    void mainMenuExit();

    void mainMenuNewGame(String white, String black,
            String ruleSet, int size, int handicap, float komi,
            int timeSystem, long mainTime, long byoYomiTime, int byoYomiAttr);

    void mainMenuLoad(String path);

    void mainMenuLoadProblem(String path);

    void mainMenuSave(String path);

    void mainMenuSolveProblems(ProblemEnumeration e);

    void mainMenuInvalidateProblems();

    void igMenuPass();

    void igMenuFreePlay();

    void igMenuScore();

    void igMenuRestartProblem();

    void igMenuNextProblem();

    void igMenuPrevProblem();

    void optPlayModeSettings(boolean showMoveStatus, boolean showColorToPlayIndicator,
            boolean showTimer,
            int commentLines);

    void optProbModeSettings(boolean showMoveStatus, boolean showColorToPlayIndicator,
            boolean showSolvedFailedIndicator, boolean showFailedImmediately,
            int commentLines);

    void optGeneralSettings(boolean sound, int commentFontSize);
}
