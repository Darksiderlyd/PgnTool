/**
 * TinyGo is a MIDlet to play and review Go board games.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 */
package com.tinygo;

import java.io.IOException;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.TimeZone;
import java.util.Timer;
import java.util.TimerTask;

import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.Item;
import javax.microedition.lcdui.StringItem;

import com.sgfj.SGFException;
import com.sgfj.SGFNode;
import com.sgfj.SGFProperty;
import com.sgfj.SGFPropertyName;
import com.sgfj.SGFWriter;
import com.tinygo.logic.DocumentedGame;
import com.tinygo.logic.Score;
import com.tinygo.logic.TimeSystem;
import com.tinygo.pdb.Problem;
import com.tinygo.pdb.ProblemEnumeration;
import com.tinyutil.T;


/**
 * @author Alexey Klimkin
 *
 */
class StatusScreen extends Form implements CommandListener {

    private Command backCommand = new Command(T._("Back"), Command.BACK, 2);
    private Command infoCommand = new Command(T._("Info"), Command.SCREEN, 3);
    private Command nodeCommand = new Command(T._("Node Properties"), Command.SCREEN, 4);
    private Command srcCommand  = new Command(T._("Source"), Command.SCREEN, 5);

    private StringItem whitePlayerName = new StringItem(null, null);
    private StringItem blackPlayerName = new StringItem(null, null);
    private StringItem whiteCaps = new StringItem(null, null);
    private StringItem blackCaps = new StringItem(null, null);
    private StringItem whiteTime = new StringItem(null, null);
    private StringItem blackTime = new StringItem(null, null);
    private StringItem moveStatus = new StringItem(null, null);
    private StringItem comment = new StringItem(null, null);

    private boolean probEnabled = false;
    //private StringItem probName = new StringItem(null, null);
    //private StringItem probSource;
    private StringItem probGenre = new StringItem(null, null);
    private StringItem probStatus = new StringItem(null, null);

    private Display display;
    private StatusScreenListener listener;
    private DocumentedGame game;
    private TimeSystem timeSystem;

    private boolean extern = false;

    private TimerTask task = new TimerTask() {
        public void run() {
            if (isShown())
                updateClocks();
        }
    };

    public StatusScreen(Display display, Timer timer, TimeSystem timeSystem) {
        super(T._("Game"));
        this.display = display;
        this.timeSystem = timeSystem;
        timer.schedule(task, 0, 1000);

        addCommand(backCommand);
        addCommand(infoCommand);
        addCommand(nodeCommand);
        addCommand(srcCommand);
        setCommandListener(this);

        whitePlayerName.setFont(fontPlain());
        whitePlayerName.setLayout(Item.LAYOUT_2 | Item.LAYOUT_EXPAND | Item.LAYOUT_LEFT);
        whiteCaps.setFont(fontBoldMono());
        whiteCaps.setLayout(Item.LAYOUT_2 | Item.LAYOUT_SHRINK);
        whiteTime.setFont(fontPlain());
        whiteTime.setLayout(Item.LAYOUT_2 | Item.LAYOUT_SHRINK | Item.LAYOUT_NEWLINE_AFTER);

        blackPlayerName.setFont(fontPlain());
        blackPlayerName.setLayout(Item.LAYOUT_2 | Item.LAYOUT_EXPAND);
        blackCaps.setFont(fontBoldMono());
        blackCaps.setLayout(Item.LAYOUT_2 | Item.LAYOUT_SHRINK);
        blackTime.setFont(fontPlain());
        blackTime.setLayout(Item.LAYOUT_2 | Item.LAYOUT_SHRINK | Item.LAYOUT_NEWLINE_AFTER);

        moveStatus.setFont(fontBold());
        moveStatus.setLayout(Item.LAYOUT_2 | Item.LAYOUT_SHRINK | Item.LAYOUT_NEWLINE_BEFORE | Item.LAYOUT_NEWLINE_AFTER | Item.LAYOUT_CENTER);
        comment.setFont(fontPlain());
        comment.setLayout(Item.LAYOUT_2 | Item.LAYOUT_EXPAND | Item.LAYOUT_VEXPAND | Item.LAYOUT_NEWLINE_BEFORE | Item.LAYOUT_NEWLINE_AFTER);

        //probName.setFont(fontPlain());
        //probName.setLayout(Item.LAYOUT_2 | Item.LAYOUT_SHRINK | Item.LAYOUT_NEWLINE_BEFORE | Item.LAYOUT_NEWLINE_AFTER | Item.LAYOUT_CENTER);
        probGenre.setFont(fontPlain());
        probGenre.setLayout(Item.LAYOUT_2 | Item.LAYOUT_SHRINK | Item.LAYOUT_NEWLINE_BEFORE | Item.LAYOUT_NEWLINE_AFTER | Item.LAYOUT_CENTER);
        probStatus.setFont(fontBold());
        probStatus.setLayout(Item.LAYOUT_2 | Item.LAYOUT_SHRINK | Item.LAYOUT_NEWLINE_BEFORE | Item.LAYOUT_NEWLINE_AFTER | Item.LAYOUT_CENTER);

        append(whitePlayerName);
        append(whiteCaps);
        append(whiteTime);
        append(blackPlayerName);
        append(blackCaps);
        append(blackTime);
        append(moveStatus);
        append(comment);
    }

    public void setListener(StatusScreenListener listener) {
        this.listener = listener;
    }

    private final static Font fontPlain() {
        return Font.getFont(Font.FACE_PROPORTIONAL, Font.STYLE_PLAIN, Font.SIZE_SMALL);
    }

    private final static Font fontBold() {
        return Font.getFont(Font.FACE_PROPORTIONAL, Font.STYLE_BOLD, Font.SIZE_SMALL);
    }

    private final static Font fontBoldMono() {
        return Font.getFont(Font.FACE_MONOSPACE, Font.STYLE_BOLD, Font.SIZE_SMALL);
    }

    private void updateClocks() {
        Calendar c = Calendar.getInstance(TimeZone.getDefault());
        int h = c.get(Calendar.HOUR_OF_DAY);
        int m = c.get(Calendar.MINUTE);
        int s = c.get(Calendar.SECOND);
        setTitle("" + h + ":" + (m < 10 ? "0" + m : "" + m) + ":" + (s < 10 ? "0" + s : "" + s));

        whiteTime.setText(timeSystem.timeLeftText(false));
        blackTime.setText(timeSystem.timeLeftText(true));
    }

    public void setGame(DocumentedGame game) {
        this.game = game;

        SGFNode root = game.kifuHead();

        String s;
        try {
            s = root.getProperty(SGFPropertyName.PW).getText();
            try {
                s += " [" + root.getProperty(SGFPropertyName.WR).getText() + "]";
            } catch (SGFException e) {
            }
        } catch (SGFException e) {
            s = T._("White");
        }
        whitePlayerName.setText("W: " + s);

        try {
            s = root.getProperty(SGFPropertyName.PB).getText();
            try {
                s += " [" + root.getProperty(SGFPropertyName.BR).getText() + "]";
            } catch (SGFException e) {
            }
        } catch (SGFException e) {
            s = T._("Black");
        }
        blackPlayerName.setText("B: " + s);
    }

    public void setProblem(Problem problem, ProblemEnumeration problemEnum) {
        if (problem != null) {
            SGFNode root = game.kifuHead();
            String name, diff;
            try {
                name = root.getProperty(SGFPropertyName.GN).getText();
            } catch (SGFException e) {
                name = "??";
            }
            try {
                diff = root.getProperty(SGFPropertyName.DI).getText();
            } catch (SGFException e) {
                diff = "??";
            }
            int enSize = problemEnum.size();
            int enCurr = problemEnum.current();
            //probName.setText(problem.filePath() + ": " + name);
            //probName.setText(name);
            probGenre.setText(name + ": " + problem.genre + " " + diff + " [" + problem.popularity + "]");
            probStatus.setText(T._("Ratio: ") + problem.solved + '/' + problem.tried + T._("  Set: ") + (enCurr + 1) + '/' + enSize);
        }

        if (probEnabled) {
            if (problem == null) {
                probEnabled = false;
                deleteAll();
                append(whitePlayerName);
                append(whiteCaps);
                append(whiteTime);
                append(blackPlayerName);
                append(blackCaps);
                append(blackTime);
                append(moveStatus);
                append(comment);
            }
        } else {
            if (problem != null) {
                probEnabled = true;
                deleteAll();
                //append(probName);
                append(probGenre);
                append(probStatus);
                append(comment);
            }
        }
    }

    private void notifyGameUpdated() {
        SGFNode node = game.kifuLastMove();

        whiteCaps.setText(Integer.toString(game.whiteCaptures));
        blackCaps.setText(Integer.toString(game.blackCaptures));
        moveStatus.setText(game.getFullMoveStatusText());

        String s;
        try {
            s = node.getCommentProperty();
        } catch (SGFException e) {
            s = "";
        }
        comment.setText(s);
    }

    public void commandAction(Command c, Displayable d) {
        if (c == backCommand) {
            if (d == this || extern) {
                extern = false;
                listener.statusScreenCancelled();
            } else
                display.setCurrent(this);
        } else if (c == infoCommand)
                displayInfo();
        else if (c == nodeCommand)
            displayNodeProperties();
        else if (c == srcCommand)
            displaySource();
    }

    public void displayStatus() {
        notifyGameUpdated();
        updateClocks();
        display.setCurrent(this);
    }

    public void displayScore(Score score) {
        Form f = new Form(score.scoreText);
        f.addCommand(backCommand);
        f.setCommandListener(this);

        StringItem item;

        item = new StringItem(null, "Rules: Japanese");
        item.setFont(fontPlain());
        item.setLayout(Item.LAYOUT_2 | Item.LAYOUT_CENTER | Item.LAYOUT_NEWLINE_BEFORE | Item.LAYOUT_NEWLINE_AFTER);
        f.append(item);

        // ----------------------------------------------------------------------------
        item = new StringItem(null, T._("White"));
        item.setFont(fontPlain());
        item.setLayout(Item.LAYOUT_2 | Item.LAYOUT_EXPAND | Item.LAYOUT_NEWLINE_BEFORE);
        f.append(item);

        item = new StringItem(null, T._("Black"));
        item.setFont(fontPlain());
        item.setLayout(Item.LAYOUT_2 | Item.LAYOUT_SHRINK | Item.LAYOUT_NEWLINE_AFTER);
        f.append(item);

        // ----------------------------------------------------------------------------
        item = new StringItem(null, T._("Territory"));
        item.setFont(fontPlain());
        item.setLayout(Item.LAYOUT_2 | Item.LAYOUT_CENTER | Item.LAYOUT_NEWLINE_BEFORE | Item.LAYOUT_NEWLINE_AFTER);
        f.append(item);

        item = new StringItem(null, String.valueOf(score.wTerr));
        item.setFont(fontPlain());
        item.setLayout(Item.LAYOUT_2 | Item.LAYOUT_EXPAND | Item.LAYOUT_NEWLINE_BEFORE);
        f.append(item);

        item = new StringItem(null, String.valueOf(score.bTerr));
        item.setFont(fontPlain());
        item.setLayout(Item.LAYOUT_2 | Item.LAYOUT_SHRINK | Item.LAYOUT_NEWLINE_AFTER);
        f.append(item);

        // ----------------------------------------------------------------------------
        item = new StringItem(null, T._("Captured"));
        item.setFont(fontPlain());
        item.setLayout(Item.LAYOUT_2 | Item.LAYOUT_CENTER | Item.LAYOUT_NEWLINE_BEFORE | Item.LAYOUT_NEWLINE_AFTER);
        f.append(item);

        item = new StringItem(null, String.valueOf(-score.wCaptured));
        item.setFont(fontPlain());
        item.setLayout(Item.LAYOUT_2 | Item.LAYOUT_EXPAND | Item.LAYOUT_NEWLINE_BEFORE);
        f.append(item);

        item = new StringItem(null, String.valueOf(-score.bCaptured));
        item.setFont(fontPlain());
        item.setLayout(Item.LAYOUT_2 | Item.LAYOUT_SHRINK | Item.LAYOUT_NEWLINE_AFTER);
        f.append(item);

        // ----------------------------------------------------------------------------
        item = new StringItem(null, T._("Dead"));
        item.setFont(fontPlain());
        item.setLayout(Item.LAYOUT_2 | Item.LAYOUT_CENTER | Item.LAYOUT_NEWLINE_BEFORE | Item.LAYOUT_NEWLINE_AFTER);
        f.append(item);

        item = new StringItem(null, String.valueOf(-score.wDead));
        item.setFont(fontPlain());
        item.setLayout(Item.LAYOUT_2 | Item.LAYOUT_EXPAND | Item.LAYOUT_NEWLINE_BEFORE);
        f.append(item);

        item = new StringItem(null, String.valueOf(-score.bDead));
        item.setFont(fontPlain());
        item.setLayout(Item.LAYOUT_2 | Item.LAYOUT_SHRINK | Item.LAYOUT_NEWLINE_AFTER);
        f.append(item);

        // ----------------------------------------------------------------------------
        item = new StringItem(null, T._("Komi"));
        item.setFont(fontPlain());
        item.setLayout(Item.LAYOUT_2 | Item.LAYOUT_CENTER | Item.LAYOUT_NEWLINE_BEFORE | Item.LAYOUT_NEWLINE_AFTER);
        f.append(item);

        item = new StringItem(null, String.valueOf(score.komi));
        item.setFont(fontPlain());
        item.setLayout(Item.LAYOUT_2 | Item.LAYOUT_EXPAND | Item.LAYOUT_NEWLINE_BEFORE);
        f.append(item);

        // ----------------------------------------------------------------------------
        item = new StringItem(null, "=");
        item.setFont(fontPlain());
        item.setLayout(Item.LAYOUT_2 | Item.LAYOUT_CENTER | Item.LAYOUT_NEWLINE_BEFORE | Item.LAYOUT_NEWLINE_AFTER);
        f.append(item);

        item = new StringItem(null, String.valueOf(score.wScore));
        item.setFont(fontPlain());
        item.setLayout(Item.LAYOUT_2 | Item.LAYOUT_EXPAND | Item.LAYOUT_NEWLINE_BEFORE);
        f.append(item);

        item = new StringItem(null, String.valueOf(score.bScore));
        item.setFont(fontPlain());
        item.setLayout(Item.LAYOUT_2 | Item.LAYOUT_SHRINK | Item.LAYOUT_NEWLINE_AFTER);
        f.append(item);

        // ----------------------------------------------------------------------------
        item = new StringItem(null, score.scoreText);
        item.setFont(fontBold());
        item.setLayout(Item.LAYOUT_2 | Item.LAYOUT_CENTER | Item.LAYOUT_NEWLINE_BEFORE | Item.LAYOUT_NEWLINE_AFTER);
        f.append(item);

        extern = true;
        display.setCurrent(f);
    }

    private void displayNodeProperties() {
        Form sgfPropsForm = new Form(T._("Node properties"));
        StringItem sgfNodeProps = new StringItem(T._("Node"), null);
        StringItem sgfRootProps = new StringItem(T._("Root"), null);

        sgfPropsForm.addCommand(backCommand);
        sgfPropsForm.setCommandListener(this);

        sgfNodeProps.setFont(fontPlain());
        sgfNodeProps.setLayout(Item.LAYOUT_2 | Item.LAYOUT_EXPAND | Item.LAYOUT_NEWLINE_BEFORE | Item.LAYOUT_NEWLINE_AFTER);
        sgfPropsForm.append(sgfNodeProps);
        sgfRootProps.setFont(fontPlain());
        sgfRootProps.setLayout(Item.LAYOUT_2 | Item.LAYOUT_EXPAND | Item.LAYOUT_NEWLINE_BEFORE | Item.LAYOUT_NEWLINE_AFTER);
        sgfPropsForm.append(sgfRootProps);

        SGFNode root = game.kifuHead();
        SGFNode node = game.kifuLastMove();

        StringBuffer sb = new StringBuffer();
        for (Enumeration e = root.getProperties(); e.hasMoreElements(); ) {
            SGFProperty p = (SGFProperty) e.nextElement();
            sb.append(p.toString());
            sb.append("\n");
        }
        sgfRootProps.setText(sb.toString());

        sb.setLength(0);
        if (node != root)
            for (Enumeration e = node.getProperties(); e.hasMoreElements(); ) {
                SGFProperty p = (SGFProperty) e.nextElement();
                sb.append(p.toString());
                sb.append("\n");
            }
        sgfNodeProps.setText(sb.toString());

        display.setCurrent(sgfPropsForm);
    }

    private void displaySource() {
        Form srcForm = new Form(T._("Source"));
        StringItem srcText = new StringItem(null, null);

        srcForm.addCommand(backCommand);
        srcForm.setCommandListener(this);

        srcText.setFont(fontPlain());
        srcForm.append(srcText);

        SGFNode root = game.kifuHead();
        try {
            srcText.setText(SGFWriter.toString(root));
        } catch (IOException e) {
            srcText.setText(e.getMessage());
        }

        display.setCurrent(srcForm);
    }

    private void displayInfo() {
        Form infoForm = new Form(T._("Info"));
        StringItem infoText = new StringItem(null, null);

        infoForm.addCommand(backCommand);
        infoForm.setCommandListener(this);

        infoText.setFont(fontPlain());
        infoForm.append(infoText);

        StringBuffer sb = new StringBuffer();

        SGFNode root = game.kifuHead();

        for (Enumeration e = root.getProperties(); e.hasMoreElements(); ) {
            SGFProperty p = (SGFProperty) e.nextElement();
            // skip point and comment properties in this screen
            if (!p.name().hasPoint() && p.name() != SGFPropertyName.C) {
                sb.append(p.toString());
                sb.append("\n");
            }
        }

        infoText.setText(sb.toString());

        display.setCurrent(infoForm);
    }
}
