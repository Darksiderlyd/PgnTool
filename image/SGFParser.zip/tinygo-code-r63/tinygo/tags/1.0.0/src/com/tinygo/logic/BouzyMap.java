/**
 * TinyGo is a MIDlet to play and review Go board games.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, 
 * MA 02110-1301, USA.
 */
package com.tinygo.logic;

/**
 * Bouzy map is used to evaluate moyo on the board. Delation = 5 and erosion = 21
 * seems to be standard.
 * 
 * @author Alexey Klimkin
 */
public class BouzyMap implements TerritoryEvaluator {

	private int[][] data;
	private int size = -1;
	
	/**
	 * Create empty Bousy map. The map should be initialized with setup later. 
	 */
	public BouzyMap() {
	}
	
	/**
     * Create Bousy map and setup with specified board.
	 * @param board    stone configuration used for setup
	 */
	public BouzyMap(Board board) {
		setup(board);
	}
	
	/**
     * Setup Bousy map values. Bousy algorithm implies, that initial value for
     * white is -128, for black is 128, 0 if no stone present.
     * Setup als checks board bits for Board.M_CAPTURED and treats such 
     * stones as not present.
     * @param board     stones and bits configuration
	 */
	public void setup(Board board) {
		if (size != board.size()) {
			size = board.size();
			data = new int[size][size];
		}
		for (int x = 0; x < size; x++)
			for (int y = 0; y < size; y++)
				if (board.isBit(board.pos(x, y), Board.M_CAPTURED))
					data[x][y] = 0;
				else
					switch (board.get(x, y)) {
						case Board.WHITE:
							data[x][y] = -128;
							break;
						case Board.BLACK:
							data[x][y] = 128;
							break;
						default:
							data[x][y] = 0;
					}
	}
	
	/**
     * Get Bousy map value for specified point.
	 * @param x    X coordinate
	 * @param y    Y coordinate
	 * @return     Bousy map value
	 */
	public final int get(int x, int y) {
		return data[x][y];
	}
    
	/**
     * Get Bousy map value for specified point.
	 * @param pos  coordinate in linear presentation
	 * @return     Bousy map value
	 */
	public final int get(int pos) {
		return get(pos % size, pos / size);
	}
	
	/**
	 * Evaluate Bousy map using 5 delations and 21 erosions.
	 */
	public final void eval() {
		eval(5, 21);
	}
	
	/**
     * Evaluate Bousy map.
	 * @param delate   number of delations
	 * @param erode    number of erosions
	 */
	public void eval(int delate, int erode) {
		int[][] buffer = new int[size][size];
		while (delate-- > 0) {
			for (int x = 0; x < size; x++)
				for (int y = 0; y < size; y++) {
					int w = 0;
					int b = 0;

					if (x > 0)
						if (data[x - 1][y] > 0)
							b++;
						else if (data[x - 1][y] < 0)
							w++;
					if (x < size - 1)
						if (data[x + 1][y] > 0)
							b++;
						else if (data[x + 1][y] < 0)
							w++;
					if (y > 0)
						if (data[x][y - 1] > 0)
							b++;
						else if (data[x][y - 1] < 0)
							w++;
					if (y < size - 1)
						if (data[x][y + 1] > 0)
							b++;
						else if (data[x][y + 1] < 0)
							w++;

					if (w == 0 && data[x][y] >= 0)
						buffer[x][y] += b;
					else if (b == 0 && data[x][y] <= 0)
						buffer[x][y] -= w;
				}
			for (int x = 0; x < size; x++)
				for (int y = 0; y < size; y++) {
					data[x][y] += buffer[x][y];
					buffer[x][y] = 0;
				}
		}
		
		while (erode-- > 0) {
			for (int x = 0; x < size; x++)
				for (int y = 0; y < size; y++) {
					int w = 0;
					int b = 0;

					if (x > 0) {
						if (data[x - 1][y] >= 0)
							b++;
						if (data[x - 1][y] <= 0)
							w++;
					}
					if (x < size - 1) {
						if (data[x + 1][y] >= 0)
							b++;
						if (data[x + 1][y] <= 0)
							w++;
					}
					if (y > 0) {
						if (data[x][y - 1] >= 0)
							b++;
						if (data[x][y - 1] <= 0)
							w++;
					}
					if (y < size - 1) {
						if (data[x][y + 1] >= 0)
							b++;
						if (data[x][y + 1] <= 0)
							w++;
					}

					if (data[x][y] > 0)
						buffer[x][y] -= w;
					else if (data[x][y] < 0)
						buffer[x][y] += b;
				}
			for (int x = 0; x < size; x++)
				for (int y = 0; y < size; y++) {
					int newVal = data[x][y] + buffer[x][y];
					if (data[x][y] > 0)
						data[x][y] = Math.max(newVal, 0);
					else if (data[x][y] < 0)
						data[x][y] = Math.min(newVal, 0);
					buffer[x][y] = 0;
				}
		}
	}
}
