/**
 * TinyGo is a MIDlet to play and review Go board games.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 */
package com.tinygo.gam;

import java.io.InputStream;

import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Display;
import javax.microedition.media.Manager;
import javax.microedition.media.MediaException;
import javax.microedition.media.Player;

/**
 * @author Alexey Klimkin
 *
 */
public class SoundPlayer {

    private Display display;

    public boolean on = true;

    public SoundPlayer(Display display) {
        this.display = display;
    }

    private void playSoundFile(String file) {
        try {
            InputStream is = getClass().getResourceAsStream(file);
            Player p = Manager.createPlayer(is, "audio/x-wav");
            p.start();
        } catch (Exception e) {
            //#ifdef debug
            Alert a = new Alert("Exception", e.toString(), null, AlertType.INFO);
            a.setTimeout(Alert.FOREVER);
            display.setCurrent(a);
            //#endif
        }
    }

    public void playStoneSound(boolean black) {
        if (!on)
            return;
        playSoundFile(black ? "/snd/stoneb.wav" : "/snd/stonew.wav");
    }

    public void playCaptSound(boolean black) {
        if (!on)
            return;
        display.vibrate(500);
    }

    public void playIllegalMoveSound() {
        if (!on)
            return;
        AlertType.WARNING.playSound(display);
    }

    public void playPassSound() {
        if (!on)
            return;
        playSoundFile("/snd/pass.wav");
    }

    public void playShortOnTime() {
        if (!on)
            return;
        try {
            Manager.playTone(69, 20, 100);
        } catch (MediaException e) {
        }
    }

    public void playProblemSolved() {
        if (!on)
            return;
        AlertType.CONFIRMATION.playSound(display);
    }

    public void playProblemFailed() {
        if (!on)
            return;
        AlertType.ERROR.playSound(display);
    }

}
