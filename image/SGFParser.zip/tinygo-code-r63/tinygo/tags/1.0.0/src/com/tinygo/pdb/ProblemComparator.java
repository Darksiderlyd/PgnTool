/**
 * TinyGo is a MIDlet to play and review Go board games.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, 
 * MA 02110-1301, USA.
 */
package com.tinygo.pdb;

import java.util.Vector;

import com.tinyutil.Comparator;

/**
 * @author Alexey Klimkin
 *
 */
class ProblemComparator implements Comparator {
    Filter f;
    Vector problems;
    
    ProblemComparator(Vector problems, Filter f) {
        this.problems = problems;
        this.f = f;
    }
    
    public int compare(Object o1, Object o2) {
        Problem p1 = (Problem)problems.elementAt(((Integer)o1).intValue());
        Problem p2 = (Problem)problems.elementAt(((Integer)o2).intValue());
        int result;
        if (p1.genre == null) {
            if (p2.genre == null)
                result = 0;
            else
                result = -1;
        } else {
            if (p2.genre == null)
                result = 1;
            else
                result = p1.genre.compareTo(p2.genre);
        }
        result = result * f.sortByGenre;
        if (result == 0)
            // more - more popular
            result = (p1.popularity - p2.popularity) * f.sortByPopularity;
        if (result == 0)
            // less - more difficult
            result = (p2.difficultyP - p1.difficultyP) * f.sortByDifficulty;
        
        return result;
    }
}
