/**
 * TinyGo is a MIDlet to play and review Go board games.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, 
 * MA 02110-1301, USA.
 */
package com.tinygo.logic;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

/**
 * @author Alexey Klimkin
 *
 */
public class TimeSystem {
    public final static int NONE     = 0;
    public final static int ABSOLUTE = 1;
    public final static int BYOYOMI  = 2;
    public final static int CANADIAN = 3;
    
    private final static int BLACK = 0;
    private final static int WHITE = 1;
    
    public int type;
    public long mainTime;
    public long byoYomiTime;
    public int byoYomiAttr;

    private long[] mainTimeC = new long[2];
    private long[] byoYomiTimeC = new long[2];
    private int[] byoYomiAttrC = new int[2];
    private int active;
    private long lastTickTime;
    
    private Timer timer;
    private TimerTask task = null;
    private TimeSystemListener listener;
    
    public TimeSystem(Timer timer) {
        this.timer = timer;
    }
    
    public void setListener(TimeSystemListener listener) {
        this.listener = listener; 
    }
    
    public void init(int type) {
        stop();
        this.type = type;
    }
    public void init(int type, long mainTime) {
        init(type);
        this.mainTime = mainTime;
    }
    public void init(int type, long mainTime, long byoYomiTime, int byoYomiAttr) {
        init(type, mainTime);
        this.byoYomiTime = byoYomiTime;
        this.byoYomiAttr = byoYomiAttr;
    }
    
    public void start(boolean isBlack) {
        active = isBlack ? BLACK : WHITE;
        if (type != NONE) {
            mainTimeC[0] = mainTimeC[1] = mainTime;
            byoYomiTimeC[0] = byoYomiTimeC[1] = byoYomiTime;
            byoYomiAttrC[0] = byoYomiAttrC[1] = byoYomiAttr;
            task = new TimerTask() {
                public void run() {
                    update();
                }
            };
            lastTickTime = System.currentTimeMillis();
            timer.schedule(task, 0, 1000);
        }
    }
    
    public void stop() {
        if (task != null) {
            task.cancel();
            task = null;
        }
    }
    
    public void pause() {
        stop();
    }
    
    public void resume() {
        if (type != NONE && task == null) {
            task = new TimerTask() {
                public void run() {
                    update();
                }
            };
            lastTickTime = System.currentTimeMillis();
            timer.schedule(task, 0, 1000);
        }
    }
    
    private boolean update() {
        long diff = System.currentTimeMillis() - lastTickTime;
        lastTickTime = System.currentTimeMillis();
        boolean timeout = false;
        int shortOnTime = 0; // TODO: Implement "short on time" notification
        
        switch (type) {
            case ABSOLUTE:
                mainTimeC[active] -= diff;
                if (mainTimeC[active] <= 0) {
                    mainTimeC[active] = 0;
                    timeout = true;
                }
                break;
            case BYOYOMI:
                if (mainTimeC[active] > 0) {
                    mainTimeC[active] -= diff;
                    if (mainTimeC[active] <= 0) {
                        diff = -mainTimeC[active];
                        mainTimeC[active] = 0;
                    }
                }
                if (mainTimeC[active] == 0) {
                    byoYomiTimeC[active] -= diff;
                    while (byoYomiTimeC[active] <= 0 && byoYomiAttrC[active] > 0) {
                        byoYomiTimeC[active] += byoYomiTime;
                        byoYomiAttrC[active]--;
                    }
                    if (byoYomiTimeC[active] <= 0 && byoYomiAttrC[active] == 0) {
                        byoYomiTimeC[active] = 0;
                        timeout = true;
                    }
                }
                break;
            case CANADIAN:
                if (mainTimeC[active] > 0) {
                    mainTimeC[active] -= diff;
                    if (mainTimeC[active] <= 0) {
                        diff = -mainTimeC[active];
                        mainTimeC[active] = 0;
                    }
                }
                if (mainTimeC[active] == 0) {
                    byoYomiTimeC[active] -= diff;
                    if (byoYomiTimeC[active] <= 0) {
                        byoYomiTimeC[active] = 0;
                        timeout = true;
                    }
                }
                break;
        }
        
        if (timeout) {
            pause();
            listener.timeSystemTimeout(active == BLACK);
        } else if (shortOnTime > 0)
            listener.timeSystemShortOnTime(active == BLACK, shortOnTime);
        return timeout;
    }
    
    public void turn() {
        if (task == null)
            return;
        pause();
        if (update()) // true if timeout
            return;
        
        if (mainTimeC[active] == 0) {
            switch (type) {
                case BYOYOMI:
                    byoYomiTimeC[active] = byoYomiTime;
                    break;
                case CANADIAN:
                    if (mainTimeC[active] == 0) {
                        byoYomiAttrC[active]--;
                        if (byoYomiAttrC[active] == 0) {
                            byoYomiTimeC[active] = byoYomiTime;
                            byoYomiAttrC[active] = byoYomiAttr;
                        }
                        break;
                    }
            }
        }
        
        active = active == BLACK ? WHITE : BLACK;
        resume();
    }
    
    public static String formatTime(long millis) {
        millis /= 1000;
        long s = millis % 60;
        long m = (millis / 60) % 60;
        long h = millis / 3600;
        return "" + h + ":" + (m < 10 ? "0" + m : "" + m) + ":" + (s < 10 ? "0" + s : "" + s);
    }
    
    public String timeLeftText(boolean black) {
        String txt;
        if (type == NONE)
            txt = "-";
        else {
            int act = black ? BLACK : WHITE;
            long t = mainTimeC[act];
            if (type == ABSOLUTE || t >= 1000) {
                txt = formatTime(t);
            } else { // show Byo-Yomi time, 
                txt = formatTime(byoYomiTimeC[act]);
                if (type == BYOYOMI)
                    txt += "(" + byoYomiAttrC[act] + ")";
                else if (type == CANADIAN)
                    txt += "/" + byoYomiAttrC[act];
            }
        }
        return txt;
    }
    
    public boolean isBlackTurn() {
        return active == BLACK;
    }
    
    public boolean isInByoYomi(boolean black) {
        return (type == BYOYOMI || type == CANADIAN) && mainTimeC[black ? BLACK : WHITE] == 0;
    }

    public void save(DataOutputStream dout) throws IOException {
        dout.writeByte(type);
        dout.writeLong(mainTime);
        dout.writeLong(byoYomiTime);
        dout.writeInt(byoYomiAttr);
        
        for (int i = 0; i < 2; i++) {
            dout.writeLong(mainTimeC[i]);
            dout.writeLong(byoYomiTimeC[i]);
            dout.writeInt(byoYomiAttrC[i]);
        }
        
        dout.writeByte(active);
        dout.writeBoolean(task != null);
    }
    
    public void restore(DataInputStream din) throws IOException {
        type = din.readByte();
        mainTime = din.readLong();
        byoYomiTime = din.readLong();
        byoYomiAttr = din.readInt();
        
        for (int i = 0; i < 2; i++) {
            mainTimeC[i] = din.readLong();
            byoYomiTimeC[i] = din.readLong();
            byoYomiAttrC[i] = din.readInt();
        }
        
        active = din.readByte();
        if (din.readBoolean())
            resume();
    }
}
