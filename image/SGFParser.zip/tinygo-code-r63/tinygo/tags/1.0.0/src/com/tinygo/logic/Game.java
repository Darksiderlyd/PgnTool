/**
 * TinyGo is a MIDlet to play and review Go board games.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, 
 * MA 02110-1301, USA.
 */
package com.tinygo.logic;

import java.util.Stack;
import java.util.Vector;

import com.sgfj.SGFPoint;

final class MoveHints {

    Vector addedStones = new Vector();
    Vector removedBStones = new Vector();
    Vector removedWStones = new Vector();

    int moveNumber;
    int lastMove;
    int koMove;
    byte colorToPlay;
    int whiteCaptures;
    int blackCaptures;

/*    private static int[] v2ar(Vector v) {
        int[] ar;
        if (v != null && v.size() > 0) {
            ar = new int[v.size()];
            for (int i = 0; i < v.size(); i++)
                ar[i] = ((Integer)v.elementAt(i)).intValue();
        } else
            ar = null;
        return ar;
    }*/

    MoveHints(int moveNumber, byte colorToPlay, int lastMove, int koMove,
            int whiteCaptures, int blackCaptures) {
        this.moveNumber = moveNumber;
        this.colorToPlay = colorToPlay;
        this.lastMove = lastMove;
        this.koMove = koMove;
        this.whiteCaptures = whiteCaptures;
        this.blackCaptures = blackCaptures;
    }
}

/**
 * @author Alexey Klimkin
 *
 */
public class Game {

    private Stack history = null;

    public Board board = null;

    //GameTimer timer;
    public int moveNumber;
    public byte colorToPlay;
    public int lastMove;
    public int koMove;

    public int handicap;
    public int whiteCaptures;
    public int blackCaptures;

    // if we don't know hoshi points to autoplace ha stones, use black only moves
    protected int handicapMovesLeft;

    protected Game() {
        // should be used with init()
    }

    /**
     * Create new game.
     * @param size Board size.
     */
    public Game(int size) {
        init(size);
    }

    public void init(int size) {
        if (board == null)
            board = new Board(size);
        else
            board.setSize(size);

        if (history == null)
            history = new Stack();
        else
            history.setSize(0);

        koMove = lastMove = -1;
        whiteCaptures = blackCaptures = 0;
        moveNumber = 0;

        handicap = 0;
        colorToPlay = Board.BLACK;
    }

    public void setHandicap(int handicap) {
        this.handicap = handicap;
        if (handicap >= 2) {
            int[] hoshis = board.getHoshis();
            if (hoshis != null) {
                if ((handicap & 1) == 1) {
                    if (handicap == 3)
                        board.set(hoshis[Board.HOSHI_SE], Board.BLACK);
                    else
                        board.set(hoshis[Board.HOSHI_C], Board.BLACK);
                    handicap &= ~1;
                }
                switch (handicap) {
                    case 8:
                        board.set(hoshis[Board.HOSHI_N], Board.BLACK);
                        board.set(hoshis[Board.HOSHI_S], Board.BLACK);
                    case 6:
                        board.set(hoshis[Board.HOSHI_W], Board.BLACK);
                        board.set(hoshis[Board.HOSHI_E], Board.BLACK);
                    case 4:
                        board.set(hoshis[Board.HOSHI_NW], Board.BLACK);
                        board.set(hoshis[Board.HOSHI_SE], Board.BLACK);
                    case 2:
                        board.set(hoshis[Board.HOSHI_NE], Board.BLACK);
                        board.set(hoshis[Board.HOSHI_SW], Board.BLACK);
                }
                handicapMovesLeft = 0;
                colorToPlay = Board.WHITE;
            } else {
                handicapMovesLeft = handicap;
                colorToPlay = Board.BLACK;
            }
        }
    }

    private void collectDead(int pos, byte color, Group deadGroup) {
        if (pos >= 0 && board.get(pos) == color && !board.isBit(pos, Board.M_DEAD)) {
            int start = deadGroup.size;
            board.getGroup(pos, deadGroup);
            if (deadGroup.liberties > 0) {
                // not dead, exclude
                deadGroup.size = start;
                deadGroup.liberties = 0;
            } else
                for (int j = start; j < deadGroup.size; j++)
                    board.setBit(deadGroup.stones[j], Board.M_DEAD);
        }
    }

    /**
     * Play stone.
     * @param pos Stone position on the board.
     * @param color Stone color.
     * @throws GameException Illegal move.
     */
    protected void play(int pos, byte color, boolean allowIllegal) throws GameException {
        if (!allowIllegal) {
            if (board.get(pos) != Board.NONE) {
                SGFPoint p = board.xy(pos);
                throw new GameOverStoneException("Stone " + board.get(pos) + " already at " + p.x + "," + p.y);
            }
            if (pos == koMove)
                throw new GameKoMoveException();
            if (color != colorToPlay)
                throw new GameWrongHandException("Expected: " + colorToPlay + ", got: " + color);
            //System.out.println("Move expected: " + colorToPlay + ", got: " + color);
        }

        advance();

        set(pos, color);

        Group deadGroup = new Group(board.maxPos());
        byte otherColor = Board.other(color);

        // collect dead stones
        board.clearBits(Board.M_DEAD);
        collectDead(board.n(pos), otherColor, deadGroup);
        collectDead(board.e(pos), otherColor, deadGroup);
        collectDead(board.s(pos), otherColor, deadGroup);
        collectDead(board.w(pos), otherColor, deadGroup);

        if (deadGroup.size == 0) {
            // no deaders, check if suicide
            board.getGroup(pos, deadGroup);
            if (deadGroup.liberties == 0) {
                if (!allowIllegal) {
                    set(pos, Board.NONE);
                    history.pop();
                    SGFPoint p = board.xy(pos);
                    throw new GameSuicideMoveException(p.x + "," + p.y);
                } // else we remove suicidal group
            } else
                deadGroup.size = 0;
        }
        if (deadGroup.size > 0) {
            // remove dead stones
            for (int i = 0; i < deadGroup.size; i++)
                set(deadGroup.stones[i], Board.NONE);
            // update capture counters
            if (deadGroup.color == Board.WHITE)
                blackCaptures += deadGroup.size;
            else
                whiteCaptures += deadGroup.size;
        }

        // check if there is now ko move
        if (koMove >= 0)
            koMove = -1;
        else if (deadGroup.size == 1) {
            int koMoveCandidate = deadGroup.stones[0];
            deadGroup.clear();
            board.getGroup(pos, deadGroup);
            if (deadGroup.size == 1 && deadGroup.liberties == 1)
                koMove = koMoveCandidate;
        }

        // finally, change expected color, progress move number
        if (handicapMovesLeft > 0)
            handicapMovesLeft--;
        if (handicapMovesLeft == 0)
            colorToPlay = otherColor;
        moveNumber++;
        lastMove = pos;
    }

    public final void play(int pos) throws GameException {
        play(pos, colorToPlay, false);
    }

    public final void play(int x, int y) throws GameException {
        play(board.pos(x, y), colorToPlay, false);
    }

    public final void play(int x, int y, byte color) throws GameException {
        play(board.pos(x, y), color, false);
    }

    public final void set(int x, int y, byte color) {
        set(board.pos(x, y), color);
    }

    public void set(int pos, byte color) {
        byte oldColor = board.get(pos);

        if (color == oldColor)
            return;

        if (!history.empty()) {
            MoveHints h = (MoveHints)history.peek();

            if (oldColor != Board.NONE) {
                int i = h.addedStones.indexOf(new Integer(pos));
                if (i < 0) {
                    Vector v = oldColor == Board.WHITE ? h.removedWStones : h.removedBStones;
                    v.addElement(new Integer(pos));
                } else
                    h.addedStones.removeElementAt(i);
            }

            if (color != Board.NONE) {
                Vector v = color == Board.WHITE ? h.removedWStones : h.removedBStones;
                int i = v.indexOf(new Integer(pos));
                if (i < 0)
                    h.addedStones.addElement(new Integer(pos));
                else
                    v.removeElementAt(i);
            }
        }

        board.set(pos, color);
    }

    public void pass() throws GameOverStoneException {
        advance();

        koMove = -1;
        colorToPlay = Board.other(colorToPlay);
        moveNumber++;
        lastMove = -1;
    }

    public void advance() {
        MoveHints hints = new MoveHints(moveNumber, colorToPlay, lastMove, koMove,
                whiteCaptures, blackCaptures);
        history.push(hints);
    }

    public boolean undo() {
        if (history.empty())
            return false;

        MoveHints hints = (MoveHints)history.pop();

        // remove added stones and put back removed
        for (int i = 0; i < hints.addedStones.size(); i++)
            board.set(((Integer)hints.addedStones.elementAt(i)).intValue(), Board.NONE);
        for (int i = 0; i < hints.removedWStones.size(); i++)
            board.set(((Integer)hints.removedWStones.elementAt(i)).intValue(), Board.WHITE);
        for (int i = 0; i < hints.removedBStones.size(); i++)
            board.set(((Integer)hints.removedBStones.elementAt(i)).intValue(), Board.BLACK);

        // restore other values
        koMove = hints.koMove;
        colorToPlay = hints.colorToPlay;
        moveNumber = hints.moveNumber;
        lastMove = hints.lastMove;
        whiteCaptures = hints.whiteCaptures;
        blackCaptures = hints.blackCaptures;

        return true;
    }

/*    public final void play(SGFMove move) throws GameException {
        play(board.pos(move.x, move.y), move.color);
    }*/

    public String getMoveStatusText() {
        return getMoveStatusText(null);
    }

    protected String getMoveStatusText(String nodeName) {
        String s;

        if (moveNumber == 0)
            s = "Game Start";
        else {
            s = "Move " + Integer.toString(moveNumber);

            if (nodeName == null) {
                char lastMoveColor = colorToPlay == Board.BLACK ? 'W' : 'B';
                String lastMovePos;
                if (lastMove < 0)
                    lastMovePos = "Pass";
                else {
                    char[] ca = { 'A' };
                    SGFPoint p = board.xy(lastMove);
                    ca[0] += p.x;
                    if (ca[0] >= 'I') // I is skipped
                        ca[0]++;
                    lastMovePos = new String(ca) + Integer.toString(board.size() - p.y);
                }
                nodeName = lastMoveColor + " " + lastMovePos;
            }

            s += " (" + nodeName + ")";
        }
        return s;
    }

    public String getFullMoveStatusText() {
        return getFullMoveStatusText(null);
    }

    protected String getFullMoveStatusText(String nodeName) {
        char nextMoveColor = colorToPlay == Board.BLACK ? 'B' : 'W';
        return getMoveStatusText(nodeName) + ": " + nextMoveColor + " to play";
    }
}
