/**
 * TinyGo is a MIDlet to play and review Go board games.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, 
 * MA 02110-1301, USA.
 */
package com.tinyutil;

import java.util.Vector;

public class QuickSort {
    private Comparator comparator;

    private void quickSort(Vector a, int l, int r) {
        if (l < r) {
            int p = partition(a, l, r);
            quickSort(a, l, p - 1);
            quickSort(a, p + 1, r);
        }
    }
    
    private int partition(Vector a, int l, int r) {
        Object x = a.elementAt(r);
        int i = l - 1;

        for (int j = l; j < r; j++)
            if (comparator.compare(a.elementAt(j), x) <= 0)
                swap(a, ++i, j);
        
        swap(a, i + 1, r);

        return i + 1;
    }

    private void swap(Vector a, int i, int j) {
        Object tmp = a.elementAt(i);
        a.setElementAt(a.elementAt(j), i);
        a.setElementAt(tmp, j);
    }
    
    public QuickSort(Comparator comparator) {
        this.comparator = comparator;
    }
    
    public void sort(Vector a) {
        quickSort(a, 0, a.size() - 1);
    }
}
