/**
 * TinyGo is a MIDlet to play and review Go board games.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 */
package com.tinygo;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Graphics;

import com.tinygo.gam.TilePainter;

/**
 * @author Alexey Klimkin
 *
 */
class WaitCanvas extends Canvas {

    private static WaitCanvas instance = null;
    private String text = "Wait...";
    private int progress = 0;

    private WaitCanvas() {
        setFullScreenMode(true);
    }

    public static WaitCanvas getInstance() {
        if (instance == null)
            instance = new WaitCanvas();
        return instance;
    }

    public void setText(String text) {
        //#ifdef debug
        System.out.println("Wait: " + text);
        //#endif
        this.text = text;
        repaint();
    }

    public void setProgress(int value) {
        //#ifdef debug
        System.out.println("Wait progress: " + value);
        //#endif
        this.progress = value;
        repaint();
    }

    /* (non-Javadoc)
     * @see javax.microedition.lcdui.Canvas#paint(javax.microedition.lcdui.Graphics)
     */
    protected void paint(Graphics g) {
        int width = getWidth();
        int height = getHeight();

        g.setFont(Font.getFont(Font.FACE_PROPORTIONAL, Font.STYLE_PLAIN, Font.SIZE_SMALL));
        int progressBarHeight = g.getFont().getHeight();
        int y = height - progressBarHeight;

        g.setColor(TilePainter.bgColor);
        g.fillRect(0, 0, width, height);
        g.setColor(TilePainter.commentBgColor);
        g.fillRect(0, y, width, progressBarHeight);
        if (progress > 0) {
            g.setColor(TilePainter.progressColor);
            g.fillRect(0, y, width * progress / 100, progressBarHeight);
        }
        g.setColor(TilePainter.commentFgColor);
        g.drawString(text, 0, y,  Graphics.TOP | Graphics.LEFT);
    }
}
