/**
 * TinyGo is a MIDlet to play and review Go board games.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 */
package com.tinygo;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.Stack;

import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Choice;
import javax.microedition.lcdui.ChoiceGroup;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.List;
import javax.microedition.lcdui.StringItem;
import javax.microedition.lcdui.TextField;
import javax.microedition.midlet.MIDlet;

import com.tinygo.pdb.DB;
import com.tinygo.pdb.Filter;
import com.tinygo.pdb.ProblemEnumeration;
import com.tinyutil.T;

/**
 * @author Alexey Klimkin
 *
 */
class MenuScreen extends List implements CommandListener, FileSelectScreenListener {

    //private static final String menuInGame = LC._("In-game menu");
    private static final String menuNew = T._("New");
    private static final String menuProblems = T._("Solve Problems");
    private static final String menuLoad = T._("Load");
    private static final String menuLoadProb = T._("Load Problem");
    private static final String menuSave = T._("Save");
    private static final String menuOptions = T._("Options");
    private static final String menuHelp = T._("Help");
    private static final String menuExit = T._("Exit");
    private static final String menuAbout = T._("About");
    private static final String igMenuMain = T._("Main Menu");
    private static final String igMenuScore = T._("Score");
    private static final String igMenuPass = T._("Pass");
    private static final String igMenuNextProblem = T._("Next Problem");
    private static final String igMenuPrevProblem = T._("Prev Problem");
    private static final String igMenuRestart = T._("Restart");
    //private static final String igMenuFreePlay = T._("Switch Free Play");
    private static final String[] menuItems = { menuNew, menuProblems,
            menuLoad, menuLoadProb, menuSave, menuOptions, menuHelp, menuAbout, menuExit };
    private static final String[] igProblemMenuItems = { igMenuRestart,
            igMenuNextProblem, igMenuPrevProblem, igMenuMain };
    private static final String[] igPlayMenuItems = { igMenuPass, igMenuMain };
    private static final String[] igViewMenuItems = { igMenuMain };
    private static final String[] igScoreMenuItems = { igMenuScore, igMenuMain };

    // private static final String[] igEditMenuItems = {
    // igMenuAddWhiteStone, igMenuAddBlackStone, igMenuRemoveStone,
    // igMenu };

    public static final int IG_NONE = 0;
    public static final int IG_PROBLEM = 1;
    public static final int IG_PLAY = 2;
    public static final int IG_VIEW = 3;
    public static final int IG_SCORE = 4;

    private Command startCommand    = new Command(T._("Start"), Command.SCREEN, 1);
    private Command selectCommand   = new Command(T._("Select"), Command.ITEM, 2);
    private Command addCommand      = new Command(T._("Add Path"), Command.SCREEN, 2);
    private Command addPathCommand  = new Command(T._("Add Path"), Command.ITEM, 2);
    private Command updPathsCommand = new Command(T._("Update Paths"), Command.SCREEN, 3);
    private Command removeCommand   = new Command(T._("Remove"), Command.SCREEN, 3);
    private Command removeAllCommand= new Command(T._("Remove All"), Command.SCREEN, 4);
    private Command backCommand     = new Command(T._("Back"), Command.BACK, 5);

    private FileSelectScreen fileSelectScreen;
    private Form newGameForm;
    private ChoiceGroup newGameBoardSize;
    private TextField newGameCustomBoardSize;
    private TextField newGameHandicap;
    private TextField newGameKomi;
    private ChoiceGroup newGameRuleSet;
    private TextField newGameWhitePlayerName;
    private TextField newGameBlackPlayerName;
    private ChoiceGroup newGameTimeSystem;
    private TextField newGameMainTime;
    private TextField newGameByoYomiTime;
    private TextField newGameByoYomiAttr;

    private List optForm;
    private Form optPlayForm;
    private ChoiceGroup optPlaySwitches;
    private TextField optPlayCommentLines;
    private Form optProbForm;
    private ChoiceGroup optProbSwitches;
    private TextField optProbCommentLines;
    private Form optGenForm;
    private ChoiceGroup optGenSwitches;
    private TextField optCommentFontSize;

    private List igProblemMenuList;
    private List igPlayMenuList;
    private List igViewMenuList;
    private List igScoreMenuList;
    private List currentIGMenuList = null;

    private Form probFilterForm;
    private ChoiceGroup probFilterGenre;
    private ChoiceGroup probFilterDiffFrom;
    private ChoiceGroup probFilterDiffTo;
    private ChoiceGroup probFilterSortByPopularity;
    private ChoiceGroup probFilterSortByGenre;
    private ChoiceGroup probFilterSortByDifficulty;
    private ChoiceGroup probFilterShow;
    private ChoiceGroup probFilterPath;
    private List probPathList;

    private MIDlet midlet;
    private Display display;
    private MenuScreenListener listener;
    private DB pdb;
    private Stack backStack = new Stack();

    private static final String[] boardSizeList = {
        "9x9", "13x13", "19x19", T._("Custom") };
    private static final String[] ruleSetList = {
        "Japanese", "Chinese", "AGA", "NZ", "GOE" };
    private static final String[] timeSystemList = {
        T._("None"), T._("Absolute"), T._("Byo-Yomi"), T._("Canadian") };
    private static final String[] levelList = {
        "30k", "25k", "20k", "18k", "15k", "12k", "10k", "8k", "7k", "6k", "5k", "4k", "3k", "2k", "1k",
        "1d", "2d", "3d", "4d", "5d", "6d" };
    private static final String[] sortList = {
        T._("Unsorted"), T._("Ascending"), T._("Descending") };
    private static final String[] showList = {
        T._("Tried"), T._("Solved"), T._("Unrated"), T._("Randomize") };
    private static final String[] optGroupList = {
        T._("General"), T._("Play mode"), T._("Problem mode") };

    private static final String[] playOptList = {
        T._("Move status"), T._("Color to play"), T._("Timer") };
    private static final int PLAY_OPT_MOVE_STATUS = 0;
    private static final int PLAY_OPT_COLOR_TO_PLAY = 1;
    private static final int PLAY_OPT_TIMER = 2;
    private static final String[] probOptList = {
        T._("Move status"), T._("Color to play"), T._("Solved/failed"), T._("Solved/failed immediately") };
    private static final int PROB_OPT_MOVE_STATUS = 0;
    private static final int PROB_OPT_COLOR_TO_PLAY = 1;
    private static final int PROB_OPT_SOLVED_FAILED = 2;
    private static final int PROB_OPT_SOLVED_FAILED_IMMEDIATELY = 3;
    private static final String[] genOptList = {
        T._("Sound") };
    private static final int GEN_OPT_SOUND = 0;

    /**
     */
    public MenuScreen(MIDlet midlet, Display display, DB pdb) {
        super("Tiny Go", Choice.IMPLICIT, menuItems, null);
        this.midlet = midlet;
        this.display = display;
        this.pdb = pdb;

        setSelectCommand(selectCommand);
        setCommandListener(this);

        if (System.getProperty("microedition.io.file.FileConnection.version") != null) {
            fileSelectScreen = new FileSelectScreen(display);
            fileSelectScreen.setListener(this);
        }

        // ---------------------------------------------------------------
        newGameBoardSize = new ChoiceGroup(T._("Board Size"), Choice.POPUP, boardSizeList, null);
        newGameBoardSize.setSelectedIndex(0, true);
        newGameCustomBoardSize = new TextField(T._("Custom Value"), null, 2, TextField.NUMERIC);
        newGameHandicap = new TextField(T._("Handicap"), "0", 1, TextField.NUMERIC);
        newGameKomi = new TextField(T._("Komi"), "5.5", 8, TextField.DECIMAL);
        newGameRuleSet = new ChoiceGroup(T._("Rule Set"), Choice.POPUP, ruleSetList, null);
        newGameRuleSet.setSelectedIndex(0, true);
        newGameTimeSystem = new ChoiceGroup(T._("Time System"), Choice.POPUP, timeSystemList, null);
        newGameTimeSystem.setSelectedIndex(0, true);
        newGameMainTime = new TextField(T._("Main Time"), "180", 5, TextField.NUMERIC);
        newGameByoYomiTime = new TextField(T._("Byo-Yomi Time"), "30", 5, TextField.NUMERIC);
        newGameByoYomiAttr = new TextField(T._("Byo-Yomi Attr"), "5", 5, TextField.NUMERIC);

        newGameWhitePlayerName = new TextField(T._("White"), T._("White"), 32, TextField.ANY);
        newGameBlackPlayerName = new TextField(T._("Black"), T._("Black"), 32, TextField.ANY);

        newGameForm = new Form(T._("New game"));
        newGameForm.setCommandListener(this);
        newGameForm.addCommand(startCommand);
        newGameForm.addCommand(backCommand);
        newGameForm.append(newGameRuleSet);
        newGameForm.append(newGameBoardSize);
        newGameForm.append(newGameCustomBoardSize);
        newGameForm.append(newGameHandicap);
        newGameForm.append(newGameKomi);
        newGameForm.append(newGameTimeSystem);
        newGameForm.append(newGameMainTime);
        newGameForm.append(newGameByoYomiTime);
        newGameForm.append(newGameByoYomiAttr);
        newGameForm.append(newGameWhitePlayerName);
        newGameForm.append(newGameBlackPlayerName);

        // ---------------------------------------------------------------
        optPlayForm = new Form(T._("Play mode"));
        optPlayForm.setCommandListener(this);
        optPlayForm.addCommand(backCommand);
        optPlaySwitches = new ChoiceGroup(T._("On board"), Choice.MULTIPLE, playOptList, null);
        optPlaySwitches.setSelectedIndex(PLAY_OPT_MOVE_STATUS, true); // default show move status
        optPlayCommentLines = new TextField(T._("Comment lines"), "0", 1, TextField.NUMERIC);
        optPlayForm.append(optPlaySwitches);
        optPlayForm.append(optPlayCommentLines);

        optProbForm = new Form(T._("Problem mode"));
        optProbForm.setCommandListener(this);
        optProbForm.addCommand(backCommand);
        optProbSwitches = new ChoiceGroup(T._("On board"), Choice.MULTIPLE, probOptList, null);
        optProbSwitches.setSelectedIndex(PROB_OPT_COLOR_TO_PLAY, true);
        optProbSwitches.setSelectedIndex(PROB_OPT_SOLVED_FAILED, true);
        optProbCommentLines = new TextField(T._("Comment lines"), "1", 1, TextField.NUMERIC);
        optProbForm.append(optProbSwitches);
        optProbForm.append(optProbCommentLines);

        optGenForm = new Form(T._("General"));
        optGenForm.setCommandListener(this);
        optGenForm.addCommand(backCommand);
        optGenSwitches = new ChoiceGroup(null, Choice.MULTIPLE, genOptList, null);
        optGenSwitches.setSelectedIndex(GEN_OPT_SOUND, true);
        optCommentFontSize = new TextField(T._("Comment font size"), "14", 2, TextField.NUMERIC);
        optGenForm.append(optGenSwitches);
        optGenForm.append(optCommentFontSize);

        optForm = new List(T._("Options"), Choice.IMPLICIT, optGroupList, null);
        optForm.setCommandListener(this);
        optForm.addCommand(backCommand);
        optForm.addCommand(selectCommand);

        // -- In-game submenus -------------------------------------------
        igProblemMenuList = new List(T._("Problem"), Choice.IMPLICIT, igProblemMenuItems, null);
        igProblemMenuList.setCommandListener(this);
        igProblemMenuList.addCommand(backCommand);
        igPlayMenuList = new List(T._("Play"), Choice.IMPLICIT, igPlayMenuItems, null);
        igPlayMenuList.setCommandListener(this);
        igPlayMenuList.addCommand(backCommand);
        igViewMenuList = new List(T._("View"), Choice.IMPLICIT, igViewMenuItems, null);
        igViewMenuList.setCommandListener(this);
        igViewMenuList.addCommand(backCommand);
        igScoreMenuList = new List(T._("Score"), Choice.IMPLICIT, igScoreMenuItems, null);
        igScoreMenuList.setCommandListener(this);
        igScoreMenuList.addCommand(backCommand);

        // -- Problem filter ---------------------------------------------
        probFilterForm = new Form(T._("Problem filter"));
        probFilterForm.setCommandListener(this);
        if (fileSelectScreen != null)
            probFilterForm.addCommand(updPathsCommand);
        probFilterForm.addCommand(startCommand);
        probFilterForm.addCommand(backCommand);

        probFilterGenre = new ChoiceGroup(T._("Genre"), Choice.POPUP);
        //probFilterGenre.setSelectedIndex(0, true);
        probFilterDiffFrom = new ChoiceGroup(T._("Difficulty From"), Choice.POPUP, levelList, null);
        probFilterDiffFrom.setSelectedIndex(0, true);
        probFilterDiffTo = new ChoiceGroup(T._("Difficulty To"), ChoiceGroup.POPUP, levelList, null);
        probFilterDiffTo.setSelectedIndex(0, true);
        probFilterDiffTo.setSelectedIndex(levelList.length - 1, true);
        probFilterSortByGenre = new ChoiceGroup(T._("Sort By Genre"), ChoiceGroup.POPUP, sortList, null);
        probFilterSortByGenre.setSelectedIndex(0, true);
        probFilterSortByDifficulty = new ChoiceGroup(T._("Sort By Difficulty"), ChoiceGroup.POPUP, sortList, null);
        probFilterSortByDifficulty.setSelectedIndex(0, true);
        probFilterSortByPopularity = new ChoiceGroup(T._("Sort By Popularity"), ChoiceGroup.POPUP, sortList, null);
        probFilterSortByPopularity.setSelectedIndex(0, true);
        probFilterShow = new ChoiceGroup(T._("Show"), ChoiceGroup.MULTIPLE, showList, null);
        probFilterShow.setSelectedIndex(0, true);
        probFilterShow.setSelectedIndex(2, true);
        probFilterShow.setSelectedIndex(3, true);
        probFilterPath = new ChoiceGroup(T._("Path"), ChoiceGroup.MULTIPLE);

        probFilterForm.append(probFilterGenre);
        probFilterForm.append(probFilterDiffFrom);
        probFilterForm.append(probFilterDiffTo);
        probFilterForm.append(probFilterShow);
        probFilterForm.append(probFilterSortByGenre);
        probFilterForm.append(probFilterSortByPopularity);
        probFilterForm.append(probFilterSortByDifficulty);
        probFilterForm.append(probFilterPath);

        probPathList = new List(T._("Problem Paths"), List.IMPLICIT);
        probPathList.addCommand(addCommand);
        probPathList.addCommand(removeCommand);
        probPathList.addCommand(removeAllCommand);
        probPathList.addCommand(backCommand);
        probPathList.setSelectCommand(removeCommand);
        probPathList.setCommandListener(this);

    }

    private void setCurrent(Displayable d) {
        backStack.push(display.getCurrent());
        if (d != null)
            display.setCurrent(d);
    }

    private Displayable goBack() {
        if (backStack.empty()) {
            listener.mainMenuDone();
            return null;
        } else {
            Displayable d = (Displayable) backStack.pop();
            display.setCurrent(d);
            return d;
        }
    }

    public void setListener(MenuScreenListener listener) {
        this.listener = listener;
    }

    public final Form getProblemFilterForm() {
        return probFilterForm;
    }

    public void activate() {
        backStack.setSize(0);
        if (currentIGMenuList == null)
            display.setCurrent(this);
        else
            display.setCurrent(currentIGMenuList);
    }

    public void setIG(int igMode) {
        if (igMode == IG_NONE) {
            removeCommand(backCommand);
            currentIGMenuList = null;
        } else {
            addCommand(backCommand);
            switch (igMode) {
                case IG_PROBLEM:
                    currentIGMenuList = igProblemMenuList;
                    break;
                case IG_PLAY:
                    currentIGMenuList = igPlayMenuList;
                    break;
                case IG_VIEW:
                    currentIGMenuList = igViewMenuList;
                    break;
                case IG_SCORE:
                    currentIGMenuList = igScoreMenuList;
                    break;
                default:
                    // DO NOTHING
            }
        }
    }

    public void commandAction(Command c, Displayable d) {
        if (c == backCommand) {
            if (d == optGenForm)
                optTransGeneralSettings();
            else if (d == optPlayForm)
                optTransPlayModeSettings();
            else if (d == optProbForm)
                optTransProbModeSettings();
            goBack();
        } else if (d == this) {
            String s = getString(getSelectedIndex());
            if (s == menuNew)
                setCurrent(newGameForm);
            else if (s == menuProblems) {
                setCurrent(probFilterForm);
            } else if (s == menuLoad || s == menuLoadProb) {
                if (fileSelectScreen != null) {
                    setCurrent(null);
                    fileSelectScreen.activate(false, false);
                }
            } else if (s == menuSave) {
                if (fileSelectScreen != null) {
                    setCurrent(null);
                    fileSelectScreen.activate(true, true);
                }
            } else if (s == menuOptions) {
                setCurrent(optForm);
            } else if (s == menuHelp)
                displayHelp();
            else if (s == menuAbout)
                displayAbout();
            else if (s == menuExit)
                listener.mainMenuExit();
        } else if (d == newGameForm) {
            if (c == startCommand)
                createGame();
        } else if (d == optForm) {
            switch (optForm.getSelectedIndex()) {
                case 0:
                    setCurrent(optGenForm);
                    break;
                case 1:
                    setCurrent(optPlayForm);
                    break;
                case 2:
                    setCurrent(optProbForm);
                    break;
            }
        } else if (d == igProblemMenuList || d == igPlayMenuList
                || d == igViewMenuList || d == igScoreMenuList) {
            List l = (List) d;
            String s = l.getString(l.getSelectedIndex());
            if (s == igMenuMain)
                setCurrent(this);
            else if (s == igMenuPass)
                listener.igMenuPass();
            /*else if (s == igMenuFreePlay)
                listener.igMenuFreePlay();*/
            else if (s == igMenuRestart)
                listener.igMenuRestartProblem();
            else if (s == igMenuNextProblem)
                listener.igMenuNextProblem();
            else if (s == igMenuPrevProblem)
                listener.igMenuPrevProblem();
            else if (s == igMenuScore)
                listener.igMenuScore();
        } else if (d == probFilterForm) {
            if (c == startCommand) {
                probStartSolving();
            } else if (c == addCommand) {
                setCurrent(null);
                fileSelectScreen.activate(false, false, addPathCommand);
            } else if (c == updPathsCommand)
                setCurrent(probPathList);
        } else {
            if (c == addCommand) {
                setCurrent(null);
                fileSelectScreen.activate(false, false, addPathCommand);
            } else if (c == removeCommand) {
                probRemovePath();
            } else if (c == removeAllCommand) {
                probRemovePathAll();
            }
        }
    }

    void createGame() {
        StringBuffer alertText = new StringBuffer();

        int size;
        switch (newGameBoardSize.getSelectedIndex()) {
            case 0:
                size = 9;
                break;
            case 1:
                size = 13;
                break;
            case 2:
                size = 19;
                break;
            default:
                size = Integer.parseInt(newGameCustomBoardSize.getString());
        }
        if (size < 2)
            alertText.append(T._("Board size should be > 1.\n"));

        int handicap = Integer.parseInt(newGameHandicap.getString());
        if (handicap < 0 || handicap > 9)
            alertText.append(T._("Handicap value should be >= 0 and <= 9.\n"));

        float komi = Float.parseFloat(newGameKomi.getString());
        String ruleSet = ruleSetList[newGameRuleSet.getSelectedIndex()];
        String white = newGameWhitePlayerName.getString();
        String black = newGameBlackPlayerName.getString();

        int timeSystem = newGameTimeSystem.getSelectedIndex();
        long mainTime = Integer.parseInt(newGameMainTime.getString()) * 1000;
        long byoYomiTime = Integer.parseInt(newGameByoYomiTime.getString()) * 1000;
        int byoYomiAttr = Integer.parseInt(newGameByoYomiAttr.getString());

        if (alertText.length() > 0) {
            Alert alert = new Alert(T._("Error!"), alertText.toString(), null, AlertType.ERROR);
            alert.setTimeout(Alert.FOREVER);
            display.setCurrent(alert);
        } else
            listener.mainMenuNewGame(white, black, ruleSet, size, handicap, komi, timeSystem, mainTime, byoYomiTime, byoYomiAttr);
    }

    public void probUpdateFromPDB() {
        String[] data;

        String[] oldPaths = null;
        boolean[] oldSelected = null;
        final int oldSz = probFilterPath.size();
        if (oldSz > 0) {
            oldPaths = new String[oldSz];
            oldSelected = new boolean[oldSz];
            for (int i = 0; i < oldSz; i++)
                oldPaths[i] = probFilterPath.getString(i);
            probFilterPath.getSelectedFlags(oldSelected);
        }

        probPathList.deleteAll();
        probFilterPath.deleteAll();
        data = pdb.getPaths();
        for (int i = 0; i < data.length; i++) {
            probPathList.append(data[i], null);
            int pfInd = probFilterPath.append(data[i], null);
            if (oldSz > 0) {
                int j;
                for (j = 0; j < oldSz; j++) {
                    if (oldPaths[j] == data[i]) {
                        probFilterPath.setSelectedIndex(pfInd, oldSelected[j]);
                        break;
                    }
                }
                if (j == oldSz)
                    probFilterPath.setSelectedIndex(pfInd, true);
            } else
                probFilterPath.setSelectedIndex(pfInd, true);
        }

        probFilterGenre.deleteAll();
        data = pdb.getGenres();
        probFilterGenre.append(T._("any"), null);
        for (int i = 0; i < data.length; i++)
            probFilterGenre.append(data[i], null);
    }

    void probStartSolving() {
        Filter probFilter = new Filter();
        // set problem filter
        int i;
        // genre filter
        i = probFilterGenre.getSelectedIndex();
        probFilter.genre = i <= 0 ? null : probFilterGenre.getString(i);
        // difficulty filter
        i = probFilterDiffFrom.getSelectedIndex();
        probFilter.difficultyFrom = Filter.rank2int(probFilterDiffFrom.getString(i));
        i = probFilterDiffTo.getSelectedIndex();
        probFilter.difficultyTo = Filter.rank2int(probFilterDiffTo.getString(i));
        // sort fields: genre, popularity, difficulty
        i = probFilterSortByGenre.getSelectedIndex();
        probFilter.sortByGenre = i == 2 ? -1 : i;
        i = probFilterSortByPopularity.getSelectedIndex();
        probFilter.sortByPopularity = i == 2 ? -1 : i;
        i = probFilterSortByDifficulty.getSelectedIndex();
        probFilter.sortByDifficulty = i == 2 ? -1 : i;
        // show filters: tried, solved, unrated
        probFilter.tried = probFilterShow.isSelected(0);
        probFilter.solved = probFilterShow.isSelected(1);
        probFilter.unrated = probFilterShow.isSelected(2);
        probFilter.randomize = probFilterShow.isSelected(3);
        // paths
        int numUnsel = 0;
        for (i = 0; i < probFilterPath.size(); i++)
            if (!probFilterPath.isSelected(i))
                numUnsel++;
        if (numUnsel > 0) {
            probFilter.excludePaths = new String[numUnsel];
            int j = 0;
            for (i = 0; i < probFilterPath.size(); i++)
                if (!probFilterPath.isSelected(i))
                    probFilter.excludePaths[j++] = probFilterPath.getString(i);
        } else
            probFilter.excludePaths = null;

        ProblemEnumeration e;
        try {
            e = pdb.enumerateRecords(probFilter);
        } catch (Exception x) {
            probError(T._("Unable to enumerate records!"), x, null);
            return;
        }
        if (e == null || !e.hasMoreElements()) {
            Alert alert = new Alert(T._("Problem solving"),
                    T._("Empty set, try widening criteria."),
                    null, AlertType.INFO);
            display.setCurrent(alert);
        } else
            listener.mainMenuSolveProblems(e);
    }

    void probAddPath(final String path) {
        final WaitCanvas wc = WaitCanvas.getInstance();
        wc.setText(T._("Reading problems..."));
        wc.setProgress(0);
        setCurrent(wc);

        new Thread(new Runnable() {
            public void run() {
                try {
                    int n = pdb.addPath(path, true);
                    probUpdateFromPDB();
                    Alert alert = new Alert(T._("Add Path"), T._("") + n + T._(" problems added"), null, AlertType.INFO);
                    alert.setTimeout(Alert.FOREVER);
                    display.setCurrent(alert, goBack());
                } catch (Exception e) {
                    probError(T._("Unable to add path!"), e, goBack());
                }
            }
        }).start();
    }

    void probRemovePath() {
        List l = (List) display.getCurrent();
        int i = l.getSelectedIndex();
        if (i >= 0) {
            try {
                String path = l.getString(i);
                pdb.removePath(path);
                listener.mainMenuInvalidateProblems();
                probUpdateFromPDB();
            } catch (Exception e) {
                probError(T._("Unable to remove path!"), e, null);
            }
        }
    }

    void probRemovePathAll() {
        try {
            pdb.removePathAll();
            listener.mainMenuInvalidateProblems();
            probUpdateFromPDB();
        } catch (Exception e) {
            probError(T._("Unable to remove!"), e, null);
        }
    }

    void probError(String msg, Exception e, Displayable d) {
        //#if debug
        e.printStackTrace();
        //#endif
        Alert alert = new Alert(T._("Problem DB error!"), msg + T._("\n") + e.toString(),
                null, AlertType.ERROR);
        alert.setTimeout(Alert.FOREVER);
        if (d == null)
            display.setCurrent(alert);
        else
            display.setCurrent(alert, d);
    }

    private void optTransGeneralSettings() {
        boolean sound = optGenSwitches.isSelected(GEN_OPT_SOUND);
        int commentFontSize = Integer.parseInt(optCommentFontSize.getString());
        listener.optGeneralSettings(sound, commentFontSize);
    }

    private void optTransPlayModeSettings() {
        boolean moveStatus = optPlaySwitches.isSelected(PLAY_OPT_MOVE_STATUS);
        boolean colorToPlay = optPlaySwitches.isSelected(PLAY_OPT_COLOR_TO_PLAY);
        boolean timer = optPlaySwitches.isSelected(PLAY_OPT_TIMER);
        int commentLines = Integer.parseInt(optPlayCommentLines.getString());
        listener.optPlayModeSettings(moveStatus, colorToPlay, timer, commentLines);
    }

    private void optTransProbModeSettings() {
        boolean moveStatus = optProbSwitches.isSelected(PROB_OPT_MOVE_STATUS);
        boolean colorToPlay = optProbSwitches.isSelected(PROB_OPT_COLOR_TO_PLAY);
        boolean solvedFailed = optProbSwitches.isSelected(PROB_OPT_SOLVED_FAILED);
        boolean solvedFailedImmediately = optProbSwitches.isSelected(PROB_OPT_SOLVED_FAILED_IMMEDIATELY);
        int commentLines = Integer.parseInt(optProbCommentLines.getString());
        listener.optProbModeSettings(moveStatus, colorToPlay, solvedFailed, solvedFailedImmediately, commentLines);
    }

    public void fileSelectDone() {
        goBack();
    }

    public void fileSelected(String currDirName, String fileName, Command cmd) {
        String s = getString(getSelectedIndex());
        if (s == menuLoad)
            listener.mainMenuLoad(currDirName + fileName);
        else if (s == menuLoadProb)
            listener.mainMenuLoadProblem(currDirName + fileName);
        else if (s == menuSave)
            listener.mainMenuSave(currDirName + fileName);
        else if (s == menuProblems) {
            if (!fileName.equals(FileSelectScreen.UP_DIRECTORY))
                probAddPath(currDirName + fileName);
        }
    }

    private void displayText(String title, String body) {
        Form f = new Form(title);
        f.addCommand(backCommand);
        f.setCommandListener(this);
        StringItem i = new StringItem(null, body);
        i.setFont(Font.getFont(Font.FACE_PROPORTIONAL, Font.STYLE_PLAIN, Font.SIZE_SMALL));
        f.append(i);
        setCurrent(f);
    }

    private void displayResourceFile(String title, String resFilePath) {
        //#ifdef debug
        System.out.println("Reading resource '" + resFilePath + "'");
        //#endif

        InputStream is = getClass().getResourceAsStream(resFilePath);
        if (is == null)
            return;

        InputStreamReader isr;
        try {
            isr = new InputStreamReader(is, "UTF8");
        } catch (UnsupportedEncodingException e1) {
            isr = new InputStreamReader(is);
        }
        StringBuffer sb = new StringBuffer();
        try {
            int c;
            while ((c = isr.read()) != -1)
                sb.append((char)c);
            isr.close();
            is.close();
        } catch (IOException e) {
        }

        displayText(title, sb.toString());
    }

    private void displayHelp() {
        displayResourceFile(T._("Help"), T._("/T/help"));
    }

    private void displayAbout() {
        StringBuffer sb = new StringBuffer();
        sb.append("Tiny Go v" + midlet.getAppProperty("MIDlet-Version") + "\n\n");
        sb.append("Copyright (C) 2006, 2007  Alexey Klimkin\n");
        sb.append("This program is free software.");

        displayText(T._("About"), sb.toString());
    }

    /*public void displayAbout() {
        displayFile(LC._("About"), aboutFile);
    }*/

    public void save(DataOutputStream dout) throws IOException {
        boolean[] flags;
        // ---------------------------------------------------------------

        dout.writeByte(probFilterGenre.getSelectedIndex());
        dout.writeByte(probFilterDiffFrom.getSelectedIndex());
        dout.writeByte(probFilterDiffTo.getSelectedIndex());
        dout.writeByte(probFilterSortByPopularity.getSelectedIndex());
        dout.writeByte(probFilterSortByGenre.getSelectedIndex());
        dout.writeByte(probFilterSortByDifficulty.getSelectedIndex());

        flags = new boolean[probFilterShow.size()];
        probFilterShow.getSelectedFlags(flags);
        dout.writeByte(flags.length);
        for (int i = 0; i < flags.length; i++)
            dout.writeBoolean(flags[i]);

        flags = new boolean[probFilterPath.size()];
        probFilterPath.getSelectedFlags(flags);
        dout.writeByte(flags.length);
        for (int i = 0; i < flags.length; i++)
            dout.writeBoolean(flags[i]);

        // ---------------------------------------------------------------
        flags = new boolean[optGenSwitches.size()];
        optGenSwitches.getSelectedFlags(flags);
        dout.writeByte(flags.length);
        for (int i = 0; i < flags.length; i++)
            dout.writeBoolean(flags[i]);
        dout.writeUTF(optCommentFontSize.getString());

        flags = new boolean[optPlaySwitches.size()];
        optPlaySwitches.getSelectedFlags(flags);
        dout.writeByte(flags.length);
        for (int i = 0; i < flags.length; i++)
            dout.writeBoolean(flags[i]);
        dout.writeUTF(optPlayCommentLines.getString());

        flags = new boolean[optProbSwitches.size()];
        optProbSwitches.getSelectedFlags(flags);
        dout.writeByte(flags.length);
        for (int i = 0; i < flags.length; i++)
            dout.writeBoolean(flags[i]);
        dout.writeUTF(optProbCommentLines.getString());
    }

    public void restore(DataInputStream din) throws IOException {
        try {
            probFilterGenre.setSelectedIndex(din.readByte(), true);
        } catch (IndexOutOfBoundsException e) {
        }
        try {
            probFilterDiffFrom.setSelectedIndex(din.readByte(), true);
        } catch (IndexOutOfBoundsException e) {
        }
        try {
            probFilterDiffTo.setSelectedIndex(din.readByte(), true);
        } catch (IndexOutOfBoundsException e) {
        }
        try {
            probFilterSortByPopularity.setSelectedIndex(din.readByte(), true);
        } catch (IndexOutOfBoundsException e) {
        }
        try {
            probFilterSortByGenre.setSelectedIndex(din.readByte(), true);
        } catch (IndexOutOfBoundsException e) {
        }
        try {
            probFilterSortByDifficulty.setSelectedIndex(din.readByte(), true);
        } catch (IndexOutOfBoundsException e) {
        }

        boolean[] flags;
        int sz;

        sz = din.readByte();
        if (sz > 0) {
            flags = new boolean[sz];
            for (int i = 0; i < flags.length; i++)
                flags[i] = din.readBoolean();
            try {
                probFilterShow.setSelectedFlags(flags);
            } catch (IllegalArgumentException e) {
            }
        }

        sz = din.readByte();
        if (sz > 0) {
            flags = new boolean[sz];
            for (int i = 0; i < flags.length; i++)
                flags[i] = din.readBoolean();
            try {
                probFilterPath.setSelectedFlags(flags);
            } catch (IllegalArgumentException e) {
            }
        }

        // ---------------------------------------------------------------
        sz = din.readByte();
        if (sz > 0) {
            flags = new boolean[sz];
            for (int i = 0; i < flags.length; i++)
                flags[i] = din.readBoolean();
            try {
                optGenSwitches.setSelectedFlags(flags);
            } catch (IllegalArgumentException e) {
            }
        }
        optCommentFontSize.setString(din.readUTF());

        sz = din.readByte();
        if (sz > 0) {
            flags = new boolean[sz];
            for (int i = 0; i < flags.length; i++)
                flags[i] = din.readBoolean();
            try {
                optPlaySwitches.setSelectedFlags(flags);
            } catch (IllegalArgumentException e) {
            }
        }
        optPlayCommentLines.setString(din.readUTF());

        sz = din.readByte();
        if (sz > 0) {
            flags = new boolean[sz];
            for (int i = 0; i < flags.length; i++)
                flags[i] = din.readBoolean();
            try {
                optProbSwitches.setSelectedFlags(flags);
            } catch (IllegalArgumentException e) {
            }
        }
        optProbCommentLines.setString(din.readUTF());

    }
}