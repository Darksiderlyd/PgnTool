/**
 * TinyGo is a MIDlet to play and review Go board games.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 */
package com.tinyutil;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Hashtable;

/**
 * @author Alexey Klimkin
 *
 */
public class T {
    private static String locale = "en-US";
    private static Hashtable messages = new Hashtable();

    public static String _(String text) {
        String translation = (String)messages.get(text);
        if (translation == null) {
            translation = text;
            //#ifdef debug
            if (!locale.equals("en-US"))
                System.out.println(text + '=');
            //#endif
        }
        return translation;
    }

    public static String getLocale() {
        return locale;
    }

    public static void setLocale(String locale) {
        if (locale == null)
            return;

        messages.clear();
        T.locale = "en-US";

        Class c = locale.getClass();
        InputStream is = c.getResourceAsStream("/T/" + locale);

        if (is != null) {
            try {
                InputStreamReader isr = new InputStreamReader(is, "UTF8");
                readTranslations(isr);
                T.locale = locale;
            } catch (Exception e) {
                messages.clear();
                //#ifdef debug
                e.printStackTrace();
                //#endif
            }
        }

        //#ifdef debug
        System.out.println("Locale: " + T.locale);
        //#endif
    }

    private static final boolean isnl(int c) {
        return c == '\n' || c == '\r';
    }

    private static void readTranslations(InputStreamReader isr) throws IOException {
        StringBuffer line = new StringBuffer();
        int c;

        do {
            // skip comment and empty lines
            do {
                c = isr.read();
                if (c == '#')
                    do {
                        c = isr.read();
                    } while (c != -1 && !isnl(c));
            } while (c != -1 && isnl(c));

            // read our line
            while (c != -1 && !isnl(c)) {
                line.append((char)c);
                c = isr.read();
            }

            if (line.length() > 0) {
                // parse key=value
                String s = line.toString();
                line.setLength(0);

                int i = s.indexOf('=');
                if (i != -1) {
                    String key = s.substring(0, i);
                    String value = s.substring(i + 1);
                    messages.put(key, value);
                }
            }
        } while (c != -1);
    }
}
