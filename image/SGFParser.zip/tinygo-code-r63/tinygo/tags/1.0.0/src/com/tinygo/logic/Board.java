/**
 * TinyGo is a MIDlet to play and review Go board games.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, 
 * MA 02110-1301, USA.
 */
package com.tinygo.logic;

import com.sgfj.SGFMove;
import com.sgfj.SGFPoint;

/**
 * @author Alexey Klimkin
 *
 */
public class Board {
    public static final byte NONE   = SGFMove.NONE;
    public static final byte WHITE  = SGFMove.WHITE;
    public static final byte BLACK  = SGFMove.BLACK;

    private int     size = -1;
    private byte[]  stones;

    public static final byte M_VISITED = 1;
    public static final byte M_DEAD    = 2;
    public static final byte M_CAPTURED= 4;
    private byte[]  bits;

    public static final int HOSHI_NW = 0;
    public static final int HOSHI_N  = 1;
    public static final int HOSHI_NE = 2;
    public static final int HOSHI_W  = 3;
    public static final int HOSHI_C  = 4;
    public static final int HOSHI_E  = 5;
    public static final int HOSHI_SW = 6;
    public static final int HOSHI_S  = 7;
    public static final int HOSHI_SE = 8;

    private static final int[] hoshis19 = {
        Board.pos(3,  3, 19), Board.pos(9,  3, 19), Board.pos(15,  3, 19),
        Board.pos(3,  9, 19), Board.pos(9,  9, 19), Board.pos(15,  9, 19),
        Board.pos(3, 15, 19), Board.pos(9, 15, 19), Board.pos(15, 15, 19)
    };
    private static final int[] hoshis15 = {
        Board.pos(3,  3, 15), Board.pos(7,  3, 15), Board.pos(11,  3, 15),
        Board.pos(3,  7, 15), Board.pos(7,  7, 15), Board.pos(11,  7, 15),
        Board.pos(3, 11, 15), Board.pos(7, 11, 15), Board.pos(11, 11, 15)
    };
    private static final int[] hoshis13 = {
        Board.pos(3, 3, 13), Board.pos(6, 3, 13), Board.pos(9, 3, 13),
        Board.pos(3, 6, 13), Board.pos(6, 6, 13), Board.pos(9, 6, 13),
        Board.pos(3, 9, 13), Board.pos(6, 9, 13), Board.pos(9, 9, 13)
    };
    private static final int[] hoshis11 = {
        Board.pos(3, 3, 11), Board.pos(5, 3, 11), Board.pos(7, 3, 11),
        Board.pos(3, 5, 11), Board.pos(5, 5, 11), Board.pos(7, 5, 11),
        Board.pos(3, 7, 11), Board.pos(5, 7, 11), Board.pos(7, 7, 11)
    };
    private static final int[] hoshis9  = {
        Board.pos(2, 2, 9), Board.pos(4, 2, 9), Board.pos(6, 2, 9),
        Board.pos(2, 4, 9), Board.pos(4, 4, 9), Board.pos(6, 4, 9),
        Board.pos(2, 6, 9), Board.pos(4, 6, 9), Board.pos(6, 6, 9)
    };

    public Board(int size) {
        setSize(size);
    }

    public final int size() {
        return size;
    }

    public final int maxPos() {
        return stones.length;
    }

    public void setSize(int size) {
        if (this.size != size) {
            stones = new byte[size * size];
            bits   = new byte[size * size];
            this.size = size;
        }
        clear();
    }

    public static final byte other(byte color) {
        switch (color) {
            case WHITE: return BLACK;
            case BLACK: return WHITE;
            default:    return NONE;
        }
    }

    public static final int pos(int x, int y, int boardSize) {
        return x + y * boardSize;
    }

    public final int pos(int x, int y) {
        return pos(x, y, size);
    }

    public final int pos(SGFPoint p) {
        return pos(p.x, p.y);
    }

    public static final SGFPoint xy(int pos, int boardSize) {
        return new SGFPoint(pos % boardSize, pos / boardSize);
    }

    public final SGFPoint xy(int pos) {
        return xy(pos, size);
    }

    public final int n(int pos) {
        return n(pos, 1);
    }

    public final int n(int pos, int delta) {
        int p = pos - size * delta;
        if (p >= 0)
            return p;
        else
            return -1;
    }

    public final int s(int pos) {
        return s(pos, 1);
    }

    public final int s(int pos, int delta) {
        int p = pos + size * delta;
        if (p < stones.length)
            return p;
        else
            return -1;
    }

    public final int w(int pos) {
        return w(pos, 1);
    }

    public final int w(int pos, int delta) {
        if (pos % size == 0)
            return -1;
        else
            return pos - 1;
    }

    public final int e(int pos) {
        return e(pos, 1);
    }

    public final int e(int pos, int delta) {
        int p = pos + 1;
        if (p % size == 0)
            return -1;
        else
            return p;
    }

    public final boolean valid(int pos) {
        return 0 <= pos && pos < stones.length;
    }

    public final byte get(int pos) {
        return stones[pos];
    }

    public final byte get(int x, int y) {
        return stones[pos(x, y)];
    }

    public final void set(int pos, byte color) {
        stones[pos] = color;
    }

    public final void set(int x, int y, byte color) {
        stones[pos(x, y)] = color;
    }

    public final boolean isBit(int pos, byte mask) {
        return (bits[pos] & mask) != 0;
    }

    public final void setBit(int pos, byte mask) {
        bits[pos] |= mask;
    }

    public void setBit(Group group, byte mask) {
        for (int i = 0; i < group.size; i++)
            setBit(group.stones[i], mask);
    }

    public final void clearBit(int pos, byte mask) {
        bits[pos] &= ~mask;
    }

    public void clearBit(Group group, byte mask) {
        for (int i = 0; i < group.size; i++)
            clearBit(group.stones[i], mask);
    }

    public void clearBits(byte mask) {
        for (int i = 0; i < bits.length; i++)
            bits[i] &= ~mask;
    }

    public void getGroup(int pos, Group group) {
        byte color = group.color = get(pos);
        //if (color == Board.NONE)
            //return;
        clearBits(M_VISITED);

        int toProcess = group.size;
        group.add(pos);
        setBit(pos, M_VISITED);
        while (toProcess < group.size) {
            pos = group.stones[toProcess++];
            int[] pp = { n(pos), s(pos), w(pos), e(pos) };
            for (int i = 0; i < 4; i++) {
                int p = pp[i];
                if (p >= 0 && !isBit(p, M_VISITED)) {
                    if (get(p) == color) {
                        group.add(p);
                        setBit(p, M_VISITED);
                    } else if (get(p) == Board.NONE) {
                        group.liberties++;
                        setBit(p, M_VISITED);
                    }
                }
            }
        }
    }

    public void clear() {
        for (int i = 0; i < stones.length; i++) {
            stones[i] = NONE;
            bits[i] = 0;
        }
    }

    public static int[] getHoshis(int boardSize) {
        switch (boardSize) {
            case 19: return hoshis19;
            case 15: return hoshis15;
            case 13: return hoshis13;
            case 11: return hoshis11;
            case 9:  return hoshis9;
            default: return null;
        }
    }

    public final int[] getHoshis() {
        return getHoshis(size);
    }

    public final int hoshi(int hoshiID) {
        return getHoshis()[hoshiID];
    }

    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("  ");
        for (int i = 0; i < size; i++) {
            if (i < 10)
                sb.append(' ');
            sb.append(i);
        }
        sb.append('\n');
        for (int i = 0; i < stones.length; i++) {
            if (i % size == 0) {
                int j = i / size;
                if (j < 10)
                    sb.append(' ');
                sb.append(j);
            }
            char c = '+';
            switch (stones[i]) {
                case WHITE:
                    c = 'O';
                    break;
                case BLACK:
                    c = '*';
                    break;
            }
            sb.append(' ');
            sb.append(c);
            if ((i + 1) % size == 0)
                sb.append('\n');
        }
        return sb.toString();
    }
}
