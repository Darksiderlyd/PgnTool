/**
 * tgIndex is the tool to create binary index for multy-SGF file.
 * Copyright (C) 2006, 2007  Alexey Klimkin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 */

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Vector;

import com.sgfj.SGFEOFException;
import com.sgfj.SGFException;
import com.sgfj.SGFNode;
import com.sgfj.SGFParseError;
import com.sgfj.SGFParser;
import com.sgfj.SGFPropertyName;
import java.io.UnsupportedEncodingException;

class Problem {
    public String subPath;
    public int offset;
    public int genre;
    public int difficulty;  // <0 = kyu, 0 = undefined, >0 = dan
    public int difficultyP; // percentage
    public int popularity;
}

class Scanner {
    public Vector genres = new Vector();
    public Vector paths = new Vector();
    public Vector problems = new Vector();

    public static int rank2int(String rank) {
        int lastCharPos = rank.length() - 1;
        if (lastCharPos == 0)
            return 0;
        char lastChar = rank.charAt(lastCharPos);
        if (lastChar != 'k' && lastChar != 'd')
            return 0;
        int result = Integer.parseInt(rank.substring(0, lastCharPos));
        if (lastChar == 'k')
            result = -result;
        return result;
    }

    public void processFile(String top, String subPath) throws FileNotFoundException {
        String filePath = subPath == null ? top : top + File.separator + subPath;

        FileInputStream fis = new FileInputStream(new File(filePath));
        InputStreamReader isr;
        isr = new InputStreamReader(fis);
        SGFParser parser = new SGFParser(isr);

        while (true) {
            int offset = parser.getCharsConsumed();

            // parse file to get tree
            SGFNode tree = null;
            try {
                tree = parser.parse();
            } catch (SGFEOFException e) {
                // DO NOTHING
                break;
            } catch (SGFParseError e) {
                System.out.println("Parse error " + filePath + ":" + e.getMessage());
                break;
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                break;
            }

            Problem entry = new Problem();
            entry.subPath = subPath;

            String genre;
            try {
                genre = tree.getProperty(SGFPropertyName.GE).getText();
            } catch (SGFException e) {
                genre = "undefined";
            }
            int i = genres.indexOf(genre);
            if (i < 0) {
                i = genres.size();
                genres.addElement(genre);
            }
            entry.genre = i;

            try {
                entry.difficulty = rank2int(tree.getProperty(SGFPropertyName.DI).getText());
            } catch (SGFException e) {
                entry.difficulty = 0;
            }
            try {
                entry.difficultyP = tree.getProperty(SGFPropertyName.DP).getInt();
            } catch (SGFException e) {
                entry.difficultyP = -1;
            }
            try {
                entry.popularity = tree.getProperty(SGFPropertyName.CO).getInt();
            } catch (SGFException e) {
                entry.popularity = -1;
            }

            entry.offset = offset;

            problems.addElement(entry);

        }
    }

    public void traverse(String top, String name) throws FileNotFoundException {

        File f = new File(name == null ? top : top + File.separator + name);

        if (f.isDirectory()) {
            String[] children = f.list();
            for (int i = 0; i < children.length; i++) {
                traverse(top, name == null ? children[i] : name + File.separator + children[i]);
            }
        } else
            processFile(top, name);

    }
}

public class tgIndex {

    public static final int version = 1;

    private static int probCount = 0;

    public static void makeIndex(String path, String output) {
        Scanner scanner = new Scanner();
        try {
            scanner.traverse(path, null);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        File outFile = new File(output);
        try {
            outFile.createNewFile();
            FileOutputStream fos = new FileOutputStream(outFile);
            DataOutputStream dout = new DataOutputStream(fos);

            Vector genres = scanner.genres;
            Vector problems = scanner.problems;

            System.out.println(path + " " + problems.size() + " problems");
            probCount += problems.size();

            boolean isDir = new File(path).isDirectory();

            dout.writeByte(version);
            dout.writeBoolean(isDir);

            dout.writeInt(genres.size());
            for (int i = 0; i < genres.size(); i++)
                dout.writeUTF((String)genres.elementAt(i));

            dout.writeInt(problems.size());
            for (int i = 0; i < problems.size(); i++) {
                Problem r = (Problem)problems.elementAt(i);
                if (isDir)
                    dout.writeUTF(r.subPath);
                dout.writeInt(r.genre);
                dout.writeInt(r.offset);
                dout.writeByte(r.difficulty);
                dout.writeByte(r.difficultyP);
                dout.writeByte(r.popularity);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Sole entry point to the class and application.
     * @param args Array of String arguments.
     */
    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("Generate index of SGF collection for TinyGo usage.");
            System.out.println("Usage: tgIndex <file or dir path> ...");
            return;
        }

        for (int i = 0; i < args.length; i++) {
            String path = args[i];
            String output = new File(path).isFile() ? path + "i" : path + ".sgfi";
            makeIndex(path, output);
        }
        System.out.println("Total " + probCount + " problems found.");
    }

}
