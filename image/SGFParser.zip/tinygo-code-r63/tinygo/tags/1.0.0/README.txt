Tiny Go is a MIDlet (cell phone application, MIDP 2.0, CLDC 1.1),
which allows to play and review Go (Weiqi, Igo, Baduk) board game
files in Smart Game Format (SGF). Supports problem solving.
Project provides library for SGF parsing as separate package.

Features
    * Complete implementation of Go game logic, including ko and handicap.
    * Antialiased zoomable goban graphics with all major markups.
    * Modes: play, review, score and problem solving.
    * Absolute, Byo-Yomi and Canadian game timers.
    * Simple score estimation using Bouzy Map algorithm.
    * Rich problem solving mode with statistics tracking.
    * Save, load and solve problems using JSR-75 (device file system).
    * Translations: English and Russian.

See http://sourceforge.net/projects/tinygo/ for release information.

Copyright (C) 2006, 2007  Alexey Klimkin
